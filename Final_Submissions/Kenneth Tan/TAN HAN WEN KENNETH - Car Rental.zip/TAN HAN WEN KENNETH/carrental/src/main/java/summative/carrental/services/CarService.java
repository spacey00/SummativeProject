package summative.carrental.services;

import java.util.List;

import summative.carrental.model.cars.Car;
import summative.carrental.model.cars.CarBrand;

public interface CarService {
    List<CarBrand> getAllBrands();

    List<Car> getAllCarsFiltered(Car car);

    List<Car> getAllCars();

    Car addCar(Car car);

    CarBrand createBrand(CarBrand carBrand);

    void disableCar(Long id);

    void enableCar(Long id);

    Car getCarById(Long id);
}
