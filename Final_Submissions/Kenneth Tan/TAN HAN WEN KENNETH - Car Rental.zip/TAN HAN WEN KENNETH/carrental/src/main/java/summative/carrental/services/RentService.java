package summative.carrental.services;

import java.time.LocalDate;
import java.util.List;

import summative.carrental.dto.BasicStatsDto;
import summative.carrental.misc.exceptions.CarNotFoundException;
import summative.carrental.misc.exceptions.RentExistsForTimespan;
import summative.carrental.model.rents.Rent;
import summative.carrental.model.rents.RentRequest;

public interface RentService {
    List<LocalDate> getUnavailableDays(Long id);

    RentRequest createRentRequest(RentRequest rentRequest) throws RentExistsForTimespan, CarNotFoundException;

    List<RentRequest> getAllRentRequests();

    List<Rent> getAllRentsForCar(Long id);

    void acceptRequest(Long id);

    void rejectRequest(Long id);

    List<RentRequest> getAllRentRequestsForUser(Long userId);

    List<Rent> getAllRentsForUser(Long userId);

    BasicStatsDto getRentRequestsStatsForLastDays(int days);

    BasicStatsDto getRentStatsForLastDays(int days);
}
