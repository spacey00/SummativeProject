package summative.carrental.misc.exceptions;

public class EmailAlreadyTaken extends Exception {
}
