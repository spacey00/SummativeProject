package summative.carrental.model.cars;

public enum  TransmissionType {
    MANUAL, AUTOMATIC
}
