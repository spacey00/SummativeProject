package summative.carrental.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import summative.carrental.model.rents.RentRequest;

import java.util.List;

public interface RentRequestRepository extends JpaRepository<RentRequest, Long> {
    List<RentRequest> findAllBySystemUserId(Long userId);
}
