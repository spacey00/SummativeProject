package summative.carrental.misc;

public interface PasswordAndRePasswordProvider {
    String getPassword();
    String getRePassword();
}
