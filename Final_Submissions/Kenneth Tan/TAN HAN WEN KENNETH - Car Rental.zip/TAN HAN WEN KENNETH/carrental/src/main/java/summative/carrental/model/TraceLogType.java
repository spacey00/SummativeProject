package summative.carrental.model;

public enum TraceLogType {
    CAR_RENTAL, CAR_RENTAL_REQUEST
}
