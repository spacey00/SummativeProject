package summative.carrental.misc.exceptions;

public class LoginAlreadyTaken extends Exception {
}
