package summative.carrental.model.rents;

import javax.persistence.Entity;

@Entity
public class RentRequest extends AbstractRent {
}
