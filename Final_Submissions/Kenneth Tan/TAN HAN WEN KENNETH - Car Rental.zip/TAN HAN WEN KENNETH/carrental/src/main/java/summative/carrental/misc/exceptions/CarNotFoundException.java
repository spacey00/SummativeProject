package summative.carrental.misc.exceptions;

public class CarNotFoundException extends Exception {
}
