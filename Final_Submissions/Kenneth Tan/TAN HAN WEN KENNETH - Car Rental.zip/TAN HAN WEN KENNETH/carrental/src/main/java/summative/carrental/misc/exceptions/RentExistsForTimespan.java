package summative.carrental.misc.exceptions;

public class RentExistsForTimespan extends Exception {
}
