package summative.carrental.services;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import summative.carrental.misc.exceptions.EmailAlreadyTaken;
import summative.carrental.misc.exceptions.LoginAlreadyTaken;
import summative.carrental.model.users.SystemUser;

import java.util.List;

public interface SystemUserService extends UserDetailsService {
    @Override
    UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException;

    void createStandardUser(SystemUser user) throws EmailAlreadyTaken, LoginAlreadyTaken;

    List<SystemUser> getAllUsers();

    void enableUser(Long id);

    void disableUser(Long id);
}
