package summative.carrental.model.cars;

public enum  CarType {
    SMALL, MEDIUM, LARGE, KOMBI, PREMIUM, FAMILY, SUV
}
