var initStats = function (days) {
    $.get('/admin/stats/rentRequests/' + days, function (data, status) {
        const labels = data.labels;
        const elements = data.data;
        var ctx = document.getElementById('rentRequests');
        var firstChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Rental requests of previous week',
                    data: elements,
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    });

    $.get('/admin/stats/rents/' + days, function (data, status) {
        const labels = data.labels;
        const elements = data.data;
        var ctx = document.getElementById('rents');
        var secondChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Rentals of previous week',
                    data: elements,
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    });
};