package ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import ntuc.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	
	/* return user with username, must ensure that username is unique */
	@Query("SELECT u FROM User u" + " WHERE u.username = :ustr") 
	public User findUserByUsername(@Param("ustr") String ustr);
	
	
	}
