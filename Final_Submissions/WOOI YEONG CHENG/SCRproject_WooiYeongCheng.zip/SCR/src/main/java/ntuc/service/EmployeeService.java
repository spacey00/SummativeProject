package ntuc.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import ntuc.model.Hire;
import ntuc.model.Vehicle;
import ntuc.model.VehicleHire;
import ntuc.model.VehicleType.VehicleCatagory;
import ntuc.model.VehicleType;
import ntuc.repository.HireRepository;
import ntuc.repository.VehicleRepository;
import ntuc.repository.VehicleTypeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private VehicleRepository VHrepo;
	@Autowired
	private VehicleTypeRepository VTyperepo;
	@Autowired
	private HireRepository Hrepo;
	
	public void collateData(Model model, List<VehicleHire> ClistVH, String viewOpt) 
	{
		Integer tcorSales = 0, hcitSales = 0, m3Sales = 0, mcouSales = 0, talpSales = 0, hfreSales = 0;
		Integer m5Sales = 0, lambSales = 0, travSales = 0, hcrvSales = 0, mcx5Sales = 0, bgtcSales = 0;
		List<Integer> sedanSales = Arrays.asList(0, 0, 0);
		List<Integer> suvSales = Arrays.asList(0, 0, 0);
		List<Integer> mpvSales = Arrays.asList(0, 0, 0);
		List<Integer> luxSales = Arrays.asList(0, 0, 0);
		Integer csedanSales = 0;
		Integer csuvSales = 0;
		Integer cmpvSales = 0;
		Integer cluxSales = 0;
		
	for (int i = 0; i < ClistVH.size(); i++) 
		{
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Toyota Corolla"))
			tcorSales = tcorSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Honda City"))
			hcitSales = hcitSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Mazada 3"))
			m3Sales = m3Sales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Mercedes Coupe"))
			mcouSales = mcouSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Toyota Alphard"))
			talpSales = talpSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Honda Freed"))
			hfreSales = hfreSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Mazada 5"))
			m5Sales = m5Sales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Lamborghini"))
			lambSales = lambSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Toyota RAV"))
			travSales = travSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Honda CR-V"))
			hcrvSales = hcrvSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Mazada CX-5"))
			mcx5Sales = mcx5Sales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleModelName().equals("Bentley GT Coupe"))
			bgtcSales = bgtcSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());

		/* Check for vehicle Categories Sedan,SUV,MPV and LUX */
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleCatagory().equals(VehicleCatagory.SEDAN))
			csedanSales = csedanSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleCatagory().equals(VehicleCatagory.SUV))
			csuvSales = csuvSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleCatagory().equals(VehicleCatagory.MPV))
			cmpvSales = cmpvSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		if (ClistVH.get(i).getVehicle().getVehicleType().getVehicleCatagory().equals(VehicleCatagory.LUX))
			cluxSales = cluxSales + (ClistVH.get(i).getVehicle().getVehicleType().getPricing().intValue());
		}
	
	switch(viewOpt)
	{
	case "thismth":
	case "thisqtr":
	case "thisyr":	
		sedanSales.set(0, csedanSales);
		suvSales.set(0, csuvSales);
		mpvSales.set(0, cmpvSales);
		luxSales.set(0, cluxSales);
		break;
	case "lastmth":
	case "lastqtr":
	case "lastyr":	
		sedanSales.set(1, csedanSales);
		suvSales.set(1, csuvSales);
		mpvSales.set(1, cmpvSales);
		luxSales.set(1, cluxSales);
		break;
	case "2mthsago":
	case "2qtrsago":
	case "2yrsago":	
		sedanSales.set(2, csedanSales);
		suvSales.set(2, csuvSales);
		mpvSales.set(2, cmpvSales);
		luxSales.set(2, cluxSales);
		break;
	}
	// first, Vehicle Model Sales
			model.addAttribute("tcorSales", tcorSales);
			model.addAttribute("hcitSales", hcitSales);
			model.addAttribute("m3Sales", m3Sales);
			model.addAttribute("mcouSales", mcouSales);
			model.addAttribute("talpSales", talpSales);
			model.addAttribute("hfreSales", hfreSales);
			model.addAttribute("m5Sales", m5Sales);
			model.addAttribute("lambSales", lambSales);
			model.addAttribute("travSales", travSales);
			model.addAttribute("hcrvSales", hcrvSales);
			model.addAttribute("mcx5Sales", mcx5Sales);
			model.addAttribute("bgtcSales", bgtcSales);

			/* Vehicle Cat Sales */
			model.addAttribute("sedanSales", sedanSales);
			model.addAttribute("suvSales", suvSales);
			model.addAttribute("mpvSales", mpvSales);
			model.addAttribute("luxSales", luxSales);
	}

	
	
	
	
	public Page<Vehicle> listAllVeh(Integer pageNumber, String sortField, String sortDir, String keyword){
		System.out.println("empService line 32"+"|pageno: "+pageNumber+"| sortField: "+sortField+"| SortDir: "+sortDir+"| Keyword :"+keyword+" |");
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNumber-1, 15,sort);
		if(keyword!=null) {
			/* return VHrepo.findAll(keyword,pageable); */
		}
		System.out.println("empService line 39, going into HireRepo");
		/* return Hrepo.findAllNext(pageable); */
		return VHrepo.findAll(pageable);
			
	}
	
	
	  public void save(Vehicle vehicle) { VHrepo.save(vehicle); }
	  
	  public Vehicle get(Integer id) { return VHrepo.findVehiclesByVehicleId(id); }
	  
	  public void delete(Integer id) { VHrepo.deleteById(id); }
	  
	  public Vehicle getPlate(String plate) { return VHrepo.findVehiclesByPlateNo(plate);}
	  
//----------------------------- for VehicleType ----------------------------------
	  public Page<VehicleType> listAllVehType(Integer pageNumber, String sortField, String sortDir, String keyword){
			System.out.println("empService line 32"+"|pageno: "+pageNumber+"| sortField: "+sortField+"| SortDir: "+sortDir+"| Keyword :"+keyword+" |");
			Sort sort = Sort.by(sortField);
			sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
			Pageable pageable = PageRequest.of(pageNumber-1, 15,sort);
			if(keyword!=null) {
				/* return VHrepo.findAll(keyword,pageable); */
			}
			System.out.println("empService line 39, going into HireRepo");
			/* return Hrepo.findAllNext(pageable); */
			return VTyperepo.findAll(pageable);
				
		}
		
	  /* for VehicleType */
		  public void saveVT(VehicleType vehicleType) { VTyperepo.save(vehicleType); }
		  
		  public VehicleType getVT(Integer id) { return VTyperepo.findByVehicleId(id); }
		  
		  public void deleteVT(Integer id) { VTyperepo.deleteById(id); }

//-----------------------------------------
		  public Page<Hire> listAll(Integer pageNumber, String sortField, String sortDir, String keyword){
				//System.out.println("empService line 32"+"|pageno: "+pageNumber+"| sortField: "+sortField+"| SortDir: "+sortDir+"| Keyword :"+keyword+" |");
				Sort sort = Sort.by(sortField);
				sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
				Pageable pageable = PageRequest.of(pageNumber-1, 15,sort);
				if(keyword!=null) {
					return Hrepo.findAll(keyword,pageable);
				}
				//System.out.println("empService line 39, going into HireRepo");
				/* return Hrepo.findAllNext(pageable); */
				return Hrepo.findAll(pageable);
					
			}
			
			
			  public void saveH(Hire hire) { Hrepo.save(hire); }
			  
			  public Hire getH(Integer id) { return Hrepo.findById(id).get(); }
			  
			  public void deleteH(Integer id) { Hrepo.deleteById(id); }
					  
			  public List<Hire> findABIN(String invNo) {return Hrepo.findAllbyInvoiceNo(invNo);}
}
