package ntuc.model;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "customers")
public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "customer_id")
	private Integer customerId;

	@Column(name = "name", nullable = false) 
	private String name;

	@Column(name = "address", nullable = false)
	private String address;

	@Column(name = "phone", nullable = false)
	private String phone;

	@Column(name = "email", nullable = false)
	private String email;

	@Column(name = "office_no")
	private String officeNo;

	@Column(name = "website")
	private String website;

	@Column(name = "driver_license_no", nullable = false, unique = true)
	private String driverLicenseNo;

	@Embedded
	@AttributeOverrides({
		@AttributeOverride(name = "name", column = @Column(name = "alt_name")),
		@AttributeOverride(name = "address", column = @Column(name = "alt_address")),
		@AttributeOverride(name = "email", column = @Column(name = "alt_email")),
		@AttributeOverride(name = "phone", column = @Column(name = "alt_phone"))})
	private CustomerAlternateContact customerAlternateContact;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "user_id")
	private User user;

	public Customer() {
	}

	public Customer(Integer customerId, String name, String address, String phone, String email, String officeNo,
			String website, String driverLicenseNo, CustomerAlternateContact customerAlternateContact, User user) {
		this.customerId = customerId;
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.officeNo = officeNo;
		this.website = website;
		this.driverLicenseNo = driverLicenseNo;
		this.customerAlternateContact = customerAlternateContact;
		this.user = user;
	}


	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOfficeNo() {
		return officeNo;
	}

	public void setOfficeNo(String officeNo) {
		this.officeNo = officeNo;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getDriverLicenseNo() {
		return driverLicenseNo;
	}

	public void setDriverLicenseNo(String driverLicenseNo) {
		this.driverLicenseNo = driverLicenseNo;
	}

	public CustomerAlternateContact getCustomerAlternateContact() {
		return customerAlternateContact;
	}

	public void setCustomerAlternateContact(CustomerAlternateContact customerAlternateContact) {
		this.customerAlternateContact = customerAlternateContact;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((customerAlternateContact == null) ? 0 : customerAlternateContact.hashCode());
		result = prime * result + ((customerId == null) ? 0 : customerId.hashCode());
		result = prime * result + ((driverLicenseNo == null) ? 0 : driverLicenseNo.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((officeNo == null) ? 0 : officeNo.hashCode());
		result = prime * result + ((phone == null) ? 0 : phone.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		result = prime * result + ((website == null) ? 0 : website.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (customerAlternateContact == null) {
			if (other.customerAlternateContact != null)
				return false;
		} else if (!customerAlternateContact.equals(other.customerAlternateContact))
			return false;
		if (customerId == null) {
			if (other.customerId != null)
				return false;
		} else if (!customerId.equals(other.customerId))
			return false;
		if (driverLicenseNo == null) {
			if (other.driverLicenseNo != null)
				return false;
		} else if (!driverLicenseNo.equals(other.driverLicenseNo))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (officeNo == null) {
			if (other.officeNo != null)
				return false;
		} else if (!officeNo.equals(other.officeNo))
			return false;
		if (phone == null) {
			if (other.phone != null)
				return false;
		} else if (!phone.equals(other.phone))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		if (website == null) {
			if (other.website != null)
				return false;
		} else if (!website.equals(other.website))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Customer [address=" + address + ", customerAlternateContact=" + customerAlternateContact
				+ ", customerId=" + customerId + ", driverLicenseNo=" + driverLicenseNo + ", email=" + email + ", name="
				+ name + ", officeNo=" + officeNo + ", phone=" + phone + ", user=" + user + ", website=" + website
				+ "]";
	}

}
