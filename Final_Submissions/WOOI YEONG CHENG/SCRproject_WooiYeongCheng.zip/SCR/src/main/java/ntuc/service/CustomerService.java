package ntuc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import ntuc.model.Customer;
import ntuc.model.Role;
import ntuc.model.User;
import ntuc.repository.CustomerRepository;
import ntuc.repository.RoleRepository;
import ntuc.repository.UserRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository custRepo;
	
	@Autowired
	RoleRepository roleRepo;
	
	@Autowired
	UserRepository userRepo;
	
	public void custSave(User user) {
		userRepo.save(user);
	}
	
	public void custSave(Customer customer) {
		custRepo.save(customer);
	}
	
	public String saveCusUser(String username, String password, String yrname, String email, String telno, 
			String officephone, String address, String website, String drvlicense) 
	{
		/* save user then save to customer table */
	
		Customer cust = new Customer();
		User user = new User();

		BCryptPasswordEncoder ecd = new BCryptPasswordEncoder();
		
		Role test = (Role) roleRepo.findIdByRoleName("customer");
		//System.out.println(test);

		user.setUsername(username);
		user.setPassword(ecd.encode(password));
		user.setEnabled(true);
		user.addRole(test);
		//System.out.println(user);
		custSave(user);

		cust.setName(yrname);
		cust.setAddress(address);
		cust.setPhone(telno);
		cust.setEmail(email);
		cust.setOfficeNo(officephone);
		cust.setWebsite(website);
		cust.setDriverLicenseNo(drvlicense);
		cust.setUser(user);
		//System.out.println(cust);
		custSave(cust);
		

		
		return "true";
		
	}


}
