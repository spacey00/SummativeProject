package ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import ntuc.model.Customer;
import ntuc.model.User;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	/* return customer id from user Id */
	@Query("SELECT c FROM Customer c" + " WHERE c.user = :usr") 
	public Customer findCustomerByUserId(@Param("usr") User user);

	@Query("SELECT c FROM Customer c" + " WHERE c.customerId = :cid") 
	public Customer findCustomerByCustomerId(@Param("cid") Integer cid);
}
