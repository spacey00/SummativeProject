package ntuc.service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.servlet.http.HttpSession;
import java.time.temporal.ChronoUnit;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import ntuc.model.Vehicle;
import ntuc.model.VehicleType;
import ntuc.model.VehicleType.VehicleCatagory;
import ntuc.repository.VehicleRepository;
import ntuc.repository.HireRepository;

@Service
public class HireService {
	
	@Autowired
	VehicleRepository vehicleRepo;
	
	@Autowired
	HireRepository Hrepo;

	public List<Vehicle> initdisplay(String Cat)
	{
		VehicleType vehS1 = new VehicleType();
		
		switch (Cat) {

		  case "SEDAN":
			  vehS1.setVehicleCatagory(VehicleCatagory.SEDAN);
		    break;
		  
		  case "SUV":
			  vehS1.setVehicleCatagory(VehicleCatagory.SUV);
		    break;
		  
		  case "MPV":
			  vehS1.setVehicleCatagory(VehicleCatagory.MPV);
		    break;
		  
		  case "LUX":
			  vehS1.setVehicleCatagory(VehicleCatagory.LUX);
		    break;  
		    
		  default:
		    // default statements
		  }
		
		/* //System.out.println(vehS1.toString()); */
		List<Vehicle> listVehicle = vehicleRepo.findVehiclesByCat(vehS1.getVehicleCatagory());

		/* //System.out.println(listVehicle.size()); */
		//System.out.println("Vehicle available: " + listVehicle);

		return listVehicle;
	}
	
	public String checklistveh(List<Vehicle> listVehicle, HttpSession session) 
	{
		
		if (listVehicle.size() == 0) 
		{
			String message = "The vehicle model selected is unavailable with these dates. Please click back or Home button to try again... ";
			session.setAttribute(message, message);
			return "index"; 
		}
		return "true";
	}
	
	
	public List<LocalDate> initdates() 
	{
	LocalDate Datefr = LocalDate.now();
	LocalDate Dateto = LocalDate.now();
	
	List<LocalDate> dates = Stream.iterate(Datefr, date -> date.plusDays(1))
		    .limit(ChronoUnit.DAYS.between(Datefr, Dateto)+1)
		    .collect(Collectors.toList());
	//System.out.println("line 78 - dates-----: " + dates );
	return dates;
	
	}	
	
	
	
}

