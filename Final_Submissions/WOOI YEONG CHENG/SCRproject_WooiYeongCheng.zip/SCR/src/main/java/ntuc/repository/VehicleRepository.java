package ntuc.repository;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import ntuc.model.Vehicle;
import ntuc.model.VehicleType.VehicleCatagory;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Integer> {

		@Query("SELECT v FROM Vehicle v" 
			   + " WHERE v.vehicleId NOT IN"
			   + " (SELECT DISTINCT i.vehicle FROM VehicleHire i WHERE i.day IN (:dates))")
		public List<Vehicle> findVehicleByDate(List<LocalDate> dates);
	
	
		@Query("SELECT v FROM Vehicle v" 
			  + " JOIN v.vehicleType vt" 
			  + " WHERE vt.vehicleCatagory = :cat AND v.vehicleId NOT IN"  
			  + " (SELECT DISTINCT vh.vehicle FROM VehicleHire vh WHERE vh.day IN (:dates))")
		public List<Vehicle> findVehicleByVehicleCatagoryAndDate(
			VehicleCatagory cat, List<LocalDate> dates);
	
	
		@Query("SELECT v FROM Vehicle v" + " JOIN v.vehicleType vh" +
				" WHERE vh.vehicleCatagory = :cat") public List<Vehicle>
		findVehiclesByCat(@Param("cat") VehicleCatagory cat);
	  
	  
		@Query("SELECT v FROM Vehicle v" + " WHERE v.vehiclePlateNo = :cnum") 
		public Vehicle findVehiclesByPlateNo(@Param("cnum") String cnum);
	 
		@Query("SELECT v FROM Vehicle v" + " WHERE v.vehicleId = :vid") 
		public Vehicle findVehiclesByVehicleId(@Param("vid") Integer vid);
		
		@Query("SELECT v FROM Vehicle v" 
				  + " JOIN v.vehicleType vt" 
				  + " WHERE vt.vehicleModelName = :cmodel AND v.vehicleId NOT IN" 
				  + " (SELECT DISTINCT vh.vehicle FROM VehicleHire vh WHERE vh.day IN (:dates))")  
			public List<Vehicle> findVehicleByVehicleModelNameAndDate(
				String cmodel, List<LocalDate> dates);
		
		@Query("SELECT v FROM Vehicle v" 
				  + " JOIN v.vehicleType vt" 
				  + " WHERE v.vehiclePlateNo= :cplate AND v.vehicleId NOT IN" 
				  + " (SELECT DISTINCT vh.vehicle FROM VehicleHire vh WHERE vh.day IN (:dates))")
			public Vehicle findVehicleByPlateNoAndDate(
				String cplate, List<LocalDate> dates);
		
		@Query("SELECT v FROM Vehicle v" 
				  + " JOIN v.vehicleType vt" 
				  + " WHERE vt.vehicleModelName = :cmodel")
			public List<Vehicle> findVehicleByVehicleModelName(
				String cmodel);
		
		@Query("SELECT v FROM Vehicle v" 
				  + " JOIN v.vehicleType vt" 
				  + " WHERE CONCAT(v.vehiclePlateNo, vt.pricing, vt.vehicleBrandName, vt.vehicleCatagory, vt.vehicleModelName)"
				  + " LIKE %?1%")  
			public List<Vehicle> findAll(String kword, Pageable pageable);
		
		@Query("SELECT v FROM Vehicle v" 
				  + " JOIN v.vehicleType vt" 
				  + " WHERE CONCAT(v.vehiclePlateNo, vt.pricing, vt.vehicleBrandName, vt.vehicleCatagory, vt.vehicleModelName)"
				  + " LIKE %?1%")  
			public List<Vehicle> findAllSearch(String kword);
}
