package ntuc.service;
import java.awt.Color;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import ntuc.model.VehicleHire;
import ntuc.model.Hire;
import ntuc.model.Customer;
import javax.servlet.http.HttpServletResponse;

import java.time.LocalDate;
 
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
 
 
public class UserPDFExporter {
	private List<Hire> listhire;
    private List<VehicleHire> listVH;
    private Customer custlist;
    
    
    public UserPDFExporter(List<VehicleHire> listVH, List<Hire> listhire, Customer custlist ) {
        this.listVH = listVH;
        this.listhire = listhire;
        this.custlist = custlist;
    }
 
    
     
    private void writeTableHeader(PdfPTable table) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(Color.DARK_GRAY);
        cell.setPadding(5);
         
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.WHITE);
         
		
		cell.setPhrase(new Phrase("Rental Date", font)); 
		table.addCell(cell);
		  
		cell.setPhrase(new Phrase("Brand", font)); 
		table.addCell(cell);
		  
        cell.setPhrase(new Phrase("Plate No", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Model Name", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Pricing per Day", font));
        table.addCell(cell); 
        
    }
     
    private void writeTableData(PdfPTable table) {
        for (VehicleHire vh : listVH) {
			
			table.addCell(String.valueOf(vh.getDay()));
			table.addCell(vh.getVehicle().getVehicleType().getVehicleBrandName()); 
            table.addCell(vh.getVehicle().getVehiclePlateNo());
            table.addCell(vh.getVehicle().getVehicleType().getVehicleModelName());
            table.addCell(String.valueOf(vh.getVehicle().getVehicleType().getPricing()));
            }
    }
     
    public void export(HttpServletResponse response) throws DocumentException, IOException {
        String invNo = listhire.get(0).getInvoiceNo();
        LocalDate invDate = listhire.get(0).getInvoiceDate();
        Integer days = listhire.size();
        BigDecimal pricing = listVH.get(0).getVehicle().getVehicleType().getPricing();
        String usrnam = listVH.get(0).getHire().getCustomer().getUser().getUsername();
        
        BigDecimal Totaldue = pricing.multiply(BigDecimal.valueOf(days));
        
        NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.US);
        String Finaldue = nf.format(Totaldue);
        
        String name = custlist.getName();
        String address = custlist.getAddress();
        String email = custlist.getEmail();
        String office = custlist.getOfficeNo();
        String phone = custlist.getPhone();
        
    	Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, response.getOutputStream());
         
        document.open();
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setSize(18);
        font.setColor(Color.BLUE);
        Paragraph o = new Paragraph("Simon Car Rental Pte Ltd"
				+"\n\n", font);
        o.setAlignment(Paragraph.ALIGN_CENTER); 
        
        document.add(o);
        
        font.setSize(12);
        font.setColor(Color.BLACK);
        Paragraph p = new Paragraph("Tax Invoice"+"\n"
        							+"Username : "+usrnam+ "\n"
        							+"Invoice No: "+invNo+ "\n"
        							+"Invoice Date: " +invDate+"\n"
        							+"Total Due: "+Finaldue+"\n"
        							+"Credit Terms: 14 Days "
        							+"\n\n", font);
        p.setAlignment(Paragraph.ALIGN_RIGHT); 
        document.add(p);
        
        font.setSize(12);
        Paragraph q = new Paragraph("Attention to Mr/Ms: "+name
				+"\n"
				+"Address: "+address+ "\n"
				+"Email: " +email +"\n"
				+"Office Tel: " +office +"\n"
				+"Phone: " +phone +"\n\n", font);
        q.setAlignment(Paragraph.ALIGN_LEFT);

        document.add(q);
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100f);
        table.setWidths(new float[] {2.5f, 2.5f, 2.0f, 4.0f, 1.5f});
        table.setSpacingBefore(10);
        
        writeTableHeader(table);
        writeTableData(table);
         
        document.add(table);
        
        font.setSize(12);
        Paragraph r = new Paragraph("\n\n\n\n\n "
				+"________________________________________________________"+"\n"
				+"Computer generated invoice. No signature required." +"\n"
				, font);
        r.setAlignment(Paragraph.ALIGN_LEFT);

        document.add(r);
        
        document.close();
         
    }
    
}