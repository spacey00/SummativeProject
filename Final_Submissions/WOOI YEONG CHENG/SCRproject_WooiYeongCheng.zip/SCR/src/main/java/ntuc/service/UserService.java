package ntuc.service;

import ntuc.model.Role;
import ntuc.model.User;
import ntuc.model.Employee;
import ntuc.repository.RoleRepository;
import ntuc.repository.UserRepository;
import ntuc.repository.EmployeeRepository;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Service
public class UserService {

	@Autowired
	EmployeeRepository empRepo;
	@Autowired
	UserRepository userRepo;
	@Autowired
	RoleRepository roleRepo;
	
	public void empSave(Employee employee) { empRepo.save(employee); }

	public void userSave(User user) { userRepo.save(user); }

	public void roleSave(Role role) { roleRepo.save(role); }

	public String saveEmpUser(String username, String password, String email, String name, String roles, String phone, String jobTitle) 
	{
		/*Check that the username is unique */
		User user1 = userRepo.findUserByUsername(username);
		//System.out.println("user1 data :"+user1);
		
		if (user1==null) 
		{
			/*username not taken yet */
		Employee emp = new Employee();
		User user = new User();

		BCryptPasswordEncoder ecd = new BCryptPasswordEncoder();
		
		Role test = (Role) roleRepo.findIdByRoleName(roles);
		//System.out.println(test);

		user.setUsername(username);
		user.setPassword(ecd.encode(password));
		user.setEnabled(true);
		user.addRole(test);
		//System.out.println(user);
		userSave(user);

		emp.setEmail(email);
		emp.setJobTitle(jobTitle);
		emp.setName(name);
		emp.setPhone(phone);
		emp.setUser(user);
		//System.out.println(emp);
		empSave(emp);
		
		return "true";
		}
		
		return "false"; 
	}

	public Boolean authUserPwd(String username, String password) {
		
		User user = userRepo.findUserByUsername(username);
		BCryptPasswordEncoder ecd = new BCryptPasswordEncoder();
		
		Boolean isPwdCorrect =  ecd.matches(password, user.getPassword());  
		//System.out.println("isPwdCorrect: "+isPwdCorrect);
		return isPwdCorrect;

	}
	
}
