jQuery(document).ready(function() {
 jQuery("[required]").after("<span class='required'>*</span>");
});