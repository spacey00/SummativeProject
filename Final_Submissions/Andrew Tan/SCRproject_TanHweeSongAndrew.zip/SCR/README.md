# SimonCR - Simon Car Rental Project for graduating cohort2 of NTUC LHUB (21 Oct 2020 to 8 July 2021)
FIVE BOYS - (In alphabetical order) : Andrew Tan, Andy Yong, Desmond Ang, Ken Wooi, Phang Kang Cheng
