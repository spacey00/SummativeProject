package ntuc.controller;

import java.time.LocalDate;
import java.time.temporal.IsoFields;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.math.BigDecimal;
import static java.time.temporal.IsoFields.QUARTER_OF_YEAR;
import java.io.IOException;
import java.time.*;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.dom4j.DocumentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import ntuc.model.Customer;
import ntuc.model.Hire;
import ntuc.model.Role;
import ntuc.model.Vehicle;
import ntuc.model.VehicleHire;
import ntuc.model.VehicleType;
import ntuc.model.VehicleType.VehicleCatagory;
import ntuc.repository.CustomerRepository;
import ntuc.repository.RoleRepository;
import ntuc.repository.VehicleHireRepository;
import ntuc.repository.VehicleTypeRepository;
import ntuc.service.EmployeeService;
import ntuc.service.UserPDFExporter;

@Controller
public class EmployeeController {

	@Autowired
	VehicleHireRepository VHRepo;
	@Autowired
	EmployeeService EmpServ;
	@Autowired
	VehicleTypeRepository VHTRepo;
	@Autowired
	RoleRepository roleRepo;
	@Autowired
	CustomerRepository custRepo;

	// ---------------------------------- add Employee
	@GetMapping("/addEmployee")
	public String addEmployee(Model model) {
		// System.out.println("In the addEmployee module");

		List<Role> roles = roleRepo.findAll();
		// for (int i=0; i<roles.size(); i++) {
		// System.out.println("Data inside roles - Name: "+roles.get(i).getName()+" id :
		// "+roles.get(i).getId());
		// }
		model.addAttribute("Role", roles);
		return "addUser";
	}

	// ---------------------------------- add Vehicle
	@RequestMapping("/addVehicle{urole}")
	public String VehicleDisplay(Model model, @PathVariable("urole") String urole, HttpSession session) {
		session.getAttribute(urole);
		// System.out.println("addVeh urole value:"+urole+"\n");

		String keyword = null;
		session.setAttribute("urole", urole);
		return listByVehPage(model, 1, "vehicleId", "asc", keyword);
	}

	@RequestMapping("/VehDelete/{veh.vehicleId}")
	public String VehicleDeleteDisplay(Model model, @PathVariable("veh.vehicleId") Integer vid,
			@Param("veh.currentPage") Integer currentPage) {

		String keyword = null;
		EmpServ.delete(vid);
		return listByVehPage(model, currentPage, "vehicleId", "asc", keyword);
	}

	@RequestMapping("/VehEdit/{veh.vehicleId}")
	public String VehicleEditDisplay(Model model, @PathVariable("veh.vehicleId") Integer vid,
			@Param("veh.currentPage") Integer currentPage, @Param("veh.photos") String photos,
			@Param("veh.vehiclePlateNo") String plate, @Param("veh.vehicleStatus") String status,
			@Param("veh.vehicleType.vehicleId") String VTvid) {
		String keyword = null;
		// System.out.println("|cPg: "+currentPage+"|photos: "+photos+"| plate:
		// "+plate+"| status: "+status+"|VTvid: "+VTvid+"| \n");

		model.addAttribute("vehId", vid);
		model.addAttribute("vehFoto", photos);
		model.addAttribute("vehPlateNo", plate);
		model.addAttribute("vehStatus", status);
		model.addAttribute("vehTypeId", VTvid);
		return listByVehPage(model, currentPage, "vehicleId", "asc", keyword);
	}

	@GetMapping("/addVehPage/{pageNumber}")
	public String listByVehPage(Model model, @PathVariable("pageNumber") Integer currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword) {
		// System.out.println("listByVehPage");
		Page<Vehicle> page = EmpServ.listAllVeh(currentPage, sortField, sortDir, keyword);
		// System.out.println("listByVehPage return from Page<Hire>");
		Long totalItems = page.getTotalElements();
		Integer totalPages = page.getTotalPages();
		// System.out.println("totalitem :"+totalItems+"\n");
		// System.out.println("totalpages : "+totalPages+"\n");

		List<Vehicle> vehlist = page.getContent();
		// System.out.println("line 324 page content
		// tostring"+page.getContent().toString()+"\n");

		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("vehlist", vehlist);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);

		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);

		// System.out.println("listByVehPage working well...");

		return "addvehicle";
	}

	@RequestMapping("/VehAddorEditVeh/{pageNumber}")
	public String VehAddorEditMode(Model model, @PathVariable("pageNumber") Integer currentPage,
			@Param("sortField") String sortField, @Param("vehId") Integer vehId, @Param("vehFoto") String vehFoto,
			@Param("vehPlateNo") String vehPlateNo, @Param("vehStatus") String vehStatus,
			@Param("vehTypeId") Integer vehTypeId, @Param(value = "action") String action) {

		// System.out.println("|cPg: " + currentPage + "|photos: " + vehFoto + "| plate:
		// " + vehPlateNo
		// + "| Status: " + vehStatus + "|VTvid: " + vehTypeId + "| \n");
		// Add Vehicle mode
		Vehicle Veh1 = new Vehicle();
		Vehicle Veh2 = new Vehicle();

		if (action.equals("add")) {
			// System.out.println("vehicle Add Mode");

			Veh1.setVehicleId(0); // new vehicle id will auto generate
			if (EmpServ.getPlate(vehPlateNo) != null) { // null is unique, not null plate already used
				String keyword = null;
				return listByVehPage(model, currentPage, "vehicleId", "asc", keyword);// not valid, return
			}
			Veh1.setVehiclePlateNo(vehPlateNo);// plate no must be unique
		}

		if (action.equals("edit")) {
			// System.out.println("vehicle Edit Mode");
			// use the old Vehicle Id, cannot change
			if (EmpServ.get(vehId) == null) { // check vehicleId is valid first
				String keyword = null;
				return listByVehPage(model, currentPage, "vehicleId", "asc", keyword);// not valid, return
			}

			Veh1 = EmpServ.get(vehId);// vehId is in database

			if (EmpServ.getPlate(vehPlateNo) == null) { // new platenumber detected
				// do nothing
			} else {
				Veh2 = EmpServ.getPlate(vehPlateNo);
				if (Veh1.getVehicleId() != Veh2.getVehicleId()) {
					String keyword = null;
					return listByVehPage(model, currentPage, "vehicleId", "asc", keyword);// not valid, return
				}
			} // end of else

			Veh1.setVehiclePlateNo(vehPlateNo);

		}

		if (EmpServ.getVT(vehTypeId) == null) {// null is out of scope
			String keyword = null;
			return listByVehPage(model, currentPage, "vehicleId", "asc", keyword);// not valid, return
		}
		VehicleType VT1 = EmpServ.getVT(vehTypeId);// vehType cannot be out of scope for edit & add
		Veh1.setPhotos(vehFoto);

		Veh1.setVehicleStatus(vehStatus);
		Veh1.setVehicleType(VT1);

		// System.out.println("add Vehicle Veh1 " + Veh1.toString());

		EmpServ.save(Veh1);

		String keyword = null;
		return listByVehPage(model, currentPage, "vehicleId", "asc", keyword);
	}

	// ----------------------------------------- add vehicleType
	@RequestMapping("/addVehicleType{urole}")
	public String VehicleTypeDisplay(Model model, @PathVariable("urole") String urole, HttpSession session) {
		session.getAttribute(urole);
		// System.out.println("add VehicleType urole value:"+urole+"\n");

		String keyword = null;
		session.setAttribute("urole", urole);
		return listByVehTypePage(model, 1, "vehicleId", "asc", keyword);
	}

	@RequestMapping("/VehTypeDelete/{veh.vehicleId}")
	public String VehicleTypeDeleteDisplay(Model model, @PathVariable("veh.vehicleId") Integer vid,
			@Param("veh.currentPage") Integer currentPage) {

		String keyword = null;
		EmpServ.deleteVT(vid);
		return listByVehTypePage(model, currentPage, "vehicleId", "asc", keyword);
	}

	@RequestMapping("/VehTypeEdit/{veh.vehicleId}")
	public String VehicleTypeEditDisplay(Model model, @PathVariable("veh.vehicleId") Integer vid,
			@Param("veh.currentPage") Integer currentPage, @Param("veh.vehPricing") String pricing,
			@Param("veh.vehBrandName") String brand, @Param("veh.vehCat") String category,
			@Param("veh.vehModelName") String mdel) {
		String keyword = null;
		// System.out.println("|cPg: "+currentPage+"|vpricing: "+pricing+"| vbrand:
		// "+brand+"| vCat: "+category+"|VMdl: "+mdel+"| \n");

		model.addAttribute("vehId", vid);
		model.addAttribute("vehPricing", pricing);
		model.addAttribute("vehBrandName", brand);
		model.addAttribute("vehCat", category);
		model.addAttribute("vehModelName", mdel);
		return listByVehTypePage(model, currentPage, "vehicleId", "asc", keyword);
	}

	@GetMapping("/addVehTypePage/{pageNumber}")
	public String listByVehTypePage(Model model, @PathVariable("pageNumber") Integer currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword) {
		// System.out.println("Employee controller - line 388");
		Page<VehicleType> page = EmpServ.listAllVehType(currentPage, sortField, sortDir, keyword);
		// System.out.println("line 390 return from Page<Hire>");
		Long totalItems = page.getTotalElements();
		Integer totalPages = page.getTotalPages();
		// System.out.println("totalitem :"+totalItems+"\n");
		// System.out.println("totalpages : "+totalPages+"\n");

		List<VehicleType> vehlist = page.getContent();
		// System.out.println("line 398 page content
		// tostring"+page.getContent().toString()+"\n");

		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("vehlist", vehlist);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);

		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);

		// System.out.println("listByVehTypePage working well...");

		return "addvehicleType";
	}

	@RequestMapping("/VehTypeAddorEdit/{pageNumber}")
	public String VTAddorEditMode(Model model, @PathVariable("pageNumber") Integer currentPage,
			@Param("sortField") String sortField, @Param("vehId") Integer vehId, @Param("vehPricing") String vehPricing,
			@Param("vehBrandName") String vehBrandName, @Param("vehCat") String vehCat,
			@Param("vehModelName") String vehModelName, @Param(value = "action") String action) {
		// System.out.println("Data from Vehtype- |pno" + currentPage + "|sf: " +
		// sortField + "|vid: " + vehId
		// + "|Pricing: " + vehPricing + "|Brand: " + vehBrandName + "|Cat: " + vehCat +
		// "|model: "
		// + vehModelName + "| act: " + action + "\n");

		VehicleType VHT = new VehicleType();

		if (action.equals("add")) {
			// System.out.println("vehicle add Mode");
			VHT.setVehicleId(0); // VehicleId auto create
		}

		if (action.equals("edit")) {
			// System.out.println("vehicle Edit Mode");

			if (VHTRepo.findByVehicleId(vehId) == null) { // check vehicleId is valid first
				String keyword = null;
				return listByVehTypePage(model, currentPage, "vehicleId", "asc", keyword);// not valid, return
			}
			VHT.setVehicleId(vehId);
		}

		if (vehCat.equals("SEDAN") || vehCat.equals("SUV") || vehCat.equals("MPV") || vehCat.equals("LUX")) {

			VHT.setPricing(new BigDecimal(vehPricing));
			VHT.setVehicleBrandName(vehBrandName);

			switch (vehCat) {

			case "SEDAN":
				VHT.setVehicleCatagory(VehicleCatagory.SEDAN);
				break;
			case "SUV":
				VHT.setVehicleCatagory(VehicleCatagory.SUV);
				break;
			case "MPV":
				VHT.setVehicleCatagory(VehicleCatagory.MPV);
				break;
			case "LUX":
				VHT.setVehicleCatagory(VehicleCatagory.LUX);
				break;
			}

			VHT.setVehicleModelName(vehModelName);
			EmpServ.saveVT(VHT);
		}

		String keyword = null;
		return listByVehTypePage(model, currentPage, "vehicleId", "asc", keyword);

	}

	// --------------------- Accounts ----------------------------------------------
	@GetMapping("/Accounts")
	public String viewDashBPage(Model model) {
		String keyword = null;
		return listByInvPage(model, 1, "hireId", "asc", keyword);
	}

	@GetMapping("/page/{pageNumber}")
	public String listByInvPage(Model model, @PathVariable("pageNumber") Integer currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword) {

		// System.out.println("listByInvPage "+"\n");
		Page<Hire> page = EmpServ.listAll(currentPage, sortField, sortDir, keyword);

		Long totalItems = page.getTotalElements();
		Integer totalPages = page.getTotalPages();
		// System.out.println("totalitem :" + totalItems + "\n"+"totalpages : " +
		// totalPages + "\n");

		List<Hire> hirelist = page.getContent();
		// System.out.println("listByInvPage-> content tostring" +
		// page.getContent().toString() + "\n");

		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("hirelist", hirelist);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);

		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "accounts";
	}

	@GetMapping("/InvoicePaid/{invoiceNo}")
	public String ToggleInvoicePaid(Model model, @PathVariable("invoiceNo") String invNo,
			@Param("currentPage") Integer currentPage) {
		// System.out.println("| Toggle Invoice -invoiceno: " + invNo + "|
		// \n"+"currentPage" + currentPage+"\n");

		/* write code to set invoiceno to paid and return to display */
		List<Hire> hpaid = EmpServ.findABIN(invNo);
		// System.out.println("content of hpaid" + hpaid+ "hpaid size()" +
		// hpaid.size());

		for (int i = 0; i < hpaid.size(); i++) {
			hpaid.get(i).setPaid(true);
			EmpServ.saveH(hpaid.get(i));
		}

		return listByInvPage(model, currentPage, "hireId", "asc", null);
	}

	@GetMapping("/InvoiceCreate/{invoiceNo}")
	public String AcctsInvoiceCreate(Model model, @PathVariable("invoiceNo") String invNo,
			@Param("currentPage") Integer currentPage, HttpServletResponse response)
			throws DocumentException, IOException {
		// System.out.println("| Accts Invoice Creation -invoiceno: " + invNo + "| \n");
		/* write code to set invoiceno to paid and return to display */
		response.setContentType("application/pdf");

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=users_" + invNo + ".pdf";
		response.setHeader(headerKey, headerValue);

		List<Hire> hre = EmpServ.findABIN(invNo);
		Integer maxhireId = hre.get(hre.size() - 1).getHireId();
		Customer c1 = custRepo.findCustomerByCustomerId(hre.get(0).getCustomer().getCustomerId());

		List<VehicleHire> listVH = VHRepo.findVehicleHireByHId(maxhireId);

		UserPDFExporter exporter = new UserPDFExporter(listVH, hre, c1);
		exporter.export(response);

		return listByInvPage(model, currentPage, "hireId", "asc", null);
	}

//	----------------------------------------- dashboard ------------------------------------------------------------------
// --------------------------select by mth	
public String chart(Model model, @Param("viewOpt") String viewOpt) {

		YearMonth Tmth = YearMonth.now();
		LocalDate endTmth = LocalDate.now();
		LocalDate startTmth = Tmth.atDay(1);

		YearMonth Lmth = Tmth.minusMonths(1);
		LocalDate endLmth = Lmth.atEndOfMonth();
		LocalDate startLmth = Lmth.atDay(1);

		YearMonth TWmthsago = Tmth.minusMonths(2);
		LocalDate endTWmthsago = TWmthsago.atEndOfMonth();
		LocalDate startTWmthsago = TWmthsago.atDay(1);

		switch (viewOpt) {

		case "thismth":
			List<LocalDate> Cdates = Stream.iterate(startTmth, date -> date.plusDays(1))
					.limit(ChronoUnit.DAYS.between(startTmth, endTmth) + 1).collect(Collectors.toList());

			List<VehicleHire> ClistVH = VHRepo.findVehicleHireByDates(Cdates);
			EmpServ.collateData(model, ClistVH, viewOpt);
			break;

		case "lastmth":
			List<LocalDate> Ldates = Stream.iterate(startLmth, date -> date.plusDays(1))
					.limit(ChronoUnit.DAYS.between(startLmth, endLmth) + 1).collect(Collectors.toList());

			List<VehicleHire> LlistVH = VHRepo.findVehicleHireByDates(Ldates);
			EmpServ.collateData(model, LlistVH, viewOpt);
			break;

		case "2mthsago":
			List<LocalDate> TWdates = Stream.iterate(startTWmthsago, date -> date.plusDays(1))
					.limit(ChronoUnit.DAYS.between(startTWmthsago, endTWmthsago) + 1).collect(Collectors.toList());

			List<VehicleHire> TWlistVH = VHRepo.findVehicleHireByDates(TWdates);
			EmpServ.collateData(model, TWlistVH, viewOpt);
			break;

		default: // default statements
		}

		return "dashboard";
	}

	/*--------------------Select by Quarters, Q1, Q2, Q3, Q4 */
	public String chartByQtr(Model model, @Param("viewOpt") String viewOpt) {

		int curQyear = Year.now().getValue();
		int lastQyear = curQyear;
		int curQtr = LocalDate.now().get(IsoFields.QUARTER_OF_YEAR);

		int lastQtr = (curQtr - 1) > 0 ? curQtr - 1 : 4;
		if (lastQtr > curQtr)
			lastQyear = lastQyear - 1; // Q4 to 3, minus 1 year

		// This Quarter
		LocalDate CQstart = YearMonth.of(curQyear, 1).with(QUARTER_OF_YEAR, curQtr).atDay(1);
		LocalDate CQend = LocalDate.now();

		// Last Quarter
		LocalDate LQstart = YearMonth.of(lastQyear, 1).with(QUARTER_OF_YEAR, lastQtr).atDay(1);
		LocalDate LQend = YearMonth.of(lastQyear, 3).with(QUARTER_OF_YEAR, lastQtr).atEndOfMonth();

		int TwoQtrsAgo = (lastQtr - 1) > 0 ? lastQtr - 1 : 4;
		if (TwoQtrsAgo > lastQtr)
			lastQyear = lastQyear - 1;// Q4 to 3, minus 1 year

		// Two Quarters Ago
		LocalDate TWQstart = YearMonth.of(lastQyear, 1).with(QUARTER_OF_YEAR, TwoQtrsAgo).atDay(1);
		LocalDate TWQend = YearMonth.of(lastQyear, 3).with(QUARTER_OF_YEAR, TwoQtrsAgo).atEndOfMonth();

		switch (viewOpt) {

		case "thisqtr":
			List<LocalDate> Cdates = Stream.iterate(CQstart, date -> date.plusDays(1))
					.limit(ChronoUnit.DAYS.between(CQstart, CQend) + 1).collect(Collectors.toList());

			List<VehicleHire> ClistVH = VHRepo.findVehicleHireByDates(Cdates);
			EmpServ.collateData(model, ClistVH, viewOpt);
			break;

		case "lastqtr":
			List<LocalDate> Ldates = Stream.iterate(LQstart, date -> date.plusDays(1))
					.limit(ChronoUnit.DAYS.between(LQstart, LQend) + 1).collect(Collectors.toList());

			List<VehicleHire> LlistVH = VHRepo.findVehicleHireByDates(Ldates);
			EmpServ.collateData(model, LlistVH, viewOpt);

			break;

		case "2qtrsago":
			List<LocalDate> TWdates = Stream.iterate(TWQstart, date -> date.plusDays(1))
					.limit(ChronoUnit.DAYS.between(TWQstart, TWQend) + 1).collect(Collectors.toList());

			List<VehicleHire> TWlistVH = VHRepo.findVehicleHireByDates(TWdates);
			EmpServ.collateData(model, TWlistVH, viewOpt);

			break;

		default: // default statements
		}

		return "dashboard";
	}

	/* chart by this, next & 2 years ago */
	public String chartByYr(Model model, @Param("viewOpt") String viewOpt) {

		int curYear = Year.now().getValue();
		int lastYear = curYear - 1;
		int TwoYrsago = lastYear - 1;

		LocalDate endcurYear = LocalDate.now();
		LocalDate startcurYear = YearMonth.of(curYear, 1).atDay(1);

		LocalDate endlastYear = YearMonth.of(lastYear, 12).atEndOfMonth();
		LocalDate startlastYear = YearMonth.of(lastYear, 1).atDay(1);

		LocalDate endTwoYrsago = YearMonth.of(TwoYrsago, 12).atEndOfMonth();
		LocalDate startTwoYrsago = YearMonth.of(TwoYrsago, 1).atDay(1);

		// System.out.println("cur Year: " + startcurYear + " end: " + endcurYear +
		// "\n");
		// System.out.println("last Year: " + startlastYear + " end: " + endlastYear +
		// "\n");
		// System.out.println("Two Yrs back: " + startTwoYrsago + " end: " +
		// endTwoYrsago + "\n");

		switch (viewOpt) {

		case "thisyr":
			List<LocalDate> Cdates = Stream.iterate(startcurYear, date -> date.plusDays(1))
					.limit(ChronoUnit.DAYS.between(startcurYear, endcurYear) + 1).collect(Collectors.toList());

			List<VehicleHire> ClistVH = VHRepo.findVehicleHireByDates(Cdates);

			EmpServ.collateData(model, ClistVH, viewOpt);
			break;

		case "lastyr":
			List<LocalDate> Ldates = Stream.iterate(startlastYear, date -> date.plusDays(1))
					.limit(ChronoUnit.DAYS.between(startlastYear, endlastYear) + 1).collect(Collectors.toList());

			List<VehicleHire> LlistVH = VHRepo.findVehicleHireByDates(Ldates);
			EmpServ.collateData(model, LlistVH, viewOpt);

			break;

		case "2yrsago":
			List<LocalDate> TWdates = Stream.iterate(startTwoYrsago, date -> date.plusDays(1))
					.limit(ChronoUnit.DAYS.between(startTwoYrsago, endTwoYrsago) + 1).collect(Collectors.toList());

			List<VehicleHire> TWlistVH = VHRepo.findVehicleHireByDates(TWdates);
			EmpServ.collateData(model, TWlistVH, viewOpt);

			break;

		default: // default statements
		}

		return "dashboard";
	}

	@RequestMapping("/dashboard")
	public String chartchangeview(Model model) {
		String viewOpt = "thismth";
		return chart(model, viewOpt);
	}

	@RequestMapping("/dbSelectbythismth")
	public String chartthismth(Model model) {
		String viewOpt = "thismth";
		return chart(model, viewOpt);
	}

	@RequestMapping("/dbSelectbylastmth")
	public String chartlastmth(Model model) {
		return chart(model, "lastmth");
	}

	@RequestMapping("/dbSelectby2mthsago")
	public String chart2mthsago(Model model) {
		return chart(model, "2mthsago");
	}

	@RequestMapping("/dbSelectbythisqtr")
	public String chartthisqtr(Model model) {
		return chartByQtr(model, "thisqtr");
	}

	@RequestMapping("/dbSelectbylastqtr")
	public String chartlastqtr(Model model) {
		return chartByQtr(model, "lastqtr");
	}

	@RequestMapping("/dbSelectby2qtrsago")
	public String chart2qtrsago(Model model) {
		return chartByQtr(model, "2qtrsago");
	}

	@RequestMapping("/dbSelectbythisyr")
	public String chartthisyr(Model model) {
		return chartByYr(model, "thisyr");
	}

	@RequestMapping("/dbSelectbylastyr")
	public String chartlastyr(Model model) {
		return chartByYr(model, "lastyr");
	}

	@RequestMapping("/dbSelectby2yrsago")
	public String chart2yrsago(Model model) {
		return chartByYr(model, "2yrsago");
	}

// -------------------- SCR flowchart -----------------------------------------
	@GetMapping("/flowchart")
	public String Displayflowchart(Model model) {
		System.out.println("\n flowchart endpoint- calling flowchart.html \n");
		return "flowchart";
	}
// -------------------- Staff Logout ----------------------------------------------			
	@GetMapping("/stafflogout")
	public String DisplayLogout(Model model, HttpSession session) {
		// System.out.println("Enter staff logout ");
		String startmsg = " ";

		session.setAttribute("startmsg", startmsg);
		session.setAttribute("usrmsg", startmsg);
		session.setAttribute("urole", startmsg);
		return "index";
	}

}