package ntuc.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class VehicleHireId implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "vehicle_id", nullable = false) 
	private Integer vehicleId;

//	@Column(name = "hire_id", nullable = false)
//	private Integer hireId;

	@Column(name = "day")
	private LocalDate day;

	public VehicleHireId() {
	}

	public VehicleHireId(Integer vehicleId, LocalDate day) {
		this.vehicleId = vehicleId;
		this.day = day;
	}

	public Integer getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Integer vehicleId) {
		this.vehicleId = vehicleId;
	}


	

	public LocalDate getday() {
		return day;
	}

	public void setday(LocalDate day) {
		this.day = day;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vehicleId == null) ? 0 : vehicleId.hashCode());
		result = prime * result + ((day == null) ? 0 : day.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VehicleHireId other = (VehicleHireId) obj;
		if (vehicleId == null) {
			if (other.vehicleId != null)
				return false;
		} else if (!vehicleId.equals(other.vehicleId))
			return false;
		if (day == null) {
			if (other.day != null)
				return false;
		} else if (!day.equals(other.day))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "VehicleHireId [day=" + day + "]";
	}

		
}
