package ntuc.controller;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.lang.String;
import java.time.format.DateTimeFormatter;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ntuc.model.Hire;
import ntuc.model.User;
import ntuc.model.Vehicle;
import ntuc.model.Customer;
import ntuc.repository.CustomerRepository;
import ntuc.repository.EmployeeRepository;
import ntuc.repository.HireRepository;
import ntuc.repository.RoleRepository;
import ntuc.repository.UserRepository;
import ntuc.repository.VehicleRepository;
import ntuc.repository.VehicleTypeRepository;
import ntuc.repository.VehicleHireRepository;
import ntuc.service.UserService;
import ntuc.service.HireService;


@Controller
public class HireController {

	@Autowired
	VehicleTypeRepository vehicleTypeRepository;
	@Autowired
	VehicleRepository vehicleRepo;
	@Autowired
	VehicleHireRepository VHRepo;
	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	HireRepository hireRepo;
	@Autowired
	RoleRepository roleRepo;
	@Autowired
	UserRepository userRepo;
	@Autowired
	HireService hireServ;

	@Autowired
	private UserService userServ;

	@GetMapping("/vehicleSedan")
	public String DisplaySedan(Model model, HttpSession session) {
		List<Vehicle> listVehicle = hireServ.initdisplay("SEDAN");
		hireServ.checklistveh(listVehicle, session); // check if list of vehicles available
		List<LocalDate> dates = hireServ.initdates();
		session.setAttribute("dates", dates);
		model.addAttribute("listVehicle", listVehicle);
		return "vehicle";
	}

	@GetMapping("/vehicleSUV")
	public String DisplaySUV(Model model, HttpSession session) {
		List<Vehicle> listVehicle = hireServ.initdisplay("SUV");
		hireServ.checklistveh(listVehicle, session); // check if list of vehicles available
		List<LocalDate> dates = hireServ.initdates();
		session.setAttribute("dates", dates);
		model.addAttribute("listVehicle", listVehicle);
		return "vehicle";
	}

	@GetMapping("/vehicleMPV")
	public String DisplayMPV(Model model, HttpSession session) {
		List<Vehicle> listVehicle = hireServ.initdisplay("MPV");
		hireServ.checklistveh(listVehicle, session); // check if list of vehicles available
		List<LocalDate> dates = hireServ.initdates();
		session.setAttribute("dates", dates);
		model.addAttribute("listVehicle", listVehicle);
		return "vehicle";
	}

	@GetMapping("/vehicleLUX")
	public String DisplayLUX(Model model, HttpSession session) {
		List<Vehicle> listVehicle = hireServ.initdisplay("LUX");
		hireServ.checklistveh(listVehicle, session); // check if list of vehicles available
		List<LocalDate> dates = hireServ.initdates();
		session.setAttribute("dates", dates);
		model.addAttribute("listVehicle", listVehicle);
		return "vehicle";
	}

	@GetMapping("/vehicleAll")
	public String DisplayAll(Model model, @RequestParam("dateF") Date df, @RequestParam("dateT") Date dt, HttpSession session) {
		String imessage = " ";
		session.setAttribute("imessage", imessage); /* imessage for index page */

		/* need to implement endDate greater than startDate */
		long diff = dt.getTime() - df.getTime();
		//System.out.println("DisplayAllModel-> start to end dates |diff: " + diff+"| \n");

		if (diff < 1) 		{
			imessage = "Invalid Dates. End Date cannot be same or earlier than Start date. Click back or Home again to retry...";
			session.setAttribute("imessage", imessage);
			return "index";	}
		
		LocalDate startDate = convertToLocalDateViaSqlDate(df);
		LocalDate endDate = convertToLocalDateViaSqlDate(dt);
		List<LocalDate> dates = Stream.iterate(startDate, date -> date.plusDays(1))
				.limit(ChronoUnit.DAYS.between(startDate, endDate) + 1).collect(Collectors.toList());
		//System.out.println("DisplayAllModel-> |Dates: " + dates + "| \n");
		
		List<Vehicle> listVehicle = vehicleRepo.findVehicleByDate(dates);
		//System.out.println("DisplayAllModel-> listVeh.size()"+listVehicle.size()+"\n"+"listVehicle : " + listVehicle+"\n");

		if (listVehicle.size() == 0) 	{
			imessage = "Currently all vehicles all reserved in the period you have selected. Click Home again to retry...";
			session.setAttribute("imessage", imessage);
			return "index";				}
		
		model.addAttribute("listVehicle", listVehicle);
		session.setAttribute("dates", dates);
		//System.out.println("DisplayAllModel-> Going to Vehicle html"+"\n"+"/VehicleAll dates :" + dates);
		return "vehicle";
		
	}

// ------------------------------------- Featured Vehicles ------------------------------------------
	@GetMapping("/FeatureHondaCity")
	public String FeaturedVehsAtCarouselLeftA(Model model, HttpSession session) {
		return SearchInfoDisplay(model, "Honda City", session);
	}
	@GetMapping("/FeatureMazada3")
	public String FeaturedVehsAtCarouselLeftB(Model model, HttpSession session) {
		return SearchInfoDisplay(model, "Mazada 3", session);
	}
	@GetMapping("/FeatureToyotaRAV")
	public String FeaturedVehsAtCarouselLeftC(Model model, HttpSession session) {
		return SearchInfoDisplay(model, "Toyota RAV", session);
	}
	@GetMapping("/FeatureMercedesCLA200")
	public String FeaturedVehsAtCarouselRightA(Model model, HttpSession session) {
		return SearchInfoDisplay(model, "Mercedes Coupe", session);
	}
	@GetMapping("/FeatureAlphard")
	public String FeaturedVehsAtCarouselRightB(Model model, HttpSession session) {
		return SearchInfoDisplay(model, "Alphard", session);
	}
	@GetMapping("/FeatureLambo")
	public String FeaturedVehsAtCarouselRightC(Model model, HttpSession session) {
		return SearchInfoDisplay(model, "Lamborghini", session);
	}
//--------------------------------------------------------------------------------------------------------------------------------
	@PostMapping("/bookingreview")
	public String VehBookingreview(Model model, @RequestParam("Cplate") String cpl, @RequestParam("dates") String dates,
			HttpSession session) {
		String message = " ";
		//System.out.println("VehBookingreview-> Vehicle Number: " + cpl);

		session.getAttribute(dates);
		//System.out.println("VehBookingreview-> -dates data" + dates + "\n");
		//System.out.println("VehBookingreview-> length of dates" + dates.length() + "\n");

		if (dates.length() <= 12) {/* 2 blank spaces, no dates */
			//System.out.println("VehBookingreview->  dates is empty... ");
			Vehicle listVehicle = vehicleRepo.findVehiclesByPlateNo(cpl);

			model.addAttribute("listVehicle", listVehicle);
			LocalDate datefr = LocalDate.now();
			LocalDate dateto = LocalDate.now();

			Date datef = convertToDateViaSqlDate(datefr);
			Date datet = convertToDateViaSqlDate(dateto);

			//System.out.println("VehBookingreview-> |datefr" + datef+"|dateTo"+datet+"\n");
			session.setAttribute("datef", datef);
			session.setAttribute("datet", datet);
			return "bookingreview";

		}

		/* Get the DateFrom Dates String */
		String DateFrom = "";
		for (int i = 1; i < 11; i++) {
			DateFrom += dates.charAt(i);
		}

		/* Get the DateTo Dates String String */
		String DateTo = "";
		for (int i = dates.length() - 11; i < dates.length() - 1; i++) {
			DateTo += dates.charAt(i);
		}
		//System.out.println("dates:" + dates + "\n");
		//System.out.println("| datesfrom:" + DateFrom + "|"+"| DateTo:" + DateTo + "| \n");
		

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate datefr = LocalDate.parse(DateFrom, formatter);
		LocalDate dateto = LocalDate.parse(DateTo, formatter);

		//System.out.println("| LocalDate datesfr:" + datefr + "|"+"| LocalDate Dateto:" + dateto + "| \n");
		//System.out.println("in VehBookingreview"+"\n");

		List<LocalDate> ndates = Stream.iterate(datefr, date -> date.plusDays(1))
				.limit(ChronoUnit.DAYS.between(datefr, dateto) + 1).collect(Collectors.toList());

		Vehicle listVehicle = vehicleRepo.findVehicleByPlateNoAndDate(cpl, ndates);

		if (listVehicle == null) {
			message = "The vehicle model selected is unavailable with these dates. Please click back or Home button to try again... ";
			session.setAttribute("message", message);
			//System.out.println("Reselect Dates again or select new catgeory!!!: from controller  bookingreview2");
			return "bookingreview";
		}

		//System.out.print("Going to booking\n");
		model.addAttribute("listVehicle", listVehicle);

		Date datef = convertToDateViaSqlDate(datefr);
		Date datet = convertToDateViaSqlDate(dateto);

		long Days = getDifferenceDays(datef, datet) + 1;
		BigDecimal days = new BigDecimal(Days);
		BigDecimal pricing = listVehicle.getVehicleType().getPricing();
		BigDecimal amount = days.multiply(pricing);
		//System.out.print("amount to pay" + amount + "\n");

		session.setAttribute("Days", days);
		session.setAttribute("Total", amount);
		session.setAttribute("datef", datef);
		session.setAttribute("datet", datet);
		return "booking";

	}

	@PostMapping("/bookingreview2")
	public String VehBookingreview2(Model model, @RequestParam("Cplate") String cpl, @RequestParam("dateF") Date df,
			@RequestParam("dateT") Date dt, HttpSession session) {
		String message = " ";
		session.setAttribute("message", message);
		//System.out.println("Entering Controller bookingreview2 method:Vehicle plateno: " + cpl);
		//System.out.println("| check the dates in bookingreview2 " + "df " + df + " dt " + dt + "|");

		/* need to implement endDate greater than startDate */
		long diff = dt.getTime() - df.getTime();
		//System.out.println("diff" + diff);

		/* Another Loop if Dates are not selected yet */
		if (diff < 1) {
			message = "Invalid Dates: The end Date is earlier than the start Date. Click back or Home to retry... ";
			session.setAttribute("message", message);
			//System.out.println("Error! DateTo lesser than DateFrom");
			return "bookingreview"; /* bookingreview */
		}

		/* Else Dates selected and proceed to Booking */
		LocalDate startDate = convertToLocalDateViaSqlDate(df);
		LocalDate endDate = convertToLocalDateViaSqlDate(dt);
		//System.out.println("startDate: " + startDate);
		//System.out.println("endDate: " + endDate);

		List<LocalDate> dates = Stream.iterate(startDate, date -> date.plusDays(1))
				.limit(ChronoUnit.DAYS.between(startDate, endDate) + 1).collect(Collectors.toList());

		Vehicle listVehicle = vehicleRepo.findVehicleByPlateNoAndDate(cpl, dates);

		//System.out.println("Line 397- Vehicle available: " + listVehicle);

		if (listVehicle == null) {
			message = "The vehicle model selected is unavailable with these dates. Please click back or Home button to try again... ";
			session.setAttribute("message", message);
			//System.out.println("Reselect Dates again or select new catgeory!!!: from controller  bookingreview2");
			return "bookingreview"; /* bookingreview */
		}

		model.addAttribute("listVehicle", listVehicle);

		Date datef = df;
		Date datet = dt;
		long Days = getDifferenceDays(datef, datet) + 1;
		BigDecimal days = new BigDecimal(Days);
		BigDecimal pricing = listVehicle.getVehicleType().getPricing();
		BigDecimal amount = days.multiply(pricing);
		//System.out.print("amount to pay" + amount+"\n");

		session.setAttribute("Days", days);
		session.setAttribute("Total", amount);
		session.setAttribute("datef", datef);
		session.setAttribute("datet", datet);

		//System.out.println("booking review2 controller: from " + datef + " to: " + datet);
		return "booking";

	}

	@PostMapping("/page2") // actual booking module
	public String ReserveBooking(Model model, @RequestParam("Cplate") String cpl, @RequestParam("datef") Date df,
			@RequestParam("datet") Date dt, @RequestParam("usrnam") String usrnam, @RequestParam("pwd") String pwd,
			@RequestParam("usrmsg") String usrmsg, HttpSession session) {

		/* Check login User logged in; note Employee cannot book vehicle */
		session.getAttribute(usrmsg);
		/* usrmsg already logged in  */
		//System.out.println("usermsg logged in : " + usrmsg);
		//System.out.println("usernam logged in : " + usrnam); // usually blank; only available when user(customer) is logged in
		//System.out.println("usrmsg length: " + usrmsg.length());// usrmsg will be length 1 when no user is logged in

		if (usrmsg.length() == 1) // not logged in yet; both usrnam & pwd will be collected if usrmsg.length is 1 
		{
			
			  //System.out.println("Need to authenicate user first");
			  //System.out.println("Enter User Login module- Username: " + usrnam + " pwd: "+ pwd+"\n");
			  
			  //check input usrnam is valid
			  
			  User user2 = userRepo.findUserByUsername(usrnam);
			  //System.out.println("line 426 user2 data :" + user2);
			  
			  if (user2 == null) { return "login"; } //reject if user key in invalid username
			  
			  // need to check username & pwd 
			  if (userServ.authUserPwd(usrnam, pwd)) {
			  //matching password 
			  //System.out.println("Perfect match in username, pwd");
			  String startmsg = "Member : "; String umsg = usrnam;
			  session.setAttribute("startmsg", startmsg); session.setAttribute("usrmsg",
			  umsg); //System.out.println(startmsg + umsg);
			  
			  //System.out.println("| Cplate " + cpl + "| \n"); //System.out.println("| df" +
			  //df + "| dt" + dt + "|");
			  
			  session.setAttribute("cpl", cpl); session.setAttribute("df", df);
			  session.setAttribute("dt", dt);
			  
			  LocalDate startDate = convertToLocalDateViaSqlDate(df); LocalDate endDate =
			  convertToLocalDateViaSqlDate(dt); 
			  //System.out.println("startDate: " + startDate); 
			  //System.out.println("endDate: " + endDate);
			  
			  List<LocalDate> dates = Stream.iterate(startDate, date -> date.plusDays(1))
			  .limit(ChronoUnit.DAYS.between(startDate, endDate) +
			  1).collect(Collectors.toList());
			  
			  //find Customer id by User Id from UserName 
			  if (customerRepository.findCustomerByUserId(user2)== null) {
				// Reject if employee is booking the vehicle
					//System.out.println(" Not logged in-employee cannot book vehicle");
					startmsg = " ";
					session.setAttribute("startmsg", startmsg);
					session.setAttribute("usrmsg", startmsg);
					return "login";
			  }
			  
			  Customer C1 = customerRepository.findCustomerByUserId(user2);
			  //System.out.println("Line 461 C1 " + C1 + "\n");
			  
			  Vehicle ReserveVeh = vehicleRepo.findVehicleByPlateNoAndDate(cpl, dates);
			  
			  //check the invoice number 
			  Integer Invno = hireRepo.findMaxInvoiceNo();
			  //System.out.println("last invoice no" + Invno + "\n");
			  
			  if (Invno == null) { Invno = 55501; } //first time  
			  else Invno++;
			  
			  String Invno1 = String.valueOf(Invno); for (int i = 0; i < dates.size(); i++)
			  { Hire hire1 = Hire.of(employeeRepository.getOne(1), C1, ReserveVeh,
			  startDate, endDate, Invno1); hireRepo.save(hire1); }
			  
			  return "index";
			  
			  } else { //wrong password supplied
			  //System.out.println(" mis-match in username, pwd"); 
				  String startmsg = " ";
				  session.setAttribute("startmsg", startmsg); 
				  session.setAttribute("usrmsg", startmsg); 
				  return "login"; }
			 
			
		}
		/* User logged in portion */
		User user1 = userRepo.findUserByUsername(usrmsg);
		//System.out.println("line 484 user User1" + user1 + "\n");

		//System.out.println("| Cplate " + cpl + "| \n");
		//System.out.println("| df" + df + "| dt" + dt + "|");

		session.setAttribute("cpl", cpl);
		session.setAttribute("df", df);
		session.setAttribute("dt", dt);

		LocalDate startDate = convertToLocalDateViaSqlDate(df);
		LocalDate endDate = convertToLocalDateViaSqlDate(dt);
		//System.out.println("startDate: " + startDate);
		//System.out.println("endDate: " + endDate);

		List<LocalDate> dates = Stream.iterate(startDate, date -> date.plusDays(1))
				.limit(ChronoUnit.DAYS.between(startDate, endDate) + 1).collect(Collectors.toList());

		/* find Customer id by User Id from UserName */
		if (customerRepository.findCustomerByUserId(user1) == null) {
			// Reject if employee is booking the vehicle
			//System.out.println(" Employee logged in;  Employee cannot book vehicle");
			String startmsg = " ";
			session.setAttribute("startmsg", startmsg);
			session.setAttribute("usrmsg", startmsg);
			return "login";
		}

		Customer C1 = customerRepository.findCustomerByUserId(user1);
		//System.out.println("Line 466 C1 to string value" + C1.toString() + "\n");

		Vehicle ReserveVeh = vehicleRepo.findVehicleByPlateNoAndDate(cpl, dates);

		/* check the invoice number */
		Integer Invno = hireRepo.findMaxInvoiceNo();
		//System.out.println("last invoice no" + Invno + "\n");

		if (Invno == null) {
			Invno = 55501;
		} /* first time else use MaxInvoiceNo+1 */
		else
			Invno++;

		String Invno1 = String.valueOf(Invno);

		for (int i = 0; i < dates.size(); i++) {
			Hire hire1 = Hire.of(employeeRepository.getOne(1), C1, ReserveVeh, startDate, endDate, Invno1);
			hireRepo.save(hire1);
		}

		return "index";

	}

	@PostMapping("/searchinfo")
	public String SearchInfoDisplay(Model model, @RequestParam("keyword") String kword, HttpSession session) {
		//System.out.println("SearchInfoDisplay-> |Keyword: " + kword+"| \n");
		
		List<Vehicle> listVehicle = vehicleRepo.findAllSearch(kword);
		//System.out.println("search data:" + listVehicle);

		if (listVehicle.isEmpty()) 	{
			//System.out.println("Data empty from keyword search");
			return "index";			}
		
		List<LocalDate> dates = hireServ.initdates();
		session.setAttribute("dates", dates);
		model.addAttribute("listVehicle", listVehicle);
		return "vehicle";
	}


	/* Code to convert Date from html to LocalDate */
	public LocalDate convertToLocalDateViaSqlDate(Date dateToConvert) {
		return new java.sql.Date(dateToConvert.getTime()).toLocalDate();
	}

	public Date convertToDateViaSqlDate(LocalDate dateToConvert) {
		return java.sql.Date.valueOf(dateToConvert);
	}

	public static long getDifferenceDays(Date d1, Date d2) {
		long diff = d2.getTime() - d1.getTime();
		return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	}
}
