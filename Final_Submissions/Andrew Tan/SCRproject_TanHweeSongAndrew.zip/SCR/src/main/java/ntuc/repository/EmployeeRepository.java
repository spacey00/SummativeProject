package ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ntuc.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
}
