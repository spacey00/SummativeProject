package ntuc.repository;

import ntuc.model.Hire;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface HireRepository extends JpaRepository<Hire, Integer> {

	@Query("SELECT h FROM Hire h" + " JOIN h.customer hc" + " WHERE hc.customerId = :cid")
	public List<Hire> findAllbyCustomerId(@Param("cid") Integer cid);

	@Query("SELECT h.invoiceNo from Hire h" + " WHERE h.hireId=(SELECT MAX(h.hireId) from h)")
	public Integer findMaxInvoiceNo();

	@Query("SELECT h FROM Hire h WHERE " + " CONCAT(h.hireId, h.invoiceDate, h.invoiceNo, h.paid)" + " LIKE %?1%")
	public Page<Hire> findAll(String keyword, Pageable pageable);

	@Query("SELECT h FROM Hire h" + " WHERE h.invoiceNo = :invNo")
	public List<Hire> findAllbyInvoiceNo(String invNo);

}

