package ntuc.controller;

import java.io.IOException;
import java.util.List;
import java.lang.String;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.RedirectView;


import ntuc.model.Vehicle;
import ntuc.model.VehicleType;
import ntuc.repository.CustomerRepository;
import ntuc.repository.EmployeeRepository;
import ntuc.repository.HireRepository;
import ntuc.repository.RoleRepository;
import ntuc.repository.UserRepository;
import ntuc.repository.VehicleRepository;
import ntuc.repository.VehicleTypeRepository;

@Controller
public class VehicleController {

	@Autowired
	VehicleTypeRepository vehicleTypeRepository;
	@Autowired
	VehicleRepository vehicleRepo;
	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	HireRepository hireRepo;
	@Autowired
	RoleRepository roleRepo;
	@Autowired
	UserRepository userRepo;

	

	


	/* loading of vehicle image */
	@GetMapping("/vehicles")
	public String car(Model model) {
		List<Vehicle> listVehicle = vehicleRepo.findAll();
		model.addAttribute("listVehicle", listVehicle);
		return "vehicle";
	}

	@GetMapping("/vehicles/new")
	public String ShowUserform(Model model) {

		List<VehicleType> listVehicleType = vehicleTypeRepository.findAll();
		model.addAttribute("listVehicleType", listVehicleType);
		model.addAttribute("vehicle", new Vehicle());
		return "vehicle_form";
	}

	@PostMapping("/vehicles/save")
	public RedirectView saveVehicle(Vehicle vehicle, @RequestParam("vehiclePlateNo") String cnum,
			@RequestParam("image") MultipartFile multipartFile) throws IOException {
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		/* find vehicle with the same car plate */
		Vehicle vehfind1 = vehicleRepo.findVehiclesByPlateNo(cnum);
		/* vehicle.setPhotos(fileName); */
		vehfind1.setPhotos(fileName);

		/* Vehicle savedVehicle = vehicleRepo.save(vehfind1); */
		/* String uploadDir = "user-photos/" + savedVehicle.getVehicleId(); */
		
		//String uploadDir = "images/";
		//FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);

		return new RedirectView("/vehicles", true);

	}
	
}
