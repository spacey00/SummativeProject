package ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

import ntuc.model.VehicleHire;
import ntuc.model.VehicleHireId;


@Repository
public interface VehicleHireRepository 
	extends JpaRepository<VehicleHire, VehicleHireId> {
	
	@Query("SELECT v FROM VehicleHire v" 
			   + " JOIN v.hire vh" 
			   + " WHERE vh.hireId IN (:hrid)"
			   + " ORDER by v.day")
		public List<VehicleHire> findVehicleHireByHireId(List<Integer> hrid);
	
	@Query("SELECT v FROM VehicleHire v" 
			   + " JOIN v.hire vh" 
			   + " WHERE vh.hireId = :hid"
			   + " ORDER by v.day")
		public List<VehicleHire> findVehicleHireByHId(Integer hid);
	
	@Query("SELECT v FROM VehicleHire v" 
            + " WHERE v.day IN (:dates)"
            + " ORDER by v.day")
		public List<VehicleHire> findVehicleHireByDates(List<LocalDate> dates);
	
}

