package ntuc.model;

import java.io.Serializable;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "vehicles")
public class Vehicle implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "vehicle_id")
	private Integer vehicleId;

	@Column(name = "vehicle_plate_no", unique = true, nullable = false)
	private String vehiclePlateNo;

	@Column(name = "vehicle_status", nullable = false)
	// @ColumnDefault("working")
	private String vehicleStatus = "working";

//	@Column(name = "pricing")
//	private BigDecimal pricing;

	@ManyToOne
	@JoinColumn(name = "vehicle_type_id", nullable = false)
	VehicleType vehicleType;

	@OneToMany(mappedBy = "hire")
	private Set<VehicleHire> vehicleHire = new HashSet<>();
	
	@Column(nullable = true, length = 64)
	private String photos;
		
	@Transient
	public String getPhotosImagePath() {
		if (photos == null || vehicleId == null)
			return null;
		/* return "/user-photos/" + vehicleId + "/" + photos; */
		return "images/"+photos;
	}
    		
	public String getPhotos() {
		return photos;
	}

	public void setPhotos(String photos) {
		this.photos = photos;
	}

	public Vehicle() {
	}

	public Vehicle(Integer vehicleId, String vehiclePlateNo, String vehicleStatus, VehicleType vehicleType,
			Set<VehicleHire> vehicleHire) {
		this.vehicleId = vehicleId;
		this.vehiclePlateNo = vehiclePlateNo;
		this.vehicleStatus = vehicleStatus;
		this.vehicleType = vehicleType;
		this.vehicleHire = vehicleHire;
	}

	public Vehicle(Integer vehicleId, String vehiclePlateNo, String vehicleStatus, VehicleType vehicleType) {
		this.vehicleId = vehicleId;
		this.vehiclePlateNo = vehiclePlateNo;
		this.vehicleStatus = vehicleStatus;
		this.vehicleType = vehicleType;
	}

	

	public Integer getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Integer vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getVehiclePlateNo() {
		return vehiclePlateNo;
	}

	public void setVehiclePlateNo(String vehiclePlateNo) {
		this.vehiclePlateNo = vehiclePlateNo;
	}

	public String getVehicleStatus() {
		return vehicleStatus;
	}

	public void setVehicleStatus(String vehicleStatus) {
		this.vehicleStatus = vehicleStatus;
	}

	public VehicleType getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(VehicleType vehicleType) {
		this.vehicleType = vehicleType;
	}

	public Set<VehicleHire> getVehicleHire() {
		return vehicleHire;
	}

	public void setVehicleHire(Set<VehicleHire> vehicleHire) {
		this.vehicleHire = vehicleHire;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vehicleId == null) ? 0 : vehicleId.hashCode());
		result = prime * result + ((vehiclePlateNo == null) ? 0 : vehiclePlateNo.hashCode());
		result = prime * result + ((vehicleStatus == null) ? 0 : vehicleStatus.hashCode());
		result = prime * result + ((vehicleType == null) ? 0 : vehicleType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehicle other = (Vehicle) obj;
		if (vehicleId == null) {
			if (other.vehicleId != null)
				return false;
		} else if (!vehicleId.equals(other.vehicleId))
			return false;
		if (vehiclePlateNo == null) {
			if (other.vehiclePlateNo != null)
				return false;
		} else if (!vehiclePlateNo.equals(other.vehiclePlateNo))
			return false;
		if (vehicleStatus == null) {
			if (other.vehicleStatus != null)
				return false;
		} else if (!vehicleStatus.equals(other.vehicleStatus))
			return false;
		if (vehicleType == null) {
			if (other.vehicleType != null)
				return false;
		} else if (!vehicleType.equals(other.vehicleType))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", vehiclePlateNo=" + vehiclePlateNo
				+ ", vehicleStatus=" + vehicleStatus + ", vehicleType=" + vehicleType + "]";
	}


}
