package ntuc.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import ntuc.model.Vehicle;
import ntuc.model.VehicleType;

@Repository
public interface VehicleTypeRepository extends JpaRepository<VehicleType, Integer> {
	
	@Query("SELECT v FROM VehicleType v" 
			  + " WHERE CONCAT(v.vehicleId, v.pricing, v.vehicleBrandName, v.vehicleCatagory, v.vehicleModelName)"
			  + " LIKE %?1%")  
		public List<Vehicle> findAll(String kword, Pageable pageable);
	
	@Query("SELECT v FROM VehicleType v" 
			  + " WHERE v.vehicleId = :vehId")
		public VehicleType findByVehicleId(Integer vehId);
}
