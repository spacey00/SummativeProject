package ntuc.controller;

import javax.servlet.http.HttpSession;
import java.lang.String;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class AppController {

	@GetMapping("/")
	public String Init(Model model, HttpSession session) {
		
		String message = " ";
		session.setAttribute("message", message);
		session.setAttribute("imessage", message);
		session.setAttribute("umessage", message);
		session.setAttribute("startmsg", message); 
		session.setAttribute("usrmsg", message);
		session.setAttribute("urole", message);
		//System.out.println("Start up on endpoint: '/' Controller init");

		return "index";
	}

	@GetMapping("/Home")
	public String Home(Model model, HttpSession session) {
		
		String message = " ";
		session.setAttribute("message", message);
		session.setAttribute("imessage", message);
		session.setAttribute("umessage", message);
		//System.out.println("Start up on endpoint: '/' Controller:Home");

		return "index";
	}
	
	@GetMapping("/register")
	public String RegNewUser(Model model) {
		//System.out.println("Enter register New User html!");
		return "register";
	}

	
//----------------------------------- linked info for Footer ---------------------------
	@GetMapping("/TheCompany")
	public String CorporateInfo(Model model, HttpSession session) {
		return "corporateprofile";
		
	}	
	@GetMapping("/UserHelp")
	public String CorporateHelpPage(Model model, HttpSession session) {
		return "userhelppage";
		
	}	
}
