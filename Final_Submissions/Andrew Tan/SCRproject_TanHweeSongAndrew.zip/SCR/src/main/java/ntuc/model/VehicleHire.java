package ntuc.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

@Entity
@Table(name= "vehicles_hires")
public class VehicleHire implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private VehicleHireId vehicleHireId;

	@ManyToOne
	@MapsId("vehicleId")
	private Vehicle vehicle;

	@ManyToOne
	@JoinColumn(
			name = "hire_id",
			nullable = false)
	// @MapsId("hireId")
	private Hire hire;
	
	@Column(name = "day", insertable = false, updatable = false)
	private LocalDate day;


	public VehicleHire() {
	}

	public VehicleHire(VehicleHireId vehicleHireId, Vehicle vehicle, Hire hire) {
		this.vehicleHireId = vehicleHireId;
		this.vehicle = vehicle;
		this.hire = hire;
	}

	public VehicleHireId getVehicleHireId() {
		return vehicleHireId;
	}

	public void setVehicleHireId(VehicleHireId vehicleHireId) {
		this.vehicleHireId = vehicleHireId;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public LocalDate getDay() {
		return day;
	}

	public void setDay(LocalDate day) {
		this.day = day;
	}

	public Hire getHire() {
		return hire;
	}

	public void setHire(Hire hire) {
		this.hire = hire;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hire == null) ? 0 : hire.hashCode());
		result = prime * result + ((vehicle == null) ? 0 : vehicle.hashCode());
		result = prime * result + ((vehicleHireId == null) ? 0 : vehicleHireId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VehicleHire other = (VehicleHire) obj;
		if (hire == null) {
			if (other.hire != null)
				return false;
		} else if (!hire.equals(other.hire))
			return false;
		if (vehicle == null) {
			if (other.vehicle != null)
				return false;
		} else if (!vehicle.equals(other.vehicle))
			return false;
		if (vehicleHireId == null) {
			if (other.vehicleHireId != null)
				return false;
		} else if (!vehicleHireId.equals(other.vehicleHireId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "VehicleHire [hire=" + hire + ", vehicle=" + vehicle + ", vehicleHireId=" + vehicleHireId + "]";
	}

}
