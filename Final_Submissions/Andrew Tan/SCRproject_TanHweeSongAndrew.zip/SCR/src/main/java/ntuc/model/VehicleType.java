package ntuc.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;
import java.util.HashSet;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity 
@Table(name = "vehicle_types")
public class VehicleType implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "vehicle_id")
	private Integer vehicleId;

	@Column(name = "vehicle_brand_name", nullable = false) 
	private String vehicleBrandName;

	@Column(name = "vehicle_model_name", nullable = false) 
	private String vehicleModelName;

	@Column(name = "vehicle_cat", nullable = false)
	private VehicleCatagory vehicleCatagory;

	@Column(nullable = false)
	private BigDecimal pricing;

	@OneToMany(mappedBy = "vehicleType")
	private Set<Vehicle> vehicles = new HashSet<>();

	static public enum VehicleCatagory {
		SEDAN,
		SUV, 
		MPV,
		LUX
	}

	public VehicleType() {
	}

	public VehicleType(Integer vehicleId, String vehicleBrandName, String vehicleModelName,
			VehicleCatagory vehicleCatagory, BigDecimal pricing, Set<Vehicle> vehicles) {
		this.vehicleId = vehicleId;
		this.vehicleBrandName = vehicleBrandName;
		this.vehicleModelName = vehicleModelName;
		this.vehicleCatagory = vehicleCatagory;
		this.pricing = pricing;
		this.vehicles = vehicles;
	}

	public VehicleType(Integer vehicleId, String vehicleBrandName, String vehicleModelName,
			VehicleCatagory vehicleCatagory, BigDecimal pricing) {
		this.vehicleId = vehicleId;
		this.vehicleBrandName = vehicleBrandName;
		this.vehicleModelName = vehicleModelName;
		this.vehicleCatagory = vehicleCatagory;
		this.pricing = pricing;
	}

	public Integer getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Integer vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getVehicleBrandName() {
		return vehicleBrandName;
	}

	public void setVehicleBrandName(String vehicleBrandName) {
		this.vehicleBrandName = vehicleBrandName;
	}

	public String getVehicleModelName() {
		return vehicleModelName;
	}

	public void setVehicleModelName(String vehicleModelName) {
		this.vehicleModelName = vehicleModelName;
	}

	public VehicleCatagory getVehicleCatagory() {
		return vehicleCatagory;
	}

	public void setVehicleCatagory(VehicleCatagory vehicleCatagory) {
		this.vehicleCatagory = vehicleCatagory;
	}

	public BigDecimal getPricing() {
		return pricing;
	}

	public void setPricing(BigDecimal pricing) {
		this.pricing = pricing;
	}

	public Set<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(Set<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pricing == null) ? 0 : pricing.hashCode());
		result = prime * result + ((vehicleBrandName == null) ? 0 : vehicleBrandName.hashCode());
		result = prime * result + ((vehicleCatagory == null) ? 0 : vehicleCatagory.hashCode());
		result = prime * result + ((vehicleId == null) ? 0 : vehicleId.hashCode());
		result = prime * result + ((vehicleModelName == null) ? 0 : vehicleModelName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VehicleType other = (VehicleType) obj;
		if (pricing == null) {
			if (other.pricing != null)
				return false;
		} else if (!pricing.equals(other.pricing))
			return false;
		if (vehicleBrandName == null) {
			if (other.vehicleBrandName != null)
				return false;
		} else if (!vehicleBrandName.equals(other.vehicleBrandName))
			return false;
		if (vehicleCatagory != other.vehicleCatagory)
			return false;
		if (vehicleId == null) {
			if (other.vehicleId != null)
				return false;
		} else if (!vehicleId.equals(other.vehicleId))
			return false;
		if (vehicleModelName == null) {
			if (other.vehicleModelName != null)
				return false;
		} else if (!vehicleModelName.equals(other.vehicleModelName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "VehicleType [pricing=" + pricing + ", vehicleBrandName=" + vehicleBrandName + ", vehicleCatagory="
				+ vehicleCatagory + ", vehicleId=" + vehicleId + ", vehicleModelName=" + vehicleModelName + "]";
	}


}
