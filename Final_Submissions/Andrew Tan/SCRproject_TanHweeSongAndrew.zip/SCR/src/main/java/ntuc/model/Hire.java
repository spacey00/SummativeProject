package ntuc.model;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.Optional;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.stream.Stream;
import java.time.temporal.ChronoUnit;


@Entity
@Table(name = "hires")
public class Hire implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name = "hire_id")
	private Integer hireId;

	@Column(name = "hire_date", nullable = false)
	private LocalDateTime hireDate; 

	@Column(name = "invoice_no")
	private String invoiceNo;

	@Column(name = "invoice_date")
	private LocalDate invoiceDate;

	@Column(name = "paid", nullable = false)
	/* @ColumnDefault("0") */
	private boolean paid = false;

	@ManyToOne
	@JoinColumn(name = "employee_id")
	private Employee employee;

	@ManyToOne
	@JoinColumn(name = "customer_id")
	private Customer customer;

	@OneToMany(mappedBy = "vehicle", cascade = CascadeType.ALL)
	private Set<VehicleHire> vehicleHire = new HashSet<>();

	public Hire() {
	}

	public Hire(
			Integer hireId, 
			LocalDateTime hireDate, 
			String invoiceNo, 
			LocalDate invoiceDate, 
			boolean paid,
			Employee employee, 
			Customer customer, 
			Set<VehicleHire> vehicleHire) {

		this.hireId = hireId;
		this.hireDate = hireDate;
		this.invoiceNo = invoiceNo;
		this.invoiceDate = invoiceDate;
		this.paid = paid;
		this.employee = employee;
		this.customer = customer;
		this.vehicleHire = vehicleHire;
	}

	public Hire(
			Integer hireId, 
			LocalDateTime hireDate, 
			String invoiceNo, 
			LocalDate invoiceDate, 
			boolean paid,
			Employee employee, 
			Customer customer) {

		this.hireId = hireId;
		this.hireDate = hireDate;
		this.invoiceNo = invoiceNo;
		this.invoiceDate = invoiceDate;
		this.paid = paid;
		this.employee = employee;
		this.customer = customer;
	}


	public void addVehicleHire(
			VehicleHire vehicleHire, Vehicle selectedVehicle) {

		this.vehicleHire.add(vehicleHire);
		selectedVehicle.getVehicleHire().add(vehicleHire);
	}

	public void removeVehicleHire(
			VehicleHire vehicleHire, Vehicle selectedVehicle) {

		this.vehicleHire.remove(vehicleHire);
		selectedVehicle.getVehicleHire().remove(vehicleHire);
	}
	
	/* new code added on 13 Apr 2021 */
	
	  public static Hire of( Employee employee, Customer customer, Vehicle vehicle,
	  LocalDate startDate, LocalDate endDate, String invno) {
	  
	    
	  Hire hire = new Hire( 0, LocalDateTime.now(), invno , endDate, false, employee,
	  customer);
		
		  hire.setVehicleHire( Stream.iterate(startDate, date -> date.plusDays(1))
		  .limit(ChronoUnit.DAYS.between(startDate, endDate)+1).map(d -> new
		  VehicleHireId(vehicle.getVehicleId(), d)) .map(e -> new VehicleHire(e,
		  vehicle, hire)) .collect(Collectors.toSet()));
	  
	  return hire; }
	  
	  public Optional<LocalDate> getStartDate() { return
	  this.getVehicleHire().isEmpty() ? Optional.empty() :
	  Optional.of(this.getVehicleHire().stream().map(e -> e.getDay())
	  .sorted().collect(Collectors.toList()).get(0)); }
	  
	  public Optional<LocalDate> getEndDate() { return
	  this.getVehicleHire().isEmpty() ? Optional.empty() :
	  Optional.of(this.getVehicleHire().stream().map(e ->e.getDay()).sorted()
	  .collect(Collectors.toList()) .get(this.getVehicleHire().size() - 1)); }
	 
	/* end of new code */
	
	public Integer getHireId() {
		return hireId;
	}

	public void setHireId(Integer hireId) {
		this.hireId = hireId;
	}

	public LocalDateTime getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDateTime hireDate) {
		this.hireDate = hireDate;
	}

	public LocalDate getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(LocalDate invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public boolean isPaid() {
		return paid;
	}

	public void setPaid(boolean paid) {
		this.paid = paid;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Set<VehicleHire> getVehicleHire() {
		return vehicleHire;
	}

	public void setVehicleHire(Set<VehicleHire> vehicleHire) {
		this.vehicleHire = vehicleHire;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + ((employee == null) ? 0 : employee.hashCode());
		result = prime * result + ((hireDate == null) ? 0 : hireDate.hashCode());
		result = prime * result + ((hireId == null) ? 0 : hireId.hashCode());
		result = prime * result + ((invoiceDate == null) ? 0 : invoiceDate.hashCode());
		result = prime * result + ((invoiceNo == null) ? 0 : invoiceNo.hashCode());
		result = prime * result + (paid ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hire other = (Hire) obj;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (employee == null) {
			if (other.employee != null)
				return false;
		} else if (!employee.equals(other.employee))
			return false;
		if (hireDate == null) {
			if (other.hireDate != null)
				return false;
		} else if (!hireDate.equals(other.hireDate))
			return false;
		if (hireId == null) {
			if (other.hireId != null)
				return false;
		} else if (!hireId.equals(other.hireId))
			return false;
		if (invoiceDate == null) {
			if (other.invoiceDate != null)
				return false;
		} else if (!invoiceDate.equals(other.invoiceDate))
			return false;
		if (invoiceNo == null) {
			if (other.invoiceNo != null)
				return false;
		} else if (!invoiceNo.equals(other.invoiceNo))
			return false;
		if (paid != other.paid)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Hire [customer=" + customer + ", employee=" + employee + ", hireDate=" + hireDate + ", hireId=" + hireId
				+ ", invoiceDate=" + invoiceDate + ", invoiceNo=" + invoiceNo + ", paid=" + paid + ", vehicleHire="
				+ vehicleHire + "]";
	}

	public LocalDate convertToLocalDateViaSqlDate(Date dateToConvert) {
		return new java.sql.Date(dateToConvert.getTime()).toLocalDate();
	}

	
}
