package ntuc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ntuc.model.Customer;
import ntuc.model.Hire;
import ntuc.model.Role;
import ntuc.model.User;
import ntuc.model.VehicleHire;
import ntuc.repository.CustomerRepository;
import ntuc.repository.HireRepository;
import ntuc.repository.RoleRepository;
import ntuc.repository.UserRepository;
import ntuc.repository.VehicleHireRepository;
import ntuc.service.UserService;


@Controller
public class UserController {

	@Autowired
	private RoleRepository roleRepo;
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private UserService userServ;
	@Autowired
	private CustomerRepository custRepo;
	@Autowired
	private HireRepository hireRepo;
	@Autowired
	private VehicleHireRepository VHRepo;
	
	class authPwdRole {
		private Integer pwdcorrect;
		private Integer urole;
		
		public authPwdRole(Integer pwdcorrect, Integer urole){
			this.pwdcorrect = pwdcorrect;
			this.urole = urole;
		}
		
		public int getpwdcorrect() {
	        return pwdcorrect;
	    }

	    public int geturole() {
	        return urole;
	    }
	}

	public authPwdRole authcheck(String username, String password) {
		Integer pwdcorrect = 0; /* default pwd wrong:0 */
		Integer urole = 5;// default customer:5

		User user = userRepo.findUserByUsername(username);
		BCryptPasswordEncoder ecd = new BCryptPasswordEncoder();
		Boolean isPwdCorrect = ecd.matches(password, user.getPassword());

		if (isPwdCorrect) pwdcorrect = 1;

		urole = user.getRoles().stream().findFirst().get().getId();
		return new authPwdRole(pwdcorrect, urole);
	}

	@PostMapping("/user/registration")
	public String userRegistrationForm(Model model, @RequestParam("username") String username,
			@RequestParam("password") String password, @RequestParam("email") String email,
			@RequestParam("employee_name") String name, @RequestParam("roless") String roles,
			@RequestParam("phone") String phone, @RequestParam("jobtitle") String jobTitle,
			Authentication authentication, HttpSession session) {

		if (userServ.saveEmpUser(username, password, email, name, roles, phone, jobTitle)=="true")
		{
			String umessage = " ";
			session.setAttribute("umessage", umessage);
			return "index";
		} else 
		{
			/* tell user that username taken */
			String umessage = "The username has already been taken. Please re-select a new username again... ";
			session.setAttribute("umessage", umessage);
			
			List<Role> roles1 = roleRepo.findAll();
			model.addAttribute("Role", roles1);
			
			return "addUser";
		}	
	}

	@PostMapping("/userlogin")
	public String LoginUser(Model model, @RequestParam("usrnam") String username, @RequestParam("pwd") String password,
			HttpSession session) {

		User user1 = userRepo.findUserByUsername(username);
		if (user1==null) { return "index";}/* invalid username */
		//System.out.println("Enter User Login module- Username: "+username+" pwd: "+password);
		
		authPwdRole results = authcheck(username, password);
		
		/*if (userServ.authUserPwd(username, password))*/
		if (results.pwdcorrect==1)
		{
			/* matching password */
			//System.out.println("Perfect match in username, pwd");
			String startmsg = "User : ";
			String usrmsg = username;
			session.setAttribute("startmsg", startmsg);
			session.setAttribute("usrmsg", usrmsg);
			/* check role status */
			
			String urole = String.valueOf(results.geturole());
			session.setAttribute("urole",urole);
			//System.out.println("5Cus 4emp 3mgr 2ownr 1admin value of role"+results.geturole()+"\n");
			
		} else {
			
			/* wrong password supplied*/
			//System.out.println(" mis-match in username, pwd");
			String startmsg = " ";
			session.setAttribute("startmsg", startmsg);
			session.setAttribute("usrmsg", startmsg);
		}

		return "index";
	}
	
	@GetMapping("/login")
	public String DisplayLogin(Model model) {
		//System.out.println("Enter login html!");
		return "login";
	}

	@GetMapping("/Mlogout")// Main log in
	public String DisplayLogout(Model model, HttpSession session) {
		
		//System.out.println("Enter logout ");
		String startmsg = " ";
		  session.setAttribute("startmsg", startmsg); 
		  session.setAttribute("usrmsg", startmsg);
		  session.setAttribute("urole", startmsg);
		 
		return "index";
	}
	
	@RequestMapping("/Hbooking{usrmsg}")
	public String HbookingDisp(Model model, @PathVariable("usrmsg") String usrmsg, HttpSession session) {
		session.getAttribute(usrmsg);
		//System.out.println("HbookingDisp-> |usrmsg: "+usrmsg+"| \n");
		
		if (usrmsg.isEmpty()) return "login"; //User login needed
		
		User user1 = userRepo.findUserByUsername(usrmsg);
		if (custRepo.findCustomerByUserId(user1)== null) {return "index";} // Employee detected
		
		Customer C1 = custRepo.findCustomerByUserId(user1);
		List<Hire> hirelist = hireRepo.findAllbyCustomerId(C1.getCustomerId());

		int vcount = hirelist.size();
		//System.out.println("HbookingDisp-> |vcount: " + vcount + "| \n");

		if (vcount ==0) {return "index";}
		
		List<Integer> vcount3 = new ArrayList<Integer>();

		for (int i = 0; i < vcount; i++) {
			int vcount2 = hirelist.get(i).getHireId();
			//System.out.println("HbookingDisp-> content of |vcount2: " + vcount2 + "| \n");
			vcount3.add(vcount2);
		}

		List<VehicleHire> vh = VHRepo.findVehicleHireByHireId(vcount3);
		//System.out.println("Vehicle Hire info" + vh.toString());
		vh.get(0).getHire().getCustomer().getUser().getUsername();

		model.addAttribute("vh", vh);
		return "page2";
	}
	
}
