package ntuc.controller;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ntuc.model.User;
import ntuc.repository.UserRepository;
import ntuc.service.CustomerService;

@Controller
public class CustomerController {
	
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private CustomerService customerServ;
	
	@PostMapping("/Newuser")
	public String NewUser(Model model, @RequestParam("username") String username,
			HttpSession session) {

		User user1 = userRepo.findUserByUsername(username);
		if (user1==null) { /* valid username */
		session.setAttribute("usrname",username);
			return "regpart2";
		}
		
		//System.out.println("Username taken, please select again");
		return "register";
	}
	
	@PostMapping("/AcceptNewuser")
	public String AcceptNewUser(Model model, @RequestParam("usrname") String username,
			@RequestParam("pwd") String password, @RequestParam("yrname") String yrname,
			@RequestParam("email") String email, @RequestParam("telno") String telno,
			@RequestParam("offtelno") String officephone, @RequestParam("address") String address,
			@RequestParam("website") String website, @RequestParam("drvlicense") String drvlicense,
			Authentication authentication, HttpSession session) {

		//System.out.println("username : " + username + "\n");
		//System.out.println("pwd : " + password + "\n");
		//System.out.println("yrname : " + yrname + "\n");
		//System.out.println("email : " + email + "\n");
		//System.out.println("telno : " + telno + "\n");
		//System.out.println("offtelno : " + officephone + "\n");
		//System.out.println("address : " + address + "\n");
		//System.out.println("website : " + website + "\n");
		//System.out.println("drvlicense : " + drvlicense + "\n");

		customerServ.saveCusUser(username, password, yrname, email, telno, officephone, address, website, drvlicense);

		/* Turn User display on */
		//System.out.println("Turn on New User");
		String startmsg = "User : ";
		String usrmsg = username;
		session.setAttribute("startmsg", startmsg);
		session.setAttribute("usrmsg", usrmsg);

		return "index";
	}
	
}