$(document).ready(function() {
	$('#reportCustomer01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Customer Revenue Chart</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportCustomerA.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#reportCustomer02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Last Month' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportCustomerB1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#reportCustomer03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Month-To-Date' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportCustomerB2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#reportCustomer04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Input The Start Date, End Date And Click 'Submit'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportCustomerB3.png\"></div>";
		$('#systemSetupModal').modal();
	});

});


