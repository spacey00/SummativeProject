$(document).ready(function() {
	$('.table .showVideo').on('click', function(event) {
		event.preventDefault();
		var newtemp;
		var table = document.getElementById("table"), rIndex, cIndex;
		for (i = 0; i < table.rows.length; i++) {
				rIndex = this.parentElement.rowIndex;
				var temp = table.rows[rIndex].cells[6].innerHTML;
				var divmain = document.getElementById("videoid");
				newtemp = ["<video style=\"width:760px\" controls type=\"video/mp4\" src=\"\\vehiclephotos\\", temp, "\">"].join('');
				divmain.innerHTML = newtemp;
				$('#videoModal').modal();
		}
	});
});



