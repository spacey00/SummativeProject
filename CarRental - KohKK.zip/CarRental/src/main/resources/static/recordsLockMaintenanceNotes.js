$(document).ready(function() {
	$('#lock01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Report - ID Lock Maintenance</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/lock01.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#lock02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click On The Dropdown Icon Of The ID Type Row To Unlock</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/lock02.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#lock03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>On The Dropdown List, Click On The ID Row To Unlock</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/lock03.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#lock04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click [Unlock] Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/lock04.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#lock05').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click On The [Unlock] Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/lock05.png\"></div>";
		$('#systemSetupModal').modal();
	});

});


