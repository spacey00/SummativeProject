$(document).ready(function() {
	$('#rentVehicle01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Renting Vehicle-Marketing</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionRentMarketA.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#rentVehicle02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Play Vehicle Type Video</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionRentMarketB.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#rentVehicle03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Play Vehicle Slideshow</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionRentMarketC.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#rentVehicle04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Rent' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionRentMarketD.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#rentVehicle05').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Select Customer And Rent Vehicle</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionRentMarketE.png\"></div>";
		$('#systemSetupModal').modal();
	});

});


