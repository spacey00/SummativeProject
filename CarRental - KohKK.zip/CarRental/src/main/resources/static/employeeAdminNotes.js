$(document).ready(function() {
	$('#employeeAdmin01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Employee List</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersEmployeeA.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#employeeAdmin02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Create New Employee' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersEmployeeB1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#employeeAdmin03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Input New Employee Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersEmployeeC1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#employeeAdmin04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Edit' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersEmployeeB2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#employeeAdmin05').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Update Employee Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersEmployeeC2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#employeeAdmin06').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Delete' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersEmployeeB3.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#employeeAdmin07').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Proceed' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersEmployeeC3.png\"></div>";
		$('#systemSetupModal').modal();
	});
});


