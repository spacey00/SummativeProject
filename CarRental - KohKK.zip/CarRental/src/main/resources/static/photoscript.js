$(document).ready(function() {
	$('.table .showImage').on('click', function(event) {
		event.preventDefault();
		var table = document.getElementById("table"), rIndex, cIndex;
		for (i = 0; i < table.rows.length; i++)
			{
					rIndex = this.parentElement.rowIndex;
					var temp = table.rows[rIndex].cells[8].innerHTML;
					var divmain = document.getElementById("imageid");
					var newtemp = ["<img style=\"width:470px\" src=\"\\vehiclephotos\\", temp, "\"/>"].join('');
					divmain.innerHTML = newtemp;
			}
		$('#photoModal').modal();
	});
});



