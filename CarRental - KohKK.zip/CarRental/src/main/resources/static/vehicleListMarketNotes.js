$(document).ready(function() {
	$('#vehicleListMarket01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Renting Vehicle-Marketing</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleListMarketA.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#vehicleListMarket02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Play Vehicle Type Video</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleListMarketB1.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#vehicleListMarket03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Play Vehicle Slideshow</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleListMarketB2.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#vehicleListMarket04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Stop' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleListMarketC2.png\"></div>";
		$('#systemSetupModal').modal();
	});

});


