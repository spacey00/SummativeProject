$(document).ready(function() {
	$('#returnVehicle01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Returning Vehicle</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionReturnVehicleA.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#returnVehicle02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Return' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionReturnVehicleB.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#returnVehicle03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click The 'Proceed' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionReturnVehicleC.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#returnVehicle04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Check 'Paid?' And Click 'Save'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionReturnVehicleD.png\"></div>";
		$('#systemSetupModal').modal();
	});

});


