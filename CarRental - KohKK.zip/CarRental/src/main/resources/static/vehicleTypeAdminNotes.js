$(document).ready(function() {
	$('#vehicleTypeAdmin01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Vehicle Type List</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleTypeA.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#vehicleTypeAdmin02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Create New Vehicle Type' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleTypeB1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#vehicleTypeAdmin03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Input New Vehicle Type Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleTypeC1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#vehicleTypeAdmin04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Edit' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleTypeB2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#vehicleTypeAdmin05').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Update Vehicle Type Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleTypeC2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#vehicleTypeAdmin06').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Delete' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleTypeB3.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#vehicleTypeAdmin07').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Proceed' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/vehicleVehicleTypeC3.png\"></div>";
		$('#systemSetupModal').modal();
	});
});


