$(document).ready(function() {
	$('#reportVehicle01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Vehicle Revenue Chart</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportVehicleA.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#reportVehicle02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Last Month' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportVehicleB1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#reportVehicle03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Month-To-Date' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportVehicleB2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#reportVehicle04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Input The Start Date, End Date And Click 'Submit'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportVehicleB3.png\"></div>";
		$('#systemSetupModal').modal();
	});

});


