$(document).ready(function() {
	$('#hireAdmin01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Hire Records</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/recordsHireA.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#hireAdmin02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Create New Hire' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/recordsHireB1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#hireAdmin03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Input New Hire Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/recordsHireC1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#hireAdmin04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Edit' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/recordsHireB2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#hireAdmin05').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Update Hire Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/recordsHireC2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#hireAdmin06').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Delete' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/recordsHireB3.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#hireAdmin07').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Proceed' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/recordsHireC3.png\"></div>";
		$('#systemSetupModal').modal();
	});
});


