$(document).ready(function() {
	$('#createUserRole').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Create User Roles</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was done during successful login.<br>\
					- 3 roles, namely 'staff', 'manager' and 'admin', were created in this activity.<br>\
					- Users with the role as 'staff' can perform the tasks of renting out vehicles, returning vehicles from rents and generating invoices.<br>\
					- Users with the role as 'manager' would be able to view reports.<br>\
					- Users with the role as 'admin' will have the accessibility to peform all the functionalities provided in this application. 	</div>";

		$('#systemSetupModal').modal();
	});

	$('#createDummyEmployee').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Create (dummy) Employee</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was done during successful login.<br>\
					- An employee with ficticious data was created.<br></div>";

		$('#systemSetupModal').modal();
	});

	$('#createDummyUser').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Create (dummy) User</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was done during successful login.<br>\
					- An user with ficticious data was created.<br></div>";

		$('#systemSetupModal').modal();
	});

	$('#updateUserData').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Update User Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was done during successful login.<br>\
					- This activity is required for security reason.<br>\
					- This is for the user who is setting up the system to replace the username and password of the dummy user with his/her personal username and password.<br></div>";

		$('#systemSetupModal').modal();
	});

	$('#updateEmployeeData').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Update Employee Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was done during successful login.<br>\
					- This is for the user who is setting up the system to replace the employment data of the dummy user with his/her own employment data.<br></div>";

		$('#systemSetupModal').modal();
	});

	$('#setUpEmployeesData').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Set Up Employees Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was not done during successful login.<br>\
					- This is to input the employment data of the company employees into this application system.<br></div>";

		$('#systemSetupModal').modal();
	});

	$('#setUpVehicleTypesData').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Set Up Vehicle Types Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was not done during successful login.<br>\
					- This is to input the data of the types of vehicle that the company has for providing rental service into this application system.<br></div>";

		$('#systemSetupModal').modal();
	});
	
		$('#setUpCustomerData').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Set Up Customers Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was not done during successful login.<br>\
					- This is to input the data of the customers renting the company vehicles into this application system.<br></div>";

		$('#systemSetupModal').modal();
	});
	
			$('#setUpUsersData').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Set Up Users Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was not done during successful login.<br>\
					- This is to input the data of the users who are directly using this application to perform tasks within this application system.<br></div>";

		$('#systemSetupModal').modal();
	});
	
				$('#setUpVehiclesData').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Set Up Vehicles Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was not done during successful login.<br>\
					- This is to input the data of the vehicle that the company has for providing rental service into this application system.<br></div>";

		$('#systemSetupModal').modal();
	});
	
					$('#setUpVehicleHiresData').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Set Up Vehicle Hires Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was not done during successful login.<br>\
					- This is to input the data of the vehicle hire records into this application system.<br></div>";

		$('#systemSetupModal').modal();
	});
	
						$('#setUpInvoicesData').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Set Up Invoices Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div>- This activity was not done during successful login.<br>\
					- This is to input the data of the vehicle hire invoice records into this application system.<br></div>";

		$('#systemSetupModal').modal();
	});
	
	
	
	
	
	
	
});


