$(document).ready(function() {
	$('#rentVehicle01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Returning Vehicle</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionRentVehicleA.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#rentVehicle02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Rent' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionRentVehicleB.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#rentVehicle03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Select Customer And Click Save</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionRentVehicleC.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#returnVehicle04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Check 'Paid?' And Click 'Save'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionReturnVehicleD.png\"></div>";
		$('#systemSetupModal').modal();
	});
});


