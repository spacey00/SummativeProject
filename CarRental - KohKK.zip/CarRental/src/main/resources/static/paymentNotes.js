$(document).ready(function() {
	$('#payment01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Outstanding Invoice</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionPaymentA.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#payment02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Invoice' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionPaymentB.png\"></div>";
		$('#systemSetupModal').modal();
	});

	$('#payment03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Check 'Paid?' And Click 'Save'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/transactionReturnVehicleD.png\"></div>";
		$('#systemSetupModal').modal();
	});

});


