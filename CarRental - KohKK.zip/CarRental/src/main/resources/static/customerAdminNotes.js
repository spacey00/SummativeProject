$(document).ready(function() {
	$('#customerAdmin01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Customer List</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersCustomerA.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#customerAdmin02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Create New Customer' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersCustomerB1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#customerAdmin03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Input New Customer Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersCustomerC1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#customerAdmin04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Edit' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersCustomerB2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#customerAdmin05').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Update Customer Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersCustomerC2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#customerAdmin06').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Delete' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersCustomerB3.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#customerAdmin07').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Proceed' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersCustomerC3.png\"></div>";
		$('#systemSetupModal').modal();
	});
});


