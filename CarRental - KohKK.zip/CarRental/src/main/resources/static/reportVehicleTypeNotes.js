$(document).ready(function() {
	$('#reportVehicleType01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To Vehicle Type Revenue Chart</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportVehicleTypeA.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#reportVehicleType02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Last Month' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportVehicleTypeB1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#reportVehicleType03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Month-To-Date' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportVehicleTypeB2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#reportVehicleType04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Input The Start Date, End Date And Click 'Submit'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/reportVehicleTypeB3.png\"></div>";
		$('#systemSetupModal').modal();
	});

});


