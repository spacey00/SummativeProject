function navload() {
	var user = document.getElementById("userRole").innerHTML;
	if (user.localeCompare("[admin]")==0 || user.localeCompare("[manager]")==0 || user.localeCompare("[staff]")==0) {
	} else {
	document.getElementById("userName").innerHTML = "Facebook/Google User";
	document.getElementById("userRole").innerHTML = "[Visitor]";
	}
}



