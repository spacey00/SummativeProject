$(document).ready(function() {
	$('#appUserAdmin01').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Go To User List</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersAppUserA.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#appUserAdmin02').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Create New App User' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersAppUserB1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#appUserAdmin03').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Input New App User Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersAppUserC1.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#appUserAdmin04').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Edit' Button</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersAppUserB2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#appUserAdmin05').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Update App User Data</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersAppUserC2.png\"></div>";
		$('#systemSetupModal').modal();
	});
	$('#appUserAdmin06').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Delete' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersAppUserB3.png\"></div>";
		$('#systemSetupModal').modal();
	});
		$('#appUserAdmin07').on('click', function(event) {
		event.preventDefault();
		var divheader = document.getElementById("headerid");
		divheader.innerHTML = "<div>Click 'Proceed' Button'</div>"
		var divmain = document.getElementById("bodyid");
		divmain.innerHTML = "<div><img style=\"width:1100px\" src=\"/partnersAppUserC3.png\"></div>";
		$('#systemSetupModal').modal();
	});
});


