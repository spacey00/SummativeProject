Insert Into Approle (ROLENAME) Values ('admin');
Insert Into Approle (ROLENAME) Values ('manager');
Insert Into Approle (ROLENAME) Values ('staff');

Insert Into Employee (NAME, EMAIL, JOBTITLE, PHONE) Values ('Albert', 'albert@carrental.com', 'Administrator', '1234567');
Insert Into Employee (NAME, EMAIL, JOBTITLE, PHONE) Values ('Betty', 'betty@carrental.com', 'Manager', '3434567');
Insert Into Employee (NAME, EMAIL, JOBTITLE, PHONE) Values ('Charlie', 'charlie@carrental.com', 'Staff', '8974567');
Insert Into Employee (NAME, EMAIL, JOBTITLE, PHONE) Values ('David', 'david@carrental.com', 'Staff', '8944567');
Insert Into Employee (NAME, EMAIL, JOBTITLE, PHONE) Values ('Edward', 'edward@carrental.com', 'Staff', '8974599');
Insert Into Employee (NAME, EMAIL, JOBTITLE, PHONE) Values ('Frank', 'frank@carrental.com', 'Staff', '8958599');

Insert Into Vehicletype (BRAND, MODEL, FUELTYPE, GEARTYPE, RATE, VEHICLETYPEVIDEO) Values ('BrandA', 'ModelA', 'Petrol', 'Auto', 100, 'carvideo001.mp4');
Insert Into Vehicletype (BRAND, MODEL, FUELTYPE, GEARTYPE, RATE, VEHICLETYPEVIDEO) Values ('BrandB', 'ModelB', 'Hybrid', 'Manual', 110, 'carvideo002.mp4');
Insert Into Vehicletype (BRAND, MODEL, FUELTYPE, GEARTYPE, RATE, VEHICLETYPEVIDEO) Values ('BrandC', 'ModelC', 'Diesel', 'Manual', 120, 'carvideo003.mp4');
Insert Into Vehicletype (BRAND, MODEL, FUELTYPE, GEARTYPE, RATE, VEHICLETYPEVIDEO) Values ('BrandD', 'ModelD', 'Electric', 'Auto', 130, 'carvideo004.mp4');

Insert Into Appuser (USERNAME, PASSWORD, ENABLED, APPROLE, EMPLOYEE) Values ('user1', '$2y$12$uRp352TfqxZU2xRiBsFlBuqY7a3HlCzAjXeXKj8MWJyG.18wGQlIG', 1, 1, 1);
Insert Into Appuser (USERNAME, PASSWORD, ENABLED, APPROLE, EMPLOYEE) Values ('user2', '$2y$12$PbkJk4hbJiZa3S/hm1Nc7.lwEgAnBk.jXe9TiNbTxlXiij18Wc6.W', 0, 2, 2);
Insert Into Appuser (USERNAME, PASSWORD, ENABLED, APPROLE, EMPLOYEE) Values ('user3', '$2y$12$Mt/FoUY4oeouVRIu2FRCceunQL4fI3waL1rW8dNS7ltn9ejD3ZVU.', 0, 3, 3);
Insert Into Appuser (USERNAME, PASSWORD, ENABLED, APPROLE, EMPLOYEE) Values ('admin', '$2y$12$U6p8EuEQszXIyHD03.GFWegKt74NOgeEmOSKjUzj5kiLOzk6TWTRy', 1, 1, 4);
Insert Into Appuser (USERNAME, PASSWORD, ENABLED, APPROLE, EMPLOYEE) Values ('manager', '$2y$12$QWcxyH/u2tlssIFEMnt27ez0Cr4IPzeH8cCT/kTHCQ6PQmw5gHRHy', 1, 2, 5);
Insert Into Appuser (USERNAME, PASSWORD, ENABLED, APPROLE, EMPLOYEE) Values ('staff', '$2y$12$uxIYgWzsA4NhObn3cxdS2.P8AMB.w.GIiKC2tqjT25MN8kQQnEER.', 1, 3, 6);

Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (1, 2020, 'car001.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (2, 2021, 'car002.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (3, 2021, 'car003.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (4, 2019, 'car004.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (1, 2020, 'car005.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (2, 2018, 'car006.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (3, 2021, 'car007.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (4, 2020, 'car008.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (1, 2019, 'car009.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (2, 2021, 'car010.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (3, 2018, 'car011.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (4, 2019, 'car012.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (1, 2020, 'car013.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (2, 2021, 'car014.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (3, 2021, 'car015.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (4, 2019, 'car016.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (1, 2020, 'car017.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (2, 2018, 'car018.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (3, 2020, 'car019.png');
Insert Into Vehicle (VEHICLETYPE, REGISTEREDYEAR, VEHICLEPHOTO) Values (4, 2018, 'car020.png');

Insert Into Customer (NAME, ADDRESS, PHONE, EMAIL, OFFICENO, WEBSITE, DRIVERLICENCE) Values ('customer1', 'farfaraway', '1234567', 'customer1@car.com', '2345678', 'car@car.com', '5678987');
Insert Into Customer (NAME, ADDRESS, PHONE, EMAIL, OFFICENO, WEBSITE, DRIVERLICENCE) Values ('customer2', 'toonear', '2234567', 'customer2@car.com', '3345678', 'car@car.com', '8678987');
Insert Into Customer (NAME, ADDRESS, PHONE, EMAIL, OFFICENO, WEBSITE, DRIVERLICENCE) Values ('customer3', 'notnear', '2211567', 'customer3@car.com', '3343378', 'car@car.com', '8672387');
Insert Into Customer (NAME, ADDRESS, PHONE, EMAIL, OFFICENO, WEBSITE, DRIVERLICENCE) Values ('customer4', 'notfaraway', '2234997', 'customer4@car.com', '3348978', 'car@car.com', '8677787');
Insert Into Customer (NAME, ADDRESS, PHONE, EMAIL, OFFICENO, WEBSITE, DRIVERLICENCE) Values ('customer5', 'notfar', '2200997', 'customer5@car.com', '3348238', 'car@car.com', '8676587');
Insert Into Customer (NAME, ADDRESS, PHONE, EMAIL, OFFICENO, WEBSITE, DRIVERLICENCE) Values ('customer6', 'faraway', '2230697', 'customer6@car.com', '3342478', 'car@car.com', '8676387');

Insert Into Hire (DATESTART, DATERETURN, CUSTOMER, VEHICLE, APPUSER) Values ('2-2-2021', '3-3-2021', 1, 1, 1);
Insert Into Hire (DATESTART, DATERETURN, CUSTOMER, VEHICLE, APPUSER) Values ('3-2-2021', '1-3-2021', 6, 2, 2);
Insert Into Hire (DATESTART, DATERETURN, CUSTOMER, VEHICLE, APPUSER) Values ('2-3-2021', '6-3-2021', 5, 2, 2);
Insert Into Hire (DATESTART, DATERETURN, CUSTOMER, VEHICLE, APPUSER) Values ('7-3-2021', '15-3-2021', 6, 2, 2);
Insert Into Hire (DATESTART, DATERETURN, CUSTOMER, VEHICLE, APPUSER) Values ('23-3-2021', '25-3-2021', 5, 5, 2);
Insert Into Hire (DATESTART, DATERETURN, CUSTOMER, VEHICLE, APPUSER) Values ('27-3-2021', '12-4-2021', 5, 6, 2);

Insert Into Hire (DATESTART, CUSTOMER, VEHICLE, APPUSER) Values ('2-4-2021', 1, 1, 4);
Insert Into Hire (DATESTART, CUSTOMER, VEHICLE, APPUSER) Values ('13-4-2021', 2, 2, 2);
Insert Into Hire (DATESTART, CUSTOMER, VEHICLE, APPUSER) Values ('31-3-2021', 3, 3, 3);
Insert Into Hire (DATESTART, CUSTOMER, VEHICLE, APPUSER) Values ('3-4-2021', 4, 4, 5);

Insert Into Invoice (INVOICEDATE, HIRE, PAID) Values ('4-3-2021', 1, 1);
Insert Into Invoice (INVOICEDATE, HIRE, PAID) Values ('5-3-2021', 2, 0);
Insert Into Invoice (INVOICEDATE, HIRE, PAID) Values ('7-3-2021', 3, 0);
Insert Into Invoice (INVOICEDATE, HIRE, PAID) Values ('16-3-2021', 4, 1);
Insert Into Invoice (INVOICEDATE, HIRE, PAID) Values ('25-3-2021', 5, 0);
Insert Into Invoice (INVOICEDATE, HIRE, PAID) Values ('13-4-2021', 6, 1);


