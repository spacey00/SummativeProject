package com.carrental;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.carrental.controller.AppUserController;
import com.carrental.controller.CustomerController;
import com.carrental.controller.EmployeeController;
import com.carrental.controller.HireController;
import com.carrental.controller.InvoiceController;
import com.carrental.controller.VehicleController;
import com.carrental.controller.VehicleTypeController;

@Configuration
public class HttpSessionConfig {
	public static final Map<String, String> sessionIdUser = new HashMap<>();

	@Bean
	public HttpSessionListener httpSessionListener() {
		return new HttpSessionListener() {
			@Override
			public void sessionCreated(HttpSessionEvent hse) {

			}

			public void updateLocks(HashMap<Integer, String> amendmentInProgress, HttpSessionEvent hse) {
				for (Map.Entry<Integer, String> entry : amendmentInProgress.entrySet()) {
					if ((entry.getValue()).equals(hse.getSession().getAttribute("user"))) {
						amendmentInProgress.remove(entry.getKey());
						break;
					}
				}
			}

			@Override
			public synchronized void sessionDestroyed(HttpSessionEvent hse) {
				if (sessionIdUser.containsKey(hse.getSession().getId())) {
					if (AppUserController.appUserAmendmentInProgress
							.containsValue(hse.getSession().getAttribute("user").toString())) {
						updateLocks(AppUserController.appUserAmendmentInProgress, hse);
					} else if (CustomerController.customerAmendmentInProgress
							.containsValue(hse.getSession().getAttribute("user").toString())) {
						updateLocks(CustomerController.customerAmendmentInProgress, hse);
					} else if (EmployeeController.employeeAmendmentInProgress
							.containsValue(hse.getSession().getAttribute("user").toString())) {
						updateLocks(EmployeeController.employeeAmendmentInProgress, hse);
					} else if (HireController.hireAmendmentInProgress
							.containsValue(hse.getSession().getAttribute("user").toString())) {
						updateLocks(HireController.hireAmendmentInProgress, hse);
					} else if (InvoiceController.invoiceAmendmentInProgress
							.containsValue(hse.getSession().getAttribute("user").toString())) {
						updateLocks(InvoiceController.invoiceAmendmentInProgress, hse);
					} else if (VehicleController.vehicleAmendmentInProgress
							.containsValue(hse.getSession().getAttribute("user").toString())) {
						updateLocks(VehicleController.vehicleAmendmentInProgress, hse);
					} else if (VehicleTypeController.vehicleTypeAmendmentInProgress
							.containsValue(hse.getSession().getAttribute("user").toString())) {
						updateLocks(VehicleTypeController.vehicleTypeAmendmentInProgress, hse);
					}
					sessionIdUser.remove(hse.getSession().getId());
				}
			}
		};
	}
}
