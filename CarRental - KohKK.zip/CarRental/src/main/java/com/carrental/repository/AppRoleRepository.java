package com.carrental.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.carrental.model.Approle;

public interface AppRoleRepository extends JpaRepository<Approle, Integer> {

}
