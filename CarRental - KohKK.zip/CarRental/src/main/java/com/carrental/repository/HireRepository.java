package com.carrental.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.carrental.model.Hire;
import com.carrental.model.Vehicle;

public interface HireRepository extends JpaRepository<Hire, Integer> {
	@Query("SELECT h FROM Hire h WHERE LOWER(CONCAT('*', h.hireid, function('to_char', h.datestart, 'DD-MM-YYYY'), function('to_char', h.datereturn, 'DD-MM-YYYY'), h.customer.customerid, h.customer.name, h.vehicle.vehicleid, h.vehicle.vehicleobj.brand, h.vehicle.vehicleobj.model, h.appuser.username)) LIKE %?1%")
	public Page<Hire> findAll(String keyword, Pageable pageable);
	
	@Query("SELECT h FROM Hire h WHERE h.vehicle=:vehicle AND ((h.datestart<:datereturn OR :datereturn=null) AND (h.datereturn>:datestart OR h.datereturn=null))")
	public List<Hire> findConflictSchedule(@Param("vehicle") Vehicle vehicle, @Param("datestart") Date datestart, @Param("datereturn") Date datereturn);

	@Query("SELECT h FROM Hire h WHERE h.vehicle=:vehicle")
	public List<Hire> findHiresByVehicle(@Param("vehicle") Vehicle vehicle);
	
	@Query("SELECT h FROM Hire h WHERE ((h.datestart<=:datereturn) AND (h.datereturn>=:datestart OR h.datereturn=null))")
	public List<Hire> findHiresBetweenDates(@Param("datestart") Date datestart, @Param("datereturn") Date datereturn);

	@Query("SELECT h From Hire h Where h.datereturn!=null AND h NOT IN (SELECT i.hire FROM Invoice i)")
	public List<Hire> hirePendingInvoice();

	@Query("SELECT i.hire From Invoice i")
	public List<Hire> hireWithInvoice();
}
