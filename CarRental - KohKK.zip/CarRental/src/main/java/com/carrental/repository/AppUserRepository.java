package com.carrental.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.carrental.model.Appuser;

public interface AppUserRepository extends JpaRepository<Appuser, Integer> {
	@Query("SELECT u FROM Appuser u WHERE u.username = :username")
	public Appuser getUserByUsername(@Param("username") String username);

	@Query("SELECT u FROM Appuser u WHERE LOWER(CONCAT('*', u.appuserid, u.username, CASE WHEN u.enabled > 0 THEN 'true' ELSE 'false' END, u.roleobj.rolename, u.employee.employeeid, u.employee.name, u.employee.email, u.employee.jobtitle, u.employee.phone)) LIKE %?1%")
	public Page<Appuser> findAll(String keyword, Pageable pageable);

}
