package com.carrental.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.carrental.model.Hire;

public interface RentOutRepository extends JpaRepository<Hire, Integer> {
	@Query("SELECT h FROM Hire h WHERE h.datereturn=null AND LOWER(CONCAT('*', h.hireid, function('to_char', h.datestart, 'DD-MM-YYYY'), h.customer.customerid, h.customer.name, h.vehicle.vehicleid, h.vehicle.vehicleobj.brand, h.vehicle.vehicleobj.model, h.vehicle.vehicleobj.fueltype, h.vehicle.vehicleobj.geartype, '$', h.vehicle.vehicleobj.rate, '/day', h.vehicle.registeredyear, h.vehicle.vehiclephoto)) LIKE %?1%")
	public Page<Hire> findAll(String keyword, Pageable pageable);
	
	@Query("SELECT h FROM Hire h WHERE h.datereturn=null ")
	public Page<Hire> findAll(Pageable pageable);
	
	@Query("SELECT h FROM Hire h WHERE h.datereturn=null ")
	public List<Hire> findAll();
}
