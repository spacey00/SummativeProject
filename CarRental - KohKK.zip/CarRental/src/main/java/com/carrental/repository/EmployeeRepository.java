package com.carrental.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.carrental.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	@Query("SELECT e FROM Employee e WHERE LOWER(CONCAT('*', e.employeeid, e.name, e.email, e.jobtitle, e.phone)) LIKE %?1%")
	public Page<Employee> findAll(String keyword, Pageable pageable);
	
	@Query("SELECT e From Employee e Where e NOT IN (SELECT a.employee FROM Appuser a)")
	public List<Employee> noAppUserAccount();
	
	@Query("SELECT a.employee From Appuser a")
	public List<Employee> withAppUserAccount();
	
}
