package com.carrental.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.carrental.model.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice, Integer> {
	@Query("SELECT i FROM Invoice i WHERE LOWER(CONCAT('*', i.invoiceid, function('to_char', i.invoicedate, 'DD-MM-YYYY'), i.hire.hireid, function('to_char', i.hire.datestart, 'DD-MM-YYYY'), function('to_char', i.hire.datereturn, 'DD-MM-YYYY'), i.hire.customer.customerid, i.hire.customer.name, CASE WHEN i.paid > 0 THEN 'true' ELSE 'false' END)) LIKE %?1%")
	public Page<Invoice> findAll(String keyword, Pageable pageable);

}
