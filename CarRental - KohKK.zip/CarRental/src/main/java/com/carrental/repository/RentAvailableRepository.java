package com.carrental.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.carrental.model.Vehicle;

public interface RentAvailableRepository extends JpaRepository<Vehicle, Integer>  {
	@Query("SELECT v FROM Vehicle v Where v NOT IN (Select h.vehicle From Hire h WHERE h.datereturn=null) AND LOWER(CONCAT('*', v.vehicleid, v.vehicleobj.brand, v.vehicleobj.model, v.vehicleobj.fueltype, v.vehicleobj.geartype, '$', v.vehicleobj.rate, '/day', v.registeredyear, v.vehiclephoto)) LIKE %?1%")
	public Page<Vehicle> findAll(String keyword, Pageable pageable);

	@Query("SELECT v From Vehicle v Where v NOT IN (SELECT h.vehicle FROM Hire h Where h.datereturn=null)")
	public Page<Vehicle> findAll(Pageable pageable);
	
	@Query("SELECT v From Vehicle v Where v NOT IN (SELECT h.vehicle FROM Hire h Where h.datereturn=null)")
	public List<Vehicle> findAll();
	
}
