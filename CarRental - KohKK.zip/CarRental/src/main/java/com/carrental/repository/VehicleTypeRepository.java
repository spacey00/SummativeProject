package com.carrental.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.carrental.model.Vehicletype;

public interface VehicleTypeRepository extends JpaRepository<Vehicletype, Integer> {
	@Query("SELECT vt FROM Vehicletype vt WHERE LOWER(CONCAT('*', vt.vehicletypeid, vt.brand, vt.model, vt.fueltype, vt.geartype, '$\', vt.rate, '/day', vt.vehicletypevideo)) LIKE %?1%")
	public Page<Vehicletype> findAll(String keyword, Pageable pageable);
}
