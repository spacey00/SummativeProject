package com.carrental.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.carrental.model.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Integer>{
	@Query("SELECT v FROM Vehicle v WHERE LOWER(CONCAT('*', v.vehicleid, v.vehicleobj.brand, v.vehicleobj.model, v.vehicleobj.fueltype, v.vehicleobj.geartype, '$', v.vehicleobj.rate, '/day', v.registeredyear, v.vehiclephoto)) LIKE %?1%")
	public Page<Vehicle> findAll(String keyword, Pageable pageable);

}
