package com.carrental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import uk.org.lidalia.sysoutslf4j.context.SysOutOverSLF4J;

@EnableAspectJAutoProxy
@SpringBootApplication
public class CarRentalApplication {

	public static void main(String[] args) {
		SysOutOverSLF4J.sendSystemOutAndErrToSLF4J();
		SpringApplication.run(CarRentalApplication.class, args);
	}
}
