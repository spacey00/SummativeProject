package com.carrental.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Vehicletype {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer vehicletypeid;
	@Min(10)
	@NotNull
	private Double rate;
	@Size(min=2)
	@NotNull
	private String brand;
	@Size(min=2)
	@NotNull
	private String model;
	@Size(min=2)
	@NotNull
	private String fueltype;
	@Size(min=2)
	@NotNull
	private String geartype;
	@Column(nullable = true, length = 64)
	private String vehicletypevideo;

	@Override
	public String toString() {
		return "Type:" + vehicletypeid + ", $" + rate + "/day, " + brand + ", "
				+ model + ", " + fueltype + ", " + geartype;
	}

	public Vehicletype() {

	}

	public Vehicletype(Integer vehicletypeid, Double rate, String brand, String model, String fueltype,
			String geartype) {
		this.vehicletypeid = vehicletypeid;
		this.rate = rate;
		this.brand = brand;
		this.model = model;
		this.fueltype = fueltype;
		this.geartype = geartype;
	}

	public void setVehicletypeid(Integer vehicletypeid) {
		this.vehicletypeid = vehicletypeid;
	}

	public Integer getVehicletypeid() {
		return vehicletypeid;
	}

	public Double getRate() {
		return rate;
	}
	
	public void setRate(Double rate) {
		this.rate = rate;
	}
	
	public String getBrand() {
		return brand;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public String getModel() {
		return model;
	}
	
	public void setModel(String model) {
		this.model = model;
	}
	
	public String getFueltype() {
		return fueltype;
	}
	
	public void setFueltype(String fueltype) {
		this.fueltype = fueltype;
	}
	
	public String getGeartype() {
		return geartype;
	}
	
	public void setGeartype(String geartype) {
		this.geartype = geartype;
	}

	
	public String getVehicletypevideo() {
		return vehicletypevideo;
	}

	public void setVehicletypevideo(String vehicletypevideo) {
		this.vehicletypevideo = vehicletypevideo;
	}

	@Transient
	public String getVideoPath() {
		if (vehicletypevideo == null)
			return null;
		return "/vehiclephotos/" + vehicletypevideo;
	}
}
