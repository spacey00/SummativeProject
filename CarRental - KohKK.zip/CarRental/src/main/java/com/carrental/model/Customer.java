package com.carrental.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer customerid;
	
	@NotNull
	@Size(min=2, max=20)
	private String name;
	
	@Size(min=2, max=50)
	private String address;
	
	@NotNull
	@Size(min=6, max=20)
	private String phone;
	
	@NotNull
	@Email
	private String email;
	
	@Size(min=6, max=20)
	private String officeno;

	@Size(min=3, max=30)
	private String website;
	
	@NotNull
	@Size(min=2, max=20)
	private String driverlicence;

	@Override
	public String toString() {
		return "ID:" + customerid + ", Name:" + name + ", Phone:" + phone
				+ ", Office No:" + officeno + ", Licence:"
				+ driverlicence;
	}

	public Customer() {

	}

	public Customer(Integer customerid, @Size(min = 2) String name, @Size(min = 2) String address,
			@Size(min = 6) String phone, @Email String email, @Size(min = 6) String officeno,
			@Size(min = 3) String website, @Size(min = 2) String driverlicence) {
		this.customerid = customerid;
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.officeno = officeno;
		this.website = website;
		this.driverlicence = driverlicence;
	}

	public Integer getCustomerid() {
		return customerid;
	}

	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOfficeno() {
		return officeno;
	}

	public void setOfficeno(String officeno) {
		this.officeno = officeno;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getDriverlicence() {
		return driverlicence;
	}

	public void setDriverlicence(String driverlicence) {
		this.driverlicence = driverlicence;
	}
}
