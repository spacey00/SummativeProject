package com.carrental.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Appuser {
	@Id
	@Column(name = "appuserid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer appuserid;
	
	@Size(min=2, max=20)
	private String username;
	
	@Column(length = 150)	// This is required for Bcrypt passwords (length)
	@NotNull
	private String password;

	private Boolean enabled;
	
	@ManyToOne
	@JoinColumn(name= "approle")		// (=> column name on database table = "approle")
	private Approle roleobj;	// define the data type as the object to be joined.
	
	@OneToOne
	@JoinColumn(name="employee")
	private Employee employee;

	@Override
	public String toString() {
		return "ID:" + appuserid + ", User:" + username + ", Role:" + roleobj.getRolename() + ", Employee ID:" + employee.getEmployeeid();
	}

	public Appuser() {

	}

	public Appuser(@Size(min = 2, max = 20) String username, @NotNull String password, Boolean enabled, Approle roleobj,
			Employee employee) {
		this.username = username;
		this.password = password;
		this.enabled = enabled;
		this.roleobj = roleobj;
		this.employee = employee;
	}

	public Appuser(Integer appuserid, @Size(min = 2) String username, String password, Boolean enabled, Approle roleobj,
			@NotNull Employee employee) {
		this.appuserid = appuserid;
		this.username = username;
		this.password = password;
		this.enabled = enabled;
		this.roleobj = roleobj;
		this.employee = employee;
	}

	public Integer getAppuserid() {
		return appuserid;
	}

	public void setAppuserid(Integer appuserid) {
		this.appuserid = appuserid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public Approle getRoleobj() {
		return roleobj;
	}

	public void setRoleobj(Approle roleobj) {
		this.roleobj = roleobj;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
}
