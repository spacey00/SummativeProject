package com.carrental.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer employeeid;
	
	@NotNull
	@Size(min=2, max=20)
	private String name;
	
	@NotNull
	@Email
	private String email;
	
	@NotNull
	@Size(min=2, max=20)
	private String jobtitle;
	
	@NotNull
	@Size(min=6, max=20)
	private String phone;

	@Override
	public String toString() {
		return "Employee [employeeid=" + employeeid + ", name=" + name + ", email=" + email + ", jobtitle="
				+ jobtitle + ", phone=" + phone +  "]";
	}
	
	public Employee() {

	}

	public Employee(@NotNull @Size(min = 2, max = 20) String name, @NotNull @Email String email,
			@NotNull @Size(min = 2, max = 20) String jobtitle, @NotNull @Size(min = 6, max = 20) String phone) {
		this.name = name;
		this.email = email;
		this.jobtitle = jobtitle;
		this.phone = phone;
	}

	public Employee(Integer employeeid, @NotNull @Size(min = 2, max = 20) String name, @NotNull @Email String email,
			@NotNull @Size(min = 2, max = 20) String jobtitle, @NotNull @Size(min = 6, max = 20) String phone) {
		this.employeeid = employeeid;
		this.name = name;
		this.email = email;
		this.jobtitle = jobtitle;
		this.phone = phone;
	}
	
	public Integer getEmployeeid() {
		return employeeid;
	}
	
	public void setEmployeeid(Integer employeeid) {
		this.employeeid = employeeid;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getJobtitle() {
		return jobtitle;
	}
	
	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
}
