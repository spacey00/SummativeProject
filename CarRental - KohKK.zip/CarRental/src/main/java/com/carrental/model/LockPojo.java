package com.carrental.model;

import java.util.HashMap;
import java.util.Map;

public class LockPojo {
	private String lockid;
	public HashMap<Integer, String> lockmap = new HashMap<>();
	public Map<String, String> lockmapLogin = new HashMap<>();
	private String lockLogin;
	private int lock;

	public Map<String, String> getLockmapLogin() {
		return lockmapLogin;
	}
	public void setLockmapLogin(Map<String, String> lockmapLogin) {
		this.lockmapLogin = lockmapLogin;
	}
	public String getLockLogin() {
		return lockLogin;
	}
	public void setLockLogin(String lockLogin) {
		this.lockLogin = lockLogin;
	}

	public String getLockid() {
		return lockid;
	}
	public void setLockid(String lockid) {
		this.lockid = lockid;
	}
	public HashMap<Integer, String> getLockmap() {
		return lockmap;
	}
	public void setLockmap(HashMap<Integer, String> lockmap) {
		this.lockmap = lockmap;
	}
	public int getLock() {
		return lock;
	}
	public void setLock(int lock) {
		this.lock = lock;
	}
	public LockPojo(String lockid, HashMap<Integer, String> lockmap) {
		this.lockid = lockid;
		this.lockmap = lockmap;
	}

	public LockPojo(String lockid, int lock) {
		this.lockid = lockid;
		this.lock = lock;
	}
	public LockPojo() {

	}

	public LockPojo(String lockid, String lockLogin) {
		this.lockid = lockid;
		this.lockLogin = lockLogin;
	}
	public LockPojo(String lockid, Map<String, String> lockmapLogin) {
		this.lockid = lockid;
		this.lockmapLogin = lockmapLogin;
	}
	@Override
	public String toString() {
		return "LockPojo [lockid=" + lockid + ", lockmap=" + lockmap + ", lock=" + lock + "]";
	}

}
