package com.carrental.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class Approle {
	@Id
	@Column(name = "approleid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer approleid;
	@NotNull
	private String rolename;

	@Override
	public String toString() {
		return rolename;
	}
	
	public Approle() {

	}

	public Approle(String rolename) {
		this.rolename = rolename;
	}
	
	public Approle(Integer approleid, String rolename) {
		this.approleid = approleid;
		this.rolename = rolename;
	}
	
	public Integer getApproleid() {
		return approleid;
	}
	
	public void setApproleid(Integer approleid) {
		this.approleid = approleid;
	}
	
	public String getRolename() {
		return rolename;
	}
	
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
}
