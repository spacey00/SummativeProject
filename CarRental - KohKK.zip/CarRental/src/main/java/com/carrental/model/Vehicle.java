package com.carrental.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
public class Vehicle {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer vehicleid;
	
	@NotNull
	@ManyToOne
	@JoinColumn(name= "vehicletype")		// (=> column name on database table = "vehicletype")
	private Vehicletype vehicleobj;	// define the data type as the object to be joined.

	@Pattern(regexp="^[2-9]{1}[0-9]{3}",message="must be within the range of [2000] and [9999]")
	@NotNull
	private String registeredyear;
	
	@Column(nullable = true, length = 64)
	private String vehiclephoto;

	@Override
	public String toString() {
		return "ID:" + vehicleid + ", " + vehicleobj + ", Year:" + registeredyear;
	}

	public Vehicle() {

	}

	public Vehicle(Integer vehicleid, Vehicletype vehicleobj, String registeredyear) {
		super();
		this.vehicleid = vehicleid;
		this.vehicleobj = vehicleobj;
		this.registeredyear = registeredyear;
	}

	public void setVehicleid(Integer vehicleid) {
		this.vehicleid = vehicleid;
	}

	public Integer getVehicleid() {
		return vehicleid;
	}

	public Vehicletype getVehicleobj() {
		return vehicleobj;
	}

	public void setVehicleobj(Vehicletype vehicleobj) {
		this.vehicleobj = vehicleobj;
	}

	public String getRegisteredyear() {
		return registeredyear;
	}

	public void setRegisteredyear(String registeredyear) {
		this.registeredyear = registeredyear;
	}

	public String getVehiclephoto() {
		return vehiclephoto;
	}

	public void setVehiclephoto(String vehiclephoto) {
		this.vehiclephoto = vehiclephoto;
	}

	@Transient
	public String getPhotosImagePath() {
		if (vehiclephoto == null)
			return "/vehiclephotos/nocar.png";
		return "/vehiclephotos/" + vehiclephoto;
	}
}
