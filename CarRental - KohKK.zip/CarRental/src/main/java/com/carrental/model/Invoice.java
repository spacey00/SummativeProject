package com.carrental.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Invoice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer invoiceid;
	
	@NotNull
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date invoicedate;
	
	private String invoicedateCsv;	// dummy string to export correct date to CSV 
	
	@OneToOne
	@JoinColumn(name="hire")
	@NotNull
	private Hire hire;
	
	@NotNull
	private Boolean paid;
	
	@Override
	public String toString() {
		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		String invoicedateStr = invoicedate==null ? "no date" : dateFormatter.format(invoicedate);
		String status = paid? "Paid" : "Unpaid";
		
		return "ID:" + invoiceid + ", invoicedate=" + invoicedateStr + ", hire=" + hire + ", " + status;
	}
	
	public Invoice() {

	}

	public Invoice(Date invoicedate, @NotNull Hire hire, Boolean paid) {
		this.invoicedate = invoicedate;
		this.hire = hire;
		this.paid = paid;
	}
	
	public Invoice(Integer invoiceid, Date invoicedate, @NotNull Hire hire, Boolean paid) {
		this.invoiceid = invoiceid;
		this.invoicedate = invoicedate;
		this.hire = hire;
		this.paid = paid;
	}
	
	public Integer getInvoiceid() {
		return invoiceid;
	}
	
	public void setInvoiceid(Integer invoiceid) {
		this.invoiceid = invoiceid;
	}
	
	public Date getInvoicedate() {
		return invoicedate;
	}
	
	public String getInvoicedateCsv() {
		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		return invoicedate==null ? "" : dateFormatter.format(invoicedate);
	}
	
	public void setInvoicedate(Date invoicedate) {
		this.invoicedate = invoicedate;
	}
	public Hire getHire() {
		return hire;
	}
	
	public void setHire(Hire hire) {
		this.hire = hire;
	}
	
	public Boolean getPaid() {
		return paid;
	}
	
	public void setPaid(Boolean paid) {
		this.paid = paid;
	}
}
