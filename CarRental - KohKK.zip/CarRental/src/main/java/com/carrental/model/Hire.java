package com.carrental.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Hire {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer hireid;
	
	@NotNull
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date datestart;
	private String datestartCsv;	// dummy string to export correct date to CSV 
	
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date datereturn;
	private String datereturnCsv;	// dummy string to export correct date to CSV 
	
	@NotNull
	@ManyToOne
	@JoinColumn(name= "customer")
	private Customer customer;
	
	@NotNull
	@ManyToOne
	@JoinColumn(name= "vehicle")
	private Vehicle vehicle;
	
	@NotNull
	@ManyToOne
	@JoinColumn(name= "appuser")
	private Appuser appuser;

	@Override
	public String toString() {
        DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
        String datestartStr = datestart==null ? "no date" : dateFormatter.format(datestart);
        String datereturnStr = datereturn==null ? "no date" : dateFormatter.format(datereturn);

		return "Hire ID:" + hireid + ", Start:" + datestartStr + ", Return:" + datereturnStr + ", Customer ID:"
				+ customer.getCustomerid() + ", Vehicle ID:" + vehicle.getVehicleid();
	}	
	
	public Hire() {

	}

	public Hire(Integer hireid, Date datestart, Date datereturn, Customer customer, Vehicle vehicle, Appuser appuser) {
		this.hireid = hireid;
		this.datestart = datestart;
		this.datereturn = datereturn;
		this.customer = customer;
		this.vehicle = vehicle;
		this.appuser = appuser;
	}

	public Integer getHireid() {
		return hireid;
	}

	public void setHireid(Integer hireid) {
		this.hireid = hireid;
	}

	public Date getDatestart() {
		return datestart;
	}
	
	public String getDatestartCsv() {
		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		return datestart==null? "" : dateFormatter.format(datestart);
	}

	public void setDatestart(Date datestart) {
		this.datestart = datestart;
	}

	public Date getDatereturn() {
		return datereturn;
	}
	
	public String getDatereturnCsv() {
		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		return datereturn==null? "" : dateFormatter.format(datereturn);
	}

	public void setDatereturn(Date datereturn) {
		this.datereturn = datereturn;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public Appuser getAppuser() {
		return appuser;
	}

	public void setAppuser(Appuser appuser) {
		this.appuser = appuser;
	}
}
