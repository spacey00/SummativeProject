package com.carrental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.carrental.model.Invoice;
import com.carrental.repository.InvoiceRepository;

@Service
public class InvoiceService {
	@Autowired
	private InvoiceRepository invoiceRepo;

	public Page<Invoice> listAll(int pageNumber, String sortField, String sortDir, String keyword) {
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNumber - 1, 5, sort);
		keyword = keyword.toLowerCase();
		return invoiceRepo.findAll(keyword, pageable);
	}

	public void save(Invoice invoice) {
		invoiceRepo.save(invoice);
	}

	public Invoice get(Integer id) {
		return invoiceRepo.findById(id).get();
	}

	public void delete(Integer id) {
		invoiceRepo.deleteById(id);
	}
}
