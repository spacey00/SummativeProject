package com.carrental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.carrental.model.Appuser;
import com.carrental.model.MyUserDetails;
import com.carrental.repository.AppUserRepository;

public class UserDetailsServiceImpl implements UserDetailsService {
	@Autowired
	private AppUserRepository appUserRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) 
			throws UsernameNotFoundException {
		Appuser appuser = appUserRepository.getUserByUsername(username);
		
		if (appuser == null) {
			throw new UsernameNotFoundException("Could not find user");
		}
		return new MyUserDetails(appuser);
	}
}
