package com.carrental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.carrental.model.Hire;
import com.carrental.repository.HireRepository;

@Service
public class HireService {
	@Autowired
	private HireRepository hireRepo;

	public Page<Hire> listAll(int pageNumber, String sortField, String sortDir, String keyword) {
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNumber - 1, 5, sort);
		keyword = keyword.toLowerCase();
		return hireRepo.findAll(keyword, pageable);
	}

	public void save(Hire hire) {
		hireRepo.save(hire);
	}

	public Hire get(Integer id) {
		return hireRepo.findById(id).get();
	}

	public void delete(Integer id) {
		hireRepo.deleteById(id);
	}
}
