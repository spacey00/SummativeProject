package com.carrental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.carrental.model.Hire;
import com.carrental.repository.RentOutRepository;

@Service
public class RentOutService {
	@Autowired
	private RentOutRepository rentOutRepo;
	
	public Page<Hire> listAll(int pageNumber, String sortField, String sortDir, String keyword){
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNumber-1, 5,sort);
			keyword=keyword.toLowerCase();
		return rentOutRepo.findAll(keyword,pageable);
	}
	
	public void save(Hire hire) {
		rentOutRepo.save(hire);
	}

	public Hire get(Integer id) {
		return rentOutRepo.findById(id).get();
	}
}
