package com.carrental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.carrental.model.Vehicle;
import com.carrental.repository.VehicleRepository;

@Service
public class VehicleService {
	@Autowired
	private VehicleRepository vehicleRepo;

	public Page<Vehicle> listAll(int pageNumber, String sortField, String sortDir, String keyword) {
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNumber - 1, 5, sort);
		keyword = keyword.toLowerCase();
		return vehicleRepo.findAll(keyword, pageable);
	}

	public void save(Vehicle vehicle) {
		vehicleRepo.save(vehicle);
	}

	public Vehicle get(Integer id) {
		return vehicleRepo.findById(id).get();
	}

	public void delete(Integer id) {
		vehicleRepo.deleteById(id);
	}
}
