package com.carrental.service;

import java.awt.Color;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.carrental.model.Hire;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class OnHirePdfExporter {
    private List<Hire> listOnHires;
    
    public OnHirePdfExporter(List<Hire> listOnHires) {
        this.listOnHires = listOnHires;
    }
 
    private void writeTableHeader(PdfPTable table) {
        PdfPCell cell = new PdfPCell();
        cell.setPadding(5);
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setColor(Color.BLUE);
        font.setSize(8);
        cell.setHorizontalAlignment(1);
         
        cell.setPhrase(new Phrase("Hire ID", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Date Start", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("Customer ID", font));
        table.addCell(cell);

        cell.setPhrase(new Phrase("Customer Name", font));
        table.addCell(cell);
        
        cell.setPhrase(new Phrase("Vehicle ID", font));
        table.addCell(cell);
        
        cell.setPhrase(new Phrase("Brand", font));
        table.addCell(cell);
        
        cell.setPhrase(new Phrase("Model", font));
        table.addCell(cell);
        
        cell.setPhrase(new Phrase("Fuel Type", font));
        table.addCell(cell);
        
        cell.setPhrase(new Phrase("Gear Type", font));
        table.addCell(cell);
        
        cell.setPhrase(new Phrase("Rate", font));
        table.addCell(cell);
        
        cell.setPhrase(new Phrase("Registered Year", font));
        table.addCell(cell);
    }
     
    private void writeTableData(PdfPTable table) {
        PdfPCell cell = new PdfPCell();
        cell.setPadding(5);
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setSize(8);
    	SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        for (Hire onHire : listOnHires) {
            cell.setPhrase(new Phrase(String.valueOf(onHire.getHireid()), font));
            cell.setHorizontalAlignment(1);
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf(formatter.format(onHire.getDatestart())), font));
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf(onHire.getCustomer().getCustomerid()), font));
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf(onHire.getCustomer().getName()), font));
            cell.setHorizontalAlignment(0);
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf(onHire.getVehicle().getVehicleid()), font));
            cell.setHorizontalAlignment(1);
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf(onHire.getVehicle().getVehicleobj().getBrand()), font));
            cell.setHorizontalAlignment(0);
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf(onHire.getVehicle().getVehicleobj().getModel()), font));
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf(onHire.getVehicle().getVehicleobj().getFueltype()), font));
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf(onHire.getVehicle().getVehicleobj().getGeartype()), font));
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf("$" + onHire.getVehicle().getVehicleobj().getRate() + "/day"), font));
            table.addCell(cell);
            cell.setPhrase(new Phrase(String.valueOf(onHire.getVehicle().getRegisteredyear()), font));
            cell.setHorizontalAlignment(1);
            table.addCell(cell);
        }
    }
     
    public void export(HttpServletResponse response) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, response.getOutputStream());
         
        document.open();
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setSize(18);
        font.setColor(Color.WHITE);
        PdfPTable tableH = new PdfPTable(1);
        tableH.setWidthPercentage(100f);
        tableH.setWidths(new float[] {9.9f});
        tableH.setSpacingBefore(10);
        PdfPCell cellH = new PdfPCell();
        cellH.setBackgroundColor(Color.BLUE);
        cellH.setPhrase(new Phrase("List Of On Hire Vehicles", font));
        cellH.setHorizontalAlignment(1);
        cellH.setBorder(0);
        cellH.setPadding(10);
        tableH.addCell(cellH);
        document.add(tableH);
         
        PdfPTable table = new PdfPTable(11);
        table.setWidthPercentage(100f);
        table.setWidths(new float[] {1.5f, 2.5f, 2.5f, 2.5f, 2.5f, 2.5f, 2.5f, 2.5f, 2.5f, 3.0f, 2.0f});
        table.setSpacingBefore(10);
         
        writeTableHeader(table);
        writeTableData(table);
         
        document.add(table);
        document.close();
    }
}
