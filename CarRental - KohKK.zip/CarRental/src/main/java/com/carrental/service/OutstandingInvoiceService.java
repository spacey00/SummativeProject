package com.carrental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.carrental.model.Invoice;
import com.carrental.repository.OutstandingInvoiceRepository;

@Service
public class OutstandingInvoiceService {
	@Autowired
	private OutstandingInvoiceRepository outstandingInvoiceRepo;

	public Page<Invoice> listAll(int pageNumber, String sortField, String sortDir, String keyword) {
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNumber - 1, 5, sort);
		keyword = keyword.toLowerCase();
		return outstandingInvoiceRepo.findAll(keyword, pageable);
	}

	public void save(Invoice invoice) {
		outstandingInvoiceRepo.save(invoice);
	}

	public Invoice get(Integer id) {
		return outstandingInvoiceRepo.findById(id).get();
	}

	public void delete(Integer id) {
		outstandingInvoiceRepo.deleteById(id);
	}
}
