package com.carrental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.carrental.model.Customer;
import com.carrental.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepo;

	public Page<Customer> listAll(int pageNumber, String sortField, String sortDir, String keyword) {
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNumber - 1, 5, sort);
		keyword = keyword.toLowerCase();
		return customerRepo.findAll(keyword, pageable);
	}

	public void save(Customer customer) {
		customerRepo.save(customer);
	}

	public Customer get(Integer id) {
		return customerRepo.findById(id).get();
	}

	public void delete(Integer id) {
		customerRepo.deleteById(id);
	}
}
