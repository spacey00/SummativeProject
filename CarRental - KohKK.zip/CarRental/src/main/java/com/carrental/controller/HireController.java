package com.carrental.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.carrental.model.Appuser;
import com.carrental.model.Customer;
import com.carrental.model.Hire;
import com.carrental.model.Vehicle;
import com.carrental.repository.AppUserRepository;
import com.carrental.repository.CustomerRepository;
import com.carrental.repository.HireRepository;
import com.carrental.repository.RentAvailableRepository;
import com.carrental.repository.VehicleRepository;
import com.carrental.service.HirePdfExporter;
import com.carrental.service.HireService;
import com.lowagie.text.DocumentException;

@Controller
public class HireController {
	@Autowired
	private HireService hireService;
	@Autowired
	private VehicleRepository vehicleRepo;
	@Autowired
	private RentAvailableRepository rentAvailableRepo;
	@Autowired
	private HireRepository hireRepo;
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private AppUserRepository appUserRepo;

	public static HashMap<Integer, String> hireAmendmentInProgress = new HashMap<>();
	public static HashMap<Integer, String> hireMap = new HashMap<>();

	@GetMapping("/hires")
	public String viewHomePage(Model model, HttpSession session) {
		String keyword = "";
		return listByPage(model, 1, "hireid", "asc", keyword, session); // (HtmlPage, PageNumber, ColumnName,
																		// OrderDirection, SearchKey)
	}

	@GetMapping("/hires/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword,
			HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString()
							.contains("staff"))) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		session.setAttribute("currentpage", currentPage);
		session.setAttribute("sortfield", sortField);
		session.setAttribute("sortdir", sortDir);
		session.setAttribute("keyword", keyword);
		if(session.getAttribute("hireEditId")==null) {
			session.setAttribute("hireEditId", "0");
		}
		int x = Integer.parseInt((String) session.getAttribute("hireEditId"));
		if (x != 0) {
			hireAmendmentInProgress.remove(x);
		}

		Page<Hire> page = hireService.listAll(currentPage, sortField, sortDir, keyword);

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Hire> listHires = page.getContent();
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listHires", listHires);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "/hiresHtml";
	}

	@GetMapping("/hires/new")
	public String showNewForm(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		Hire hire = new Hire();
		hire.setDatestart(new Date());

		List<Customer> listCustomers = customerRepo.findAll();
		model.addAttribute("listCustomers", listCustomers);
		List<Vehicle> listVehicles = vehicleRepo.findAll();
		model.addAttribute("listVehicles", listVehicles);

		Appuser appuser = appUserRepo.getUserByUsername(session.getAttribute("user").toString());
		hire.setAppuser(appuser);
		model.addAttribute("hire", hire);
		return "/newHireHtml";
	}

	@PostMapping("/hires/checknew")
	public String checkNewForm(@Valid Hire hire, BindingResult bindingResult, Model model, HttpSession session) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("hire", hire);
			List<Customer> listCustomers = customerRepo.findAll();
			model.addAttribute("listCustomers", listCustomers);
			List<Vehicle> listVehicles = rentAvailableRepo.findAll();
			model.addAttribute("listVehicles", listVehicles);
			return "/newHireHtml";
		}
		List<Hire> listHires = hireRepo.findConflictSchedule(hire.getVehicle(), hire.getDatestart(),
				hire.getDatereturn());
		String hireIds = "";
		for (int i = 0; i < listHires.size(); i++) {
			if (i > 0) {
				hireIds += ", ";
			}
			hireIds += listHires.get(i).getHireid();
		}

		if (listHires.size() > 0) {
			model.addAttribute("returnHtml", "/hires");
			model.addAttribute("heading", "Rent Period In Conflict With Hire ID = " + hireIds);
			return "/duplicatedHtml";
		}
		hireMap.put(hire.getHireid(), session.getAttribute("user").toString());
		hireService.save(hire);
		System.out.println("Added by " + session.getAttribute("user") + ": " + hire);
		Sort sort = Sort.by("hireid");
		Pageable pageable = PageRequest.of(0, 5, sort.ascending());
		Page<Hire> page = hireRepo.findAll("*", pageable);
		int totalpages = page.getTotalPages();
		return listByPage(model, totalpages, "hireid", "asc", "", session);
	}

	@PostMapping("/hires/checkedit")
	public String checkEditForm(@Valid Hire hire, BindingResult bindingResult, Model model, HttpSession session) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("hire", hire);
			List<Customer> listCustomers = customerRepo.findAll();
			model.addAttribute("listCustomers", listCustomers);
			List<Vehicle> listVehicles = vehicleRepo.findAll();
			model.addAttribute("listVehicles", listVehicles);
			List<Appuser> listAppUsers = appUserRepo.findAll();
			model.addAttribute("listAppUsers", listAppUsers);
			return "/editHireHtml";
		}
		List<Hire> listHires = hireRepo.findConflictSchedule(hire.getVehicle(), hire.getDatestart(),
				hire.getDatereturn());
		for (int i = 0; i < listHires.size(); i++) {
			if (hire.getHireid() != listHires.get(i).getHireid()) {
				model.addAttribute("returnHtml", "/hires/page");
				model.addAttribute("heading", "Rent Period In Conflict With Hire ID = " + listHires.get(i).getHireid());
				return "/duplicatedHtml";
			}
		}
		hireService.save(hire);
		System.out.println("Edited by " + session.getAttribute("user") + ": " + hire);
		return listByPage(model, (Integer) session.getAttribute("currentpage"),
				(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
				(String) session.getAttribute("keyword"), session);
	}

	@RequestMapping("/hires/edit/{id}")
	public String showEditForm(@PathVariable(name = "id") Integer hireid, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		if (hireAmendmentInProgress.containsKey(hireid)) {
			model.addAttribute("userEdit", hireMap.get(hireid));
			model.addAttribute("returnHtml", "/hires/page/");
			return "/amendmentInProgress";
		}
		List<Hire> hireList = hireRepo.findAll();
		for (int i = 0; i < hireList.size(); i++) {
			if (hireList.get(i).getHireid() == hireid) {
				hireAmendmentInProgress.put(hireid, session.getAttribute("user").toString());
				hireMap.put(hireid, session.getAttribute("user").toString());
				session.setAttribute("hireEditId", "" + hireid);
				Hire hire = hireService.get(hireid);
				model.addAttribute("hire", hire);
				List<Customer> listCustomers = customerRepo.findAll();
				model.addAttribute("listCustomers", listCustomers);
				List<Vehicle> listVehicles = vehicleRepo.findAll();
				model.addAttribute("listVehicles", listVehicles);
				List<Appuser> listAppUsers = appUserRepo.findAll();
				model.addAttribute("listAppUsers", listAppUsers);
				return "/editHireHtml";
			}
		}
		model.addAttribute("returnHtml", "/hires/page/");
		model.addAttribute("userEdit", hireMap.get(hireid));
		return "/justDeleted";
	}

	@RequestMapping("/hires/delete/{id}")
	public String deleteObj(@PathVariable(name = "id") Integer id, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		try {
			if (hireAmendmentInProgress.containsKey(id)) {
				model.addAttribute("userEdit", hireMap.get(id));
				model.addAttribute("returnHtml", "/hires/page/");
				return "/amendmentInProgress";
			}
			List<Hire> hireList = hireRepo.findAll();
			for (int i = 0; i < hireList.size(); i++) {
				if (hireList.get(i).getHireid() == id) {
					hireAmendmentInProgress.put(id, session.getAttribute("user").toString());
					hireMap.put(id, session.getAttribute("user").toString());
					hireService.delete(id);
					hireAmendmentInProgress.remove(id);
					System.out.println("Deleted by " + session.getAttribute("user") + ": Hire ID " + id);
					return listByPage(model, (Integer) session.getAttribute("currentpage"),
							(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
							(String) session.getAttribute("keyword"), session);
				}
			}
		} catch (Exception e) {
			model.addAttribute("returnHtml", "/hires/page/");
			return "/violateReferentialIntegrityHtml";
		}
		model.addAttribute("returnHtml", "/hires/page/");
		model.addAttribute("userEdit", hireMap.get(id));
		return "/justDeleted";
	}

	@GetMapping("/hires/exportCsv")
	public void exportToCSV(HttpServletResponse response, HttpSession session) throws IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("text/csv");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";

			String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
			response.setHeader(headerKey, headerValue);
			List<Hire> listHires = hireRepo.findAll();

			ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
			String[] csvHeader = { "Hire ID", "Date Start", "Date Return", "Customer", "Vehicle", "App User" };
			String[] nameMapping = { "hireid", "datestartCsv", "datereturnCsv", "customer", "vehicle", "appuser" };
			csvWriter.writeHeader(csvHeader);

			for (Hire hire : listHires) {
				csvWriter.write(hire, nameMapping);
			}
			csvWriter.close();
		}
	}

	@GetMapping("/hires/exportPdf")
	public void exportToPDF(HttpServletResponse response, HttpSession session) throws DocumentException, IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("application/pdf");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";
			String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
			response.setHeader(headerKey, headerValue);
			List<Hire> listHires = hireRepo.findAll();

			HirePdfExporter exporter = new HirePdfExporter(listHires);
			exporter.export(response);
		}
	}
}
