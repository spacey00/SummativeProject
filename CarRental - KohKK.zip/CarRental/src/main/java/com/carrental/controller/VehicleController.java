package com.carrental.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.carrental.FileUploadUtil;
import com.carrental.model.Hire;
import com.carrental.model.Vehicle;
import com.carrental.model.Vehicletype;
import com.carrental.repository.HireRepository;
import com.carrental.repository.RentAvailableRepository;
import com.carrental.repository.RentOutRepository;
import com.carrental.repository.VehicleRepository;
import com.carrental.repository.VehicleTypeRepository;
import com.carrental.service.VehiclePdfExporter;
import com.carrental.service.VehicleService;
import com.lowagie.text.DocumentException;

@Controller
public class VehicleController {
	@Autowired
	private VehicleService vehicleService;
	@Autowired
	private VehicleTypeRepository vehicleTypeRepo;
	@Autowired
	private VehicleRepository vehicleRepo;
	@Autowired
	private HireRepository hireRepo;
	@Autowired
	private RentOutRepository rentOutRepo;
	@Autowired
	private RentAvailableRepository rentAvailableRepo;

	public static HashMap<Integer, String> vehicleAmendmentInProgress = new HashMap<>();
	private HashMap<Integer, String> vehicleMap = new HashMap<>();

	@GetMapping("/vehicleslider")
	public String viewSlider(Model model) {
		List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();
		List<Vehicle> listVehicles = vehicleRepo.findAll();
		List<Hire> listRentOutHires = rentOutRepo.findAll();
		List<Integer> listRentOutVehicles = new ArrayList<>();
		for (int i = 0; i < listRentOutHires.size(); i++) {
			listRentOutVehicles.add(listRentOutHires.get(i).getVehicle().getVehicleid());
		}
		List<Vehicle> listAvailableVehicles = rentAvailableRepo.findAll();
		model.addAttribute("listRentOutVehicles", listRentOutVehicles);
		model.addAttribute("listAvailableVehicles", listAvailableVehicles);
		model.addAttribute("listVehicles", listVehicles);
		model.addAttribute("listVehicleTypes", listVehicleTypes);
		model.addAttribute("size", listVehicles.size());
		return "/vehicleSliderHtml";
	}

	@GetMapping("/vehicles")
	public String viewHomePage(Model model, HttpSession session) {
		String keyword = "";
		return listByPage(model, 1, "vehicleid", "asc", keyword, session);
	}

	@GetMapping("/vehicles/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword,
			HttpSession session) {
		session.setAttribute("currentpage", currentPage);
		session.setAttribute("sortfield", sortField);
		session.setAttribute("sortdir", sortDir);
		session.setAttribute("keyword", keyword);

		if(session.getAttribute("vehicleEditId")==null) {
			session.setAttribute("vehicleEditId", "0");
		}

		int x = Integer.parseInt((String) session.getAttribute("vehicleEditId"));
		if (x != 0) {
			vehicleAmendmentInProgress.remove(x);
		}
		Page<Vehicle> page = vehicleService.listAll(currentPage, sortField, sortDir, keyword);
		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Vehicle> listVehicles = page.getContent();

		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listVehicles", listVehicles);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);

		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "/vehiclesHtml";
	}

	@GetMapping("/vehicles/new")
	public String showNewForm(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();
		model.addAttribute("listVehicleTypes", listVehicleTypes);
		Vehicle vehicle = new Vehicle();
		vehicle.setVehiclephoto("nocar.png");
		model.addAttribute("vehicle", vehicle);
		return "/newVehicleHtml";
	}

	@PostMapping("/vehicles/checknew")
	public String checkNewForm(@Valid Vehicle vehicle, BindingResult bindingResult, Model model,
			@RequestParam("image") MultipartFile multipartFile, HttpServletRequest request, HttpSession session)
			throws IOException {
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		if (!fileName.isEmpty()) {
			vehicle.setVehiclephoto(fileName);
			String uploadDir = "vehiclephotos/";
			FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
		}
		if (bindingResult.hasErrors()) {
			List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();
			model.addAttribute("listVehicleTypes", listVehicleTypes);
			model.addAttribute("vehicle", vehicle);
			return "/newVehicleHtml";
		}
		if (vehicle.getVehiclephoto() == null) {
			String[] photo = request.getParameterValues("originphoto");
			vehicle.setVehiclephoto(photo[0]);
		}
		vehicleService.save(vehicle);
		System.out.println("Added by " + session.getAttribute("user") + ": " + vehicle);
		Sort sort = Sort.by("vehicleid");
		Pageable pageable = PageRequest.of(0, 5, sort.ascending());
		Page<Vehicle> page = vehicleRepo.findAll("*", pageable);
		int totalpages = page.getTotalPages();
		return listByPage(model, totalpages, "vehicleid", "asc", "", session);
	}

	@PostMapping("/vehicles/checkedit")
	public String checkEditForm(@Valid Vehicle vehicle, BindingResult bindingResult, Model model,
			@RequestParam("image") MultipartFile multipartFile, HttpServletRequest request, HttpSession session)
			throws IOException {
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		if (!fileName.isEmpty()) {
			vehicle.setVehiclephoto(fileName);
			String uploadDir = "vehiclephotos/";
			FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
		} else {
			String[] photo = request.getParameterValues("originphoto");
			vehicle.setVehiclephoto(photo[0]);
		}

		if (bindingResult.hasErrors()) {
			List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();
			model.addAttribute("listVehicleTypes", listVehicleTypes);
			return "/editVehicleHtml";
		}
		vehicleService.save(vehicle);
		vehicleAmendmentInProgress.remove(vehicle.getVehicleid());
		System.out.println("Edited by " + session.getAttribute("user") + ": " + vehicle);
		return listByPage(model, (Integer) session.getAttribute("currentpage"),
				(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
				(String) session.getAttribute("keyword"), session);
	}

	@RequestMapping("/vehicles/edit/{id}")
	public String showEditForm(@PathVariable(name = "id") Integer vehicleid, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		if (vehicleAmendmentInProgress.containsKey(vehicleid)) {
			model.addAttribute("userEdit", vehicleMap.get(vehicleid));
			model.addAttribute("returnHtml", "/vehicles/page/");
			return "/amendmentInProgress";
		}
		List<Vehicle> vehicleList = vehicleRepo.findAll();
		for (int i = 0; i < vehicleList.size(); i++) {
			if (vehicleList.get(i).getVehicleid() == vehicleid) {
				vehicleAmendmentInProgress.put(vehicleid, session.getAttribute("user").toString());
				vehicleMap.put(vehicleid, session.getAttribute("user").toString());
				session.setAttribute("vehicleEditId", "" + vehicleid);
				Vehicle vehicle = vehicleService.get(vehicleid);
				List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();
				model.addAttribute("listVehicleTypes", listVehicleTypes);
				model.addAttribute("vehicle", vehicle);
				return "/editVehicleHtml";
			}
		}
		model.addAttribute("returnHtml", "/vehicles/page/");
		model.addAttribute("userEdit", vehicleMap.get(vehicleid));
		return "/justDeleted";
	}

	@RequestMapping("/vehicles/delete/{id}")
	public String deleteObj(@PathVariable(name = "id") Integer id, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		try {
			if (vehicleAmendmentInProgress.containsKey(id)) {
				model.addAttribute("userEdit", vehicleMap.get(id));
				model.addAttribute("returnHtml", "/vehicles/page/");
				return "/amendmentInProgress";
			}
			List<Vehicle> vehicleList = vehicleRepo.findAll();
			for (int i = 0; i < vehicleList.size(); i++) {
				if (vehicleList.get(i).getVehicleid() == id) {
					vehicleAmendmentInProgress.put(id, session.getAttribute("user").toString());
					vehicleMap.put(id, session.getAttribute("user").toString());
					vehicleService.delete(id);
					vehicleAmendmentInProgress.remove(id);

					System.out.println("Deleted by " + session.getAttribute("user") + ": Vehicle ID " + id);
					return listByPage(model, (Integer) session.getAttribute("currentpage"),
							(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
							(String) session.getAttribute("keyword"), session);
				}
			}
		} catch (Exception e) {
			model.addAttribute("returnHtml", "/vehicles/page/");
			return "/violateReferentialIntegrityHtml";
		}
		model.addAttribute("returnHtml", "/vehicles/page/");
		model.addAttribute("userEdit", vehicleMap.get(id));
		return "/justDeleted";
	}

	@GetMapping("/vehicles/exportCsv")
	public void exportToCSV(HttpServletResponse response) throws IOException {
		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = "Content-Disposition";

		String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		List<Vehicle> listVehicles = vehicleRepo.findAll();

		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Vehicle ID", "Vehicle Type", "Registered Year" };
		String[] nameMapping = { "vehicleid", "vehicleobj", "registeredyear" };
		csvWriter.writeHeader(csvHeader);
		for (Vehicle vehicle : listVehicles) {
			csvWriter.write(vehicle, nameMapping);
		}
		csvWriter.close();
	}

	@GetMapping("/vehicles/exportPdf")
	public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
		response.setContentType("application/pdf");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
		response.setHeader(headerKey, headerValue);

		List<Vehicle> listVehicles = vehicleRepo.findAll();

		VehiclePdfExporter exporter = new VehiclePdfExporter(listVehicles);
		exporter.export(response);
	}

	@GetMapping("/showvehiclerevenuechart")
	public String showChart(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString()
							.contains("manager"))) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		try {

			Date dateStart = dateFormatter.parse("01-02-2021");
			String dateStartStr = dateFormatter.format(dateStart);
			Date dateEnd = new Date();
			String dateEndStr = dateFormatter.format(dateEnd);
			List<Hire> listHires = hireRepo.findHiresBetweenDates(dateStart, dateEnd);
			List<Vehicle> listVehicles = vehicleRepo.findAll();
			double[] revenues = new double[20];
			double numberOfDays = 0;
			Map<Integer, Double> graphData = new TreeMap<>();

			for (int v = 0; v < listVehicles.size(); v++) {
				revenues[v] = 0.0;
				for (int h = 0; h < listHires.size(); h++) {
					if (listHires.get(h).getVehicle().getVehicleid() == listVehicles.get(v).getVehicleid()) {
						Date startdate = listHires.get(h).getDatestart();
						if (startdate.compareTo(dateStart) < 0) {
							startdate = dateStart;
						}
						Date enddate;
						if (listHires.get(h).getDatereturn() == null
								|| listHires.get(h).getDatereturn().compareTo(dateEnd) > 0) {
							enddate = dateEnd;
						} else {
							enddate = listHires.get(h).getDatereturn();
						}
						numberOfDays = 1 + TimeUnit.DAYS.convert((enddate.getTime() - startdate.getTime()),
								TimeUnit.MILLISECONDS);

						revenues[v] += listHires.get(h).getVehicle().getVehicleobj().getRate() * numberOfDays;
					}
				}
				graphData.put(listVehicles.get(v).getVehicleid(), revenues[v]);
			}
			model.addAttribute("chartData", graphData);
			model.addAttribute("listVehicles", listVehicles);
			model.addAttribute("dateStart", dateStartStr);
			model.addAttribute("dateEnd", dateEndStr);
			List<List<Object>> lineData = new ArrayList<>();
			Calendar c = Calendar.getInstance();
			Date d = dateStart;
			double revenue = 0;
			int count = 0;
			do {
				List<Object> dateData = new ArrayList<>();
				dateData.add(d);
				count++;
				for (int j = 0; j < listVehicles.size(); j++) {
					revenue = 0;
					for (int i = 0; i < listHires.size(); i++) {
						if (listHires.get(i).getDatereturn() == null)
							listHires.get(i).setDatereturn(new Date());
						if ((d.after(listHires.get(i).getDatestart()) || d.equals(listHires.get(i).getDatestart()))
								&& (d.before(listHires.get(i).getDatereturn())
										|| d.equals(listHires.get(i).getDatereturn())
										|| listHires.get(i).getDatereturn() == null)) {

							if (listHires.get(i).getVehicle().getVehicleid() == j + 1) {
								revenue += listHires.get(i).getVehicle().getVehicleobj().getRate();
							}
						}
					}
					dateData.add(revenue);
				}
				lineData.add(dateData);
				c.setTime(d);
				c.add(Calendar.DATE, 1);
				d = c.getTime();
			} while ((d.before(dateEnd) || d.equals(dateEnd)));
			model.addAttribute("lineChartData", lineData);
			model.addAttribute("vehicles", listVehicles.size());
			model.addAttribute("numberofdata", count);
			return "/chartVehicleRevenue.html";
		} catch (Exception e) {
			return "/error";
		}
	}

	@PostMapping("/showvehiclerevenuechart")
	public String showPostChart(Model model, HttpServletRequest request) {

		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		try {
			String[] dateStarts = request.getParameterValues("dateStart");
			String[] dateEnds = request.getParameterValues("dateEnd");
			Date dateStart = dateFormatter.parse(dateStarts[0]);
			Date dateEnd = dateFormatter.parse(dateEnds[0]);
			List<Hire> listHires = hireRepo.findHiresBetweenDates(dateStart, dateEnd);

			List<Vehicle> listVehicles = vehicleRepo.findAll();
			double[] revenues = new double[20];
			double numberOfDays = 0;
			Map<Integer, Double> graphData = new TreeMap<>();

			for (int v = 0; v < listVehicles.size(); v++) {
				revenues[v] = 0.0;
				for (int h = 0; h < listHires.size(); h++) {
					if (listHires.get(h).getVehicle().getVehicleid() == listVehicles.get(v).getVehicleid()) {
						Date startdate = listHires.get(h).getDatestart();
						if (startdate.compareTo(dateStart) < 0) {
							startdate = dateStart;
						}
						Date enddate;
						if (listHires.get(h).getDatereturn() == null
								|| listHires.get(h).getDatereturn().compareTo(dateEnd) > 0) {
							enddate = dateEnd;
						} else {
							enddate = listHires.get(h).getDatereturn();
						}

						numberOfDays = 1 + TimeUnit.DAYS.convert((enddate.getTime() - startdate.getTime()),
								TimeUnit.MILLISECONDS);

						revenues[v] += listHires.get(h).getVehicle().getVehicleobj().getRate() * numberOfDays;
					}
				}
				graphData.put(listVehicles.get(v).getVehicleid(), revenues[v]);
			}
			model.addAttribute("chartData", graphData);
			model.addAttribute("listVehicles", listVehicles);
			model.addAttribute("dateStart", dateStarts[0]);
			model.addAttribute("dateEnd", dateEnds[0]);

			List<List<Object>> lineData = new ArrayList<>();
			Calendar c = Calendar.getInstance();
			Date d = dateStart;
			double revenue = 0;
			int count = 0;

			do {
				List<Object> dateData = new ArrayList<>();
				dateData.add(d);
				count++;
				for (int j = 0; j < listVehicles.size(); j++) {
					revenue = 0;
					for (int i = 0; i < listHires.size(); i++) {
						if (listHires.get(i).getDatereturn() == null)
							listHires.get(i).setDatereturn(new Date());
						if ((d.after(listHires.get(i).getDatestart()) || d.equals(listHires.get(i).getDatestart()))
								&& (d.before(listHires.get(i).getDatereturn())
										|| d.equals(listHires.get(i).getDatereturn())
										|| listHires.get(i).getDatereturn() == null)) {

							if (listHires.get(i).getVehicle().getVehicleid() == j + 1) {
								revenue += listHires.get(i).getVehicle().getVehicleobj().getRate();
							}
						}
					}
					dateData.add(revenue);
				}
				lineData.add(dateData);
				c.setTime(d);
				c.add(Calendar.DATE, 1);
				d = c.getTime();
			} while ((d.before(dateEnd) || d.equals(dateEnd)));

			model.addAttribute("lineChartData", lineData);
			model.addAttribute("vehicles", listVehicles.size());
			model.addAttribute("numberofdata", count);

			return "/chartVehicleRevenue";
		} catch (Exception e) {
			return "/error";
		}
	}

}
