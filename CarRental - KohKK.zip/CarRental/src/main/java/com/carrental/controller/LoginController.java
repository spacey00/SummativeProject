package com.carrental.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.carrental.HttpSessionConfig;
import com.carrental.model.Approle;
import com.carrental.model.Appuser;
import com.carrental.model.Employee;
import com.carrental.repository.AppRoleRepository;
import com.carrental.repository.AppUserRepository;
import com.carrental.repository.EmployeeRepository;

@Controller
public class LoginController {
	@Autowired
	private AppRoleRepository appRoleRepo;
	@Autowired
	private EmployeeRepository employeeRepo;
	@Autowired
	private AppUserRepository appUserRepo;
	public static int count = 1;
	@Autowired
	HttpSession session;

	@GetMapping("/")
	public String indexPage(Model model) {
			if(HttpSessionConfig.sessionIdUser.containsKey(session.getId())) {
				model.addAttribute("heading", "Already Log In With This Browser In This Computer");
				model.addAttribute("advice", "Quit App");
				return "/doubleLogin";
			}
			if(HttpSessionConfig.sessionIdUser.containsValue(session.getAttribute("user").toString())) {
				model.addAttribute("heading", "This User Already Log In");
				model.addAttribute("advice", "ReLogin");
				return "/doubleLogin";
			}

		HttpSessionConfig.sessionIdUser.put(session.getId(), session.getAttribute("user").toString());

		if (count < 1) {
			Appuser appuser = appUserRepo.getOne(1);
			appuser.setUsername(null);
			appuser.setPassword(null);
			model.addAttribute("firstLogin", "yes");
			model.addAttribute("appuser", appuser);
		} else {
			model.addAttribute("firstLogin", "no");
		}
		return "/index";
	}
	
	@GetMapping("/home")
	public String homePage(Model model) {
		model.addAttribute("firstLogin", "no");
		return "/index";
	}

	@GetMapping("/login") // endpoint, http://localhost:8080/login
	public String showLogin(Model model) {
		if (appRoleRepo.findAll().isEmpty()) {
			count = 0;
			Approle role1 = new Approle("admin");
			appRoleRepo.save(role1);
			Approle role2 = new Approle("manager");
			appRoleRepo.save(role2);
			Approle role3 = new Approle("staff");
			appRoleRepo.save(role3);
			Employee employee1 = new Employee("employee", "email@email.com", "admin", "1234567");
			employeeRepo.save(employee1);
			Appuser user1 = new Appuser("username", "$2y$12$FIPNoQTliTTRcsVe3fguce1aAJCZ0x4lZuXYZkiWjtzRJAWYIa13.",
					true, role1, employee1);
			appUserRepo.save(user1);
			model.addAttribute("newStartUp", "yes");
		} else {
			if (count == 0) {
				model.addAttribute("newStartUp", "yes");
			} else {
				model.addAttribute("newStartUp", "no");
			}
		}
		return "/loginHtml";
	}

	@GetMapping("/login-error") // endpoint, http://localhost:8080/login-error
	public String loginerror() {
		return "/loginErrorHtml";
	}

	@GetMapping("/logout")
	public String showLogout() {
		return "/logoutHtml";
	}
	
	@GetMapping("/relogin")
	public String showReLogin() {
//	Locks will have been properly unlocked before user can click logout at the navigation bar	
		HttpSessionConfig.sessionIdUser.remove(session.getId());

		return "redirect:/login";
	}

}
