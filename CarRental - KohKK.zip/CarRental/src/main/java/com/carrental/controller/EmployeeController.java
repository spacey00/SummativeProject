package com.carrental.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.carrental.model.Employee;
import com.carrental.repository.EmployeeRepository;
import com.carrental.service.EmployeePdfExporter;
import com.carrental.service.EmployeeService;
import com.lowagie.text.DocumentException;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private EmployeeRepository employeeRepo;
	private String newLogin = "yes";

	public static HashMap<Integer, String> employeeAmendmentInProgress = new HashMap<>();
	private HashMap<Integer, String> employeeMap = new HashMap<>();

	@GetMapping("/employees")
	public String viewHomePage(Model model, HttpSession session) {
		String keyword = "";
		return listByPage(model, 1, "employeeid", "asc", keyword, session); // (HtmlPage, PageNumber, ColumnName,
																			// OrderDirection, SearchKey)
	}

	@GetMapping("/employees/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword,
			HttpSession session) {

		session.setAttribute("currentpage", currentPage);
		session.setAttribute("sortfield", sortField);
		session.setAttribute("sortdir", sortDir);
		session.setAttribute("keyword", keyword);
		if(session.getAttribute("employeeEditId")==null) {
			session.setAttribute("employeeEditId", "0");
		}
		int x = Integer.parseInt((String) session.getAttribute("employeeEditId"));
		if (x != 0) {
			employeeAmendmentInProgress.remove(x);
		}

		Page<Employee> page = employeeService.listAll(currentPage, sortField, sortDir, keyword);

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Employee> listEmployees = page.getContent();
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listEmployees", listEmployees);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "/employeesHtml";
	}

	@GetMapping("/employees/new")
	public String showNewForm(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		newLogin = "no";
		return "/newEmployeeHtml";
	}

	@PostMapping("/employees/checknew")
	public String checkNewForm(@Valid Employee employee, BindingResult bindingResult, Model model,
			HttpSession session) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("employee", employee);
			return "/newEmployeeHtml";
		}
		List<Employee> listEmployees = employeeRepo.findAll();
		for (int i = 0; i < listEmployees.size(); i++) {
			if (listEmployees.get(i).getName().equalsIgnoreCase(employee.getName())) {
				model.addAttribute("returnHtml", "/employees/page");
				model.addAttribute("heading",
						"Employee Name Already Used By Employee ID: " + listEmployees.get(i).getEmployeeid());
				return "/duplicatedHtml";
			}
		}
		employeeService.save(employee);
		System.out.println("Added by " + session.getAttribute("user") + ": " + employee);
		Sort sort = Sort.by("employeeid");
		Pageable pageable = PageRequest.of(0, 5, sort.ascending());
		Page<Employee> page = employeeRepo.findAll("*", pageable);
		int totalpages = page.getTotalPages();
		return listByPage(model, totalpages, "employeeid", "asc", "", session);
	}

	@PostMapping("/employees/checkedit")
	public String checkEditForm(@Valid Employee employee, BindingResult bindingResult, Model model,
			HttpSession session) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("employee", employee);
			return "/editEmployeeHtml";
		}
		employeeService.save(employee);
		System.out.println("Edited by " + session.getAttribute("user") + ": " + employee);
		if (newLogin == "no") {
			return listByPage(model, (Integer) session.getAttribute("currentpage"),
					(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
					(String) session.getAttribute("keyword"), session);
		}
		return "redirect:/help/systemSetUp";
	}

	@RequestMapping("/employees/edit/{id}")
	public String showEditForm(@PathVariable(name = "id") Integer employeeid, Model model,
			HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		if (employeeAmendmentInProgress.containsKey(employeeid)) {
			model.addAttribute("userEdit", employeeMap.get(employeeid));
			model.addAttribute("returnHtml", "/employees/page/");
			return "/amendmentInProgress";
		}
		List<Employee> employeeList = employeeRepo.findAll();
		for (int i = 0; i < employeeList.size(); i++) {
			if (employeeList.get(i).getEmployeeid() == employeeid) {
				employeeAmendmentInProgress.put(employeeid, session.getAttribute("user").toString());
				employeeMap.put(employeeid, session.getAttribute("user").toString());
				session.setAttribute("employeeEditId", "" + employeeid);
				Employee employee = employeeService.get(employeeid);
				model.addAttribute("employee", employee);
				newLogin = "no";
				return "/editEmployeeHtml";
			}
		}
		model.addAttribute("returnHtml", "/employees/page/");
		model.addAttribute("userEdit", employeeMap.get(employeeid));
		return "/justDeleted";
	}

	@RequestMapping("/employees/delete/{id}")
	public String deleteObj(@PathVariable(name = "id") Integer id, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		try {
			if (employeeAmendmentInProgress.containsKey(id)) {
				model.addAttribute("userEdit", employeeMap.get(id));
				model.addAttribute("returnHtml", "/employees/page/");
				return "/amendmentInProgress";
			}
			List<Employee> employeeList = employeeRepo.findAll();
			for (int i = 0; i < employeeList.size(); i++) {
				if (employeeList.get(i).getEmployeeid() == id) {
					employeeAmendmentInProgress.put(id, session.getAttribute("user").toString());
					employeeMap.put(id, session.getAttribute("user").toString());
					employeeService.delete(id);
					employeeAmendmentInProgress.remove(id);
					System.out.println("Deleted by " + session.getAttribute("user") + ": Employee ID " + id);
					return listByPage(model, (Integer) session.getAttribute("currentpage"),
							(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
							(String) session.getAttribute("keyword"), session);
				}
			}
		} catch (Exception e) {
			model.addAttribute("returnHtml", "/employees/page/");
			return "/violateReferentialIntegrityHtml";
		}
		model.addAttribute("returnHtml", "/employees/page/");
		model.addAttribute("userEdit", employeeMap.get(id));
		return "/justDeleted";
	}

	@GetMapping("/employees/exportCsv")
	public void exportToCSV(HttpServletResponse response, HttpSession session) throws IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("text/csv");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";

			String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
			response.setHeader(headerKey, headerValue);
			List<Employee> listEmployees = employeeRepo.findAll();

			ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
			String[] csvHeader = { "Employee ID", "Name", "Email", "Job Title", "Phone" };
			String[] nameMapping = { "employeeid", "name", "email", "jobtitle", "phone" };
			csvWriter.writeHeader(csvHeader);

			for (Employee employee : listEmployees) {
				csvWriter.write(employee, nameMapping);
			}
			csvWriter.close();
		}
	}

	@GetMapping("/employees/exportPdf")
	public void exportToPDF(HttpServletResponse response, HttpSession session) throws DocumentException, IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("application/pdf");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";
			String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
			response.setHeader(headerKey, headerValue);
			List<Employee> listEmployees = employeeRepo.findAll();

			EmployeePdfExporter exporter = new EmployeePdfExporter(listEmployees);
			exporter.export(response);
		}
	}
}
