package com.carrental.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.carrental.HttpSessionConfig;
import com.carrental.model.LockPojo;

@Controller
public class LockController {

	@GetMapping("/locks")
	public String locksPage(Model model, HttpSession session) {
// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		List<LockPojo> listLocks = new ArrayList<>();
		LockPojo lp1 = new LockPojo();
		model.addAttribute("lockobj", lp1);

		LockPojo lpLogin = new LockPojo("Login User", HttpSessionConfig.sessionIdUser);
		model.addAttribute("lpLogin", lpLogin);

		LockPojo lp = new LockPojo("Customer", CustomerController.customerAmendmentInProgress);
		listLocks.add(lp);
		lp = new LockPojo("Employee", EmployeeController.employeeAmendmentInProgress);
		listLocks.add(lp);
		lp = new LockPojo("Hire", HireController.hireAmendmentInProgress);
		listLocks.add(lp);
		lp = new LockPojo("Invoice", InvoiceController.invoiceAmendmentInProgress);
		listLocks.add(lp);
		lp = new LockPojo("User", AppUserController.appUserAmendmentInProgress);
		listLocks.add(lp);
		lp = new LockPojo("Vehicle", VehicleController.vehicleAmendmentInProgress);
		listLocks.add(lp);
		lp = new LockPojo("Vehicle Type", VehicleTypeController.vehicleTypeAmendmentInProgress);
		listLocks.add(lp);
		model.addAttribute("listLocks", listLocks);
		return "/locksHtml";
	}

	public void updateLocks(HashMap<Integer, String> amendmentInProgress,
			String user) {
		for (Map.Entry<Integer, String> entry : amendmentInProgress.entrySet()) {
			if ((entry.getValue()).equals(user)) {
				amendmentInProgress.remove(entry.getKey());
				break;
			}
		}
	}

	@PostMapping("/locks/unlock")
	public String Unlock(HttpServletRequest request) {
		String[] nlock = request.getParameterValues("lockname");
		String[] mlock = request.getParameterValues("locknos");
		switch (mlock[0]) {
		case "User":
			AppUserController.appUserAmendmentInProgress.remove(Integer.parseInt(nlock[0]));
			break;
		case "Customer":
			CustomerController.customerAmendmentInProgress.remove(Integer.parseInt(nlock[0]));
			break;
		case "Employee":
			EmployeeController.employeeAmendmentInProgress.remove(Integer.parseInt(nlock[0]));
			break;
		case "Hire":
			HireController.hireAmendmentInProgress.remove(Integer.parseInt(nlock[0]));
			break;
		case "Invoice":
			InvoiceController.invoiceAmendmentInProgress.remove(Integer.parseInt(nlock[0]));
			break;
		case "Vehicle":
			VehicleController.vehicleAmendmentInProgress.remove(Integer.parseInt(nlock[0]));
			break;
		case "Vehicle Type":
			VehicleTypeController.vehicleTypeAmendmentInProgress.remove(Integer.parseInt(nlock[0]));
			break;
		default:
			for (Map.Entry<String, String> entry : HttpSessionConfig.sessionIdUser.entrySet()) {
				if ((entry.getValue()).equals(nlock[0])) {
					HttpSessionConfig.sessionIdUser.remove(entry.getKey());
					break;
				}
			}

			if (AppUserController.appUserAmendmentInProgress.containsValue(nlock[0].toString())) {
				updateLocks(AppUserController.appUserAmendmentInProgress, nlock[0]);
			} else if (CustomerController.customerAmendmentInProgress.containsValue(nlock[0].toString())) {
				updateLocks( CustomerController.customerAmendmentInProgress, nlock[0]);
			} else if (EmployeeController.employeeAmendmentInProgress.containsValue(nlock[0].toString())) {
				updateLocks(EmployeeController.employeeAmendmentInProgress, nlock[0]);
			} else if (HireController.hireAmendmentInProgress.containsValue(nlock[0].toString())) {
				updateLocks(HireController.hireAmendmentInProgress, nlock[0]);
			} else if (InvoiceController.invoiceAmendmentInProgress.containsValue(nlock[0].toString())) {
				updateLocks(InvoiceController.invoiceAmendmentInProgress, nlock[0]);
			} else if (VehicleController.vehicleAmendmentInProgress.containsValue(nlock[0].toString())) {
				updateLocks(VehicleController.vehicleAmendmentInProgress, nlock[0]);
			} else if (VehicleTypeController.vehicleTypeAmendmentInProgress.containsValue(nlock[0].toString())) {
				updateLocks(VehicleTypeController.vehicleTypeAmendmentInProgress, nlock[0]);
			}
			break;
		}
		return "redirect:/locks";
	}

}