package com.carrental.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.carrental.model.Invoice;
import com.carrental.repository.InvoiceRepository;
import com.carrental.repository.OutstandingInvoiceRepository;
import com.carrental.service.InvoiceService;
import com.carrental.service.InvoiceStatementPdfExporter;
import com.carrental.service.OutstandingInvoicePdfExporter;
import com.carrental.service.OutstandingInvoiceService;
import com.lowagie.text.DocumentException;

@Controller
public class OutstandingInvoiceController {
	@Autowired
	private OutstandingInvoiceService outstandingInvoiceService;
	@Autowired
	private OutstandingInvoiceRepository outstandingInvoiceRepo;
	@Autowired
	private InvoiceService invoiceService;
	@Autowired
	private InvoiceRepository invoiceRepo;

	@GetMapping("/outstandinginvoices")
	public String viewHomePage(Model model, HttpSession session) {
		String keyword = "";
		return listByPage(model, 1, "invoiceid", "asc", keyword, session); // (HtmlPage, PageNumber, ColumnName,
																			// OrderDirection, SearchKey)
	}

	@GetMapping("/outstandinginvoices/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword,
			HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString()
							.contains("staff"))) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		session.setAttribute("currentpage", currentPage);
		session.setAttribute("sortfield", sortField);
		session.setAttribute("sortdir", sortDir);
		session.setAttribute("keyword", keyword);
		if(session.getAttribute("invoiceEditId")==null) {
			session.setAttribute("invoiceEditId", "0");
		}
		int x = Integer.parseInt((String) session.getAttribute("invoiceEditId"));
		if (x != 0) {
			InvoiceController.invoiceAmendmentInProgress.remove(x);
		}

		Page<Invoice> page = outstandingInvoiceService.listAll(currentPage, sortField, sortDir, keyword);

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Invoice> listOutstandingInvoices = page.getContent();
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listOutstandingInvoices", listOutstandingInvoices);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "/outstandingInvoicesHtml";
	}

	@GetMapping("/outstandinginvoices/edit/{id}")
	public String showEditForm(@PathVariable(name = "id") Integer invoiceid, Model model,
			HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString()
							.contains("staff"))) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		if (InvoiceController.invoiceAmendmentInProgress.containsKey(invoiceid)) {
			model.addAttribute("userEdit", InvoiceController.invoiceMap.get(invoiceid));
			model.addAttribute("returnHtml", "/outstandinginvoices/page/");
			return "/amendmentInProgress";
		}
		List<Invoice> invoiceList = invoiceRepo.findAll();
		for (int i = 0; i < invoiceList.size(); i++) {
			if (invoiceList.get(i).getInvoiceid() == invoiceid) {
				InvoiceController.invoiceAmendmentInProgress.put(invoiceid, session.getAttribute("user").toString());
				InvoiceController.invoiceMap.put(invoiceid, session.getAttribute("user").toString());
				session.setAttribute("invoiceEditId", "" + invoiceid);
				Invoice invoice = outstandingInvoiceService.get(invoiceid);
				model.addAttribute("invoice", invoice);
				long diff = invoice.getHire().getDatereturn().getTime() - invoice.getHire().getDatestart().getTime();
				diff = 1 + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
				model.addAttribute("diff", diff);
				return "/editOutstandingInvoiceHtml";
			}
		}
		model.addAttribute("returnHtml", "/outstandinginvoices/page/");
		model.addAttribute("userEdit", InvoiceController.invoiceMap.get(invoiceid));
		return "/justDeleted";
	}

	@RequestMapping(value = "/outstandinginvoices/save", method = RequestMethod.POST)
	public String saveInvoice(@ModelAttribute("invoice") Invoice invoice, Model model, HttpSession session) {
		invoiceService.save(invoice);
		System.out.println("Updated by " + session.getAttribute("user") + ": " + invoice);
		return listByPage(model, (Integer) session.getAttribute("currentpage"),
				(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
				(String) session.getAttribute("keyword"), session);
	}

	@GetMapping("/outstandinginvoices/exportCsv")
	public void exportToCSV(HttpServletResponse response, HttpSession session) throws IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("text/csv");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";

			String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
			response.setHeader(headerKey, headerValue);
			List<Invoice> listOutstandingInvoices = outstandingInvoiceRepo.findAll();

			ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
			String[] csvHeader = { "Invoice ID", "Invoice Date", "Hire" };
			String[] nameMapping = { "invoiceid", "invoicedateCsv", "hire" };
			csvWriter.writeHeader(csvHeader);

			for (Invoice invoice : listOutstandingInvoices) {
				csvWriter.write(invoice, nameMapping);
			}
			csvWriter.close();
		}
	}

	@GetMapping("/outstandinginvoices/exportPdf")
	public void exportToPDF(HttpServletResponse response, HttpSession session) throws DocumentException, IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("application/pdf");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";
			String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
			response.setHeader(headerKey, headerValue);
			List<Invoice> listOutstandingInvoices = outstandingInvoiceRepo.findAll();
			OutstandingInvoicePdfExporter exporter = new OutstandingInvoicePdfExporter(listOutstandingInvoices);
			exporter.export(response);
		}
	}

	@GetMapping("/invoicestatement/exportPdf/{id}")
	public void invoicestatementToPDF(@PathVariable(name = "id") Integer id, HttpServletResponse response,
			HttpSession session) throws DocumentException, IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			Invoice outstandingInvoice = outstandingInvoiceService.get(id);
			long diff = outstandingInvoice.getHire().getDatereturn().getTime()
					- outstandingInvoice.getHire().getDatestart().getTime();
			diff = 1 + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);

			response.setContentType("application/pdf");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";
			String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
			response.setHeader(headerKey, headerValue);
			InvoiceStatementPdfExporter exporter = new InvoiceStatementPdfExporter(outstandingInvoice);
			exporter.export(response);
		}
	}
}
