package com.carrental.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.carrental.model.Hire;
import com.carrental.model.Invoice;
import com.carrental.repository.HireRepository;
import com.carrental.repository.InvoiceRepository;
import com.carrental.service.InvoicePdfExporter;
import com.carrental.service.InvoiceService;
import com.lowagie.text.DocumentException;

@Controller
public class InvoiceController {
	@Autowired
	private InvoiceService invoiceService;
	@Autowired
	private InvoiceRepository invoiceRepo;
	@Autowired
	private HireRepository hireRepo;
	public static String sourceInvoiceTemplate;

	public static HashMap<Integer, String> invoiceAmendmentInProgress = new HashMap<>();
	public static HashMap<Integer, String> invoiceMap = new HashMap<>();

	@GetMapping("/invoices")
	public String viewHomePage(Model model, HttpSession session) {
		String keyword = "";
		sourceInvoiceTemplate = "invoicesHtml";
		return listByPage(model, 1, "invoiceid", "asc", keyword, session); // (HtmlPage, PageNumber, ColumnName,
																			// OrderDirection, SearchKey)
	}

	@GetMapping("/invoices/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword,
			HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString()
							.contains("staff"))) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		session.setAttribute("currentpage", currentPage);
		session.setAttribute("sortfield", sortField);
		session.setAttribute("sortdir", sortDir);
		session.setAttribute("keyword", keyword);
		if(session.getAttribute("invoiceEditId")==null) {
			session.setAttribute("invoiceEditId", "0");
		}
		int x = Integer.parseInt((String) session.getAttribute("invoiceEditId"));
		if (x != 0) {
			invoiceAmendmentInProgress.remove(x);
		}

		Page<Invoice> page = invoiceService.listAll(currentPage, sortField, sortDir, keyword);

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Invoice> listInvoices = page.getContent();
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listInvoices", listInvoices);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "/invoicesHtml";
	}

	@GetMapping("/invoices/new")
	public String showNewForm(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end
		List<Hire> listHiresPendingInvoice = hireRepo.hirePendingInvoice();
		model.addAttribute("listHires", listHiresPendingInvoice);
		Invoice invoice = new Invoice();
		invoice.setInvoicedate(new Date());
		model.addAttribute("invoice", invoice);
		return "/newInvoiceHtml";
	}

	@PostMapping("/invoices/checknew")
	public String checkNewForm(@Valid Invoice invoice, BindingResult bindingResult, Model model,
			HttpSession session) {
		if (bindingResult.hasErrors()) {
			List<Hire> listHiresPendingInvoice = hireRepo.hirePendingInvoice();
			model.addAttribute("listHires", listHiresPendingInvoice);
			model.addAttribute("invoice", invoice);
			return "/newInvoiceHtml";
		}
		List<Hire> listHires = hireRepo.hireWithInvoice();
		for (int i = 0; i < listHires.size(); i++) {
			if (invoice.getHire().getHireid() == listHires.get(i).getHireid()) {
				model.addAttribute("returnHtml", "/invoices/page");
				List<Invoice> listInvoices = invoiceRepo.findAll();
				for(int j=listInvoices.size()-1; j>=0; j--) {
					if(listInvoices.get(j).getHire().getHireid()==listHires.get(i).getHireid()) {
						model.addAttribute("heading", "Hire ID: " + listHires.get(i).getHireid() + " Already Has An Invoice ID: " + listInvoices.get(j).getInvoiceid());
						return "/duplicatedHtml";
					}
				}
			}
		}
		invoiceService.save(invoice);
		System.out.println("Added by " + session.getAttribute("user") + ": " + invoice);
		Sort sort = Sort.by("invoiceid");
		Pageable pageable = PageRequest.of(0, 5, sort.ascending());
		Page<Invoice> page = invoiceRepo.findAll("*", pageable);
		int totalpages = page.getTotalPages();
		return listByPage(model, totalpages, "invoiceid", "asc", "", session);
	}

	@PostMapping("/invoices/checkedit")
	public String checkEditForm(@Valid Invoice invoice, BindingResult bindingResult, Model model,
			HttpSession session) {
		if (bindingResult.hasErrors()) {
			List<Hire> listHires = hireRepo.findAll();
			model.addAttribute("listHires", listHires);
			model.addAttribute("invoice", invoice);
			return "/editinvoiceHtml";
		}
		List<Hire> listHires = hireRepo.hireWithInvoice();
		listHires.remove(invoice.getHire());
		for (int i = 0; i < listHires.size(); i++) {
			if (invoice.getHire().getHireid() == listHires.get(i).getHireid()) {
				model.addAttribute("returnHtml", "/invoices/page");
				model.addAttribute("heading", "This Hire ID Already Has An Invoice");
				return "/duplicatedHtml";
			}
		}
		invoiceService.save(invoice);
		System.out.println("Edited by " + session.getAttribute("user") + ": " + invoice);
		return listByPage(model, (Integer) session.getAttribute("currentpage"),
				(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
				(String) session.getAttribute("keyword"), session);
	}

	@RequestMapping("/invoices/edit/{id}")
	public String showEditForm(@PathVariable(name = "id") Integer invoiceid, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		if (invoiceAmendmentInProgress.containsKey(invoiceid)) {
			model.addAttribute("userEdit", invoiceMap.get(invoiceid));
			model.addAttribute("returnHtml", "/invoices/page/");
			return "/amendmentInProgress";
		}
		List<Invoice> invoiceList = invoiceRepo.findAll();
		for (int i = 0; i < invoiceList.size(); i++) {
			if (invoiceList.get(i).getInvoiceid() == invoiceid) {
				invoiceAmendmentInProgress.put(invoiceid, session.getAttribute("user").toString());
				invoiceMap.put(invoiceid, session.getAttribute("user").toString());
				session.setAttribute("invoiceEditId", "" + invoiceid);
				List<Hire> listHires = hireRepo.hirePendingInvoice();
				Invoice invoice = invoiceService.get(invoiceid);
				listHires.add(invoice.getHire());
				model.addAttribute("listHires", listHires);
				model.addAttribute("invoice", invoice);
				return "/editInvoiceHtml";
			}
		}
		model.addAttribute("returnHtml", "/invoices/page/");
		model.addAttribute("userEdit", invoiceMap.get(invoiceid));
		return "/justDeleted";
	}

	@RequestMapping("/invoices/delete/{id}")
	public String deleteObj(@PathVariable(name = "id") Integer id, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		try {
			if (invoiceAmendmentInProgress.containsKey(id)) {
				model.addAttribute("userEdit", invoiceMap.get(id));
				model.addAttribute("returnHtml", "/invoices/page/");
				return "/amendmentInProgress";
			}
			List<Invoice> invoiceList = invoiceRepo.findAll();
			for (int i = 0; i < invoiceList.size(); i++) {
				if (invoiceList.get(i).getInvoiceid() == id) {
					invoiceAmendmentInProgress.put(id, session.getAttribute("user").toString());
					invoiceMap.put(id, session.getAttribute("user").toString());
					invoiceService.delete(id);
					invoiceAmendmentInProgress.remove(id);
					System.out.println("Deleted by " + session.getAttribute("user") + ": Invoice ID " + id);
					return listByPage(model, (Integer) session.getAttribute("currentpage"),
							(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
							(String) session.getAttribute("keyword"), session);
				}
			}
		} catch (Exception e) {
			model.addAttribute("returnHtml", "/invoices/page/");
			return "/violateReferentialIntegrityHtml";
		}
		model.addAttribute("returnHtml", "/invoices/page/");
		model.addAttribute("userEdit", invoiceMap.get(id));
		return "/justDeleted";
	}

	@GetMapping("/invoices/exportCsv")
	public void exportToCSV(HttpServletResponse response, HttpSession session) throws IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("text/csv");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";

			String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
			response.setHeader(headerKey, headerValue);
			List<Invoice> listInvoices = invoiceRepo.findAll();
			for (int i = 0; i < listInvoices.size(); i++) {
			}

			ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
			String[] csvHeader = { "Invoice ID", "Invoice Date", "Hire", "Paid?" };
			String[] nameMapping = { "invoiceid", "invoicedateCsv", "hire", "paid" };
			csvWriter.writeHeader(csvHeader);
			for (Invoice invoice : listInvoices) {
				csvWriter.write(invoice, nameMapping);
			}
			csvWriter.close();
		}
	}

	@GetMapping("/invoices/exportPdf")
	public void exportToPDF(HttpServletResponse response, HttpSession session) throws DocumentException, IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("application/pdf");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";
			String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
			response.setHeader(headerKey, headerValue);
			List<Invoice> listInvoices = invoiceRepo.findAll();
			InvoicePdfExporter exporter = new InvoicePdfExporter(listInvoices);
			exporter.export(response);
		}
	}
}
