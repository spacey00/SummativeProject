package com.carrental.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.carrental.model.Approle;
import com.carrental.model.Appuser;
import com.carrental.model.Employee;
import com.carrental.repository.AppRoleRepository;
import com.carrental.repository.AppUserRepository;
import com.carrental.repository.EmployeeRepository;
import com.carrental.service.AppUserPdfExporter;
import com.carrental.service.AppUserService;
import com.lowagie.text.DocumentException;

@Controller
public class AppUserController {
	@Autowired
	private AppUserService appUserService;
	@Autowired
	private EmployeeRepository employeeRepo;
	@Autowired
	private AppUserRepository appUserRepo;
	@Autowired
	private AppRoleRepository appRoleRepo;

	public static HashMap<Integer, String> appUserAmendmentInProgress = new HashMap<>();
	private HashMap<Integer, String> appUserMap = new HashMap<>();

	@GetMapping("/appusers")
	public String viewHomePage(Model model, HttpSession session) {
		String keyword = "";
		return listByPage(model, 1, "appuserid", "asc", keyword, session); // (HtmlPage, PageNumber, ColumnName,
																			// OrderDirection, SearchKey)
	}

	@GetMapping("/appusers/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword,
			HttpSession session) {
// Prevent unauthorized entry through endpoint url	- start		
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end			

		session.setAttribute("currentpage", currentPage);
		session.setAttribute("sortfield", sortField);
		session.setAttribute("sortdir", sortDir);
		session.setAttribute("keyword", keyword);
		if(session.getAttribute("appUserEditId")==null) {
			session.setAttribute("appUserEditId", "0");
		}
		int x = Integer.parseInt((String) session.getAttribute("appUserEditId"));
		if (x != 0) {
			appUserAmendmentInProgress.remove(x);
		}

		Page<Appuser> page = appUserService.listAll(currentPage, sortField, sortDir, keyword);

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Appuser> listAppUsers = page.getContent();
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listAppUsers", listAppUsers);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "/appUsersHtml";
	}

	@GetMapping("/appusers/new")
	public String showNewForm(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
		// Prevent unauthorized entry through endpoint url - end

		Appuser appuser = new Appuser();
		model.addAttribute("appuser", appuser);
		List<Employee> listEmployees = employeeRepo.noAppUserAccount();
		model.addAttribute("listEmployees", listEmployees);
		List<Approle> listAppRoles = appRoleRepo.findAll();
		model.addAttribute("listAppRoles", listAppRoles);
		return "/newAppUserHtml";
	}

	@PostMapping("/appusers/checknew")
	public String checkNewForm(@Valid Appuser appuser, BindingResult bindingResult, Model model,
			HttpSession session) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("appuser", appuser);
			List<Employee> listEmployees = employeeRepo.findAll();
			model.addAttribute("listEmployees", listEmployees);
			List<Approle> listAppRoles = appRoleRepo.findAll();
			model.addAttribute("listAppRoles", listAppRoles);
			return "/newAppUserHtml";
		}
		List<Appuser> listAppUsers = appUserRepo.findAll();
		for (int i = 0; i < listAppUsers.size(); i++) {
			if (listAppUsers.get(i).getUsername().equalsIgnoreCase(appuser.getUsername())) {
				model.addAttribute("returnHtml", "/appusers/page");
				model.addAttribute("heading",
						"Username Already Used By User ID: " + listAppUsers.get(i).getAppuserid());
				return "/duplicatedHtml";
			}
		}

		List<Employee> listEmployees = employeeRepo.withAppUserAccount();
		for (int i = 0; i < listEmployees.size(); i++) {
			if (appuser.getEmployee().getEmployeeid() == listEmployees.get(i).getEmployeeid()) {
				model.addAttribute("returnHtml", "/appusers/page");
				model.addAttribute("heading", "Just Created By Another User");
				return "/duplicatedHtml";
			}
		}

		appuser.setPassword(new BCryptPasswordEncoder().encode(appuser.getPassword()));
		appUserService.save(appuser);
		System.out.println("Added by " + session.getAttribute("user") + ": " + appuser);
		Sort sort = Sort.by("appuserid");
		Pageable pageable = PageRequest.of(0, 5, sort.ascending());
		Page<Appuser> page = appUserRepo.findAll("*", pageable);
		int totalpages = page.getTotalPages();
		return listByPage(model, totalpages, "appuserid", "asc", "", session);
	}

	@PostMapping("/appusers/checkedit")
	public String checkEditForm(@Valid Appuser appuser, BindingResult bindingResult, Model model,
			HttpSession session) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("appuser", appuser);
			List<Employee> listEmployees = employeeRepo.findAll();
			model.addAttribute("listEmployees", listEmployees);
			List<Approle> listAppRoles = appRoleRepo.findAll();
			model.addAttribute("listAppRoles", listAppRoles);
			return "/editAppUserHtml";
		}

		List<Employee> listEmployees = employeeRepo.withAppUserAccount();
		listEmployees.remove(appuser.getEmployee());
		for (int i = 0; i < listEmployees.size(); i++) {
			if (appuser.getEmployee().getEmployeeid() == listEmployees.get(i).getEmployeeid()) {
				model.addAttribute("returnHtml", "/appusers/page");
				model.addAttribute("heading", "This Employee Already Has An User Account");
				return "/duplicatedHtml";
			}
		}

		appUserService.save(appuser);
		System.out.println("Edited by " + session.getAttribute("user") + ": " + appuser);
		return listByPage(model, (Integer) session.getAttribute("currentpage"),
				(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
				(String) session.getAttribute("keyword"), session);
	}

	@RequestMapping(value = "/updatepassword", method = RequestMethod.POST)
	public ModelAndView updatePassword(@ModelAttribute("appuser") Appuser appuser) {
		appuser.setPassword(new BCryptPasswordEncoder().encode(appuser.getPassword()));
		Approle approle = appRoleRepo.getOne(1);
		appuser.setRoleobj(approle);
		appUserService.save(appuser);
		LoginController.count++;

		Employee employee = employeeRepo.getOne(1);
		employee.setEmail(null);
		employee.setJobtitle(null);
		employee.setName(null);
		employee.setPhone(null);

		ModelAndView mav = new ModelAndView("/editEmployeeHtml");
		mav.addObject("employee", employee);
		mav.addObject("firstLogin", "yes");

		return mav;
	}

	@RequestMapping("/appusers/edit/{id}")
	public String showEditForm(@PathVariable(name = "id") Integer appuserid, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
		// Prevent unauthorized entry through endpoint url - end

		if (appUserAmendmentInProgress.containsKey(appuserid)) {
			model.addAttribute("userEdit", appUserMap.get(appuserid));
			model.addAttribute("returnHtml", "/appusers/page/");
			return "/amendmentInProgress";
		}

		List<Appuser> appUserList = appUserRepo.findAll();
		for (int i = 0; i < appUserList.size(); i++) {
			if (appUserList.get(i).getAppuserid() == appuserid) {
				appUserAmendmentInProgress.put(appuserid, session.getAttribute("user").toString());
				appUserMap.put(appuserid, session.getAttribute("user").toString());
				session.setAttribute("appUserEditId", "" + appuserid);

				Appuser appuser = appUserService.get(appuserid);
				model.addAttribute("appuser", appuser);

				List<Employee> listEmployees = employeeRepo.noAppUserAccount();
				listEmployees.add(appuser.getEmployee());

				model.addAttribute("listEmployees", listEmployees);
				List<Approle> listAppRoles = appRoleRepo.findAll();
				model.addAttribute("listAppRoles", listAppRoles);
				return "/editAppUserHtml";
			}
		}
		model.addAttribute("returnHtml", "/appusers/page/");
		model.addAttribute("userEdit", appUserMap.get(appuserid));
		return "/justDeleted";
	}

	@RequestMapping("/appusers/delete/{id}")
	public String deleteObj(@PathVariable(name = "id") Integer id, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
		// Prevent unauthorized entry through endpoint url - end

		try {
			if (appUserAmendmentInProgress.containsKey(id)) {
				model.addAttribute("userEdit", appUserMap.get(id));
				model.addAttribute("returnHtml", "/appusers/page/");
				return "/amendmentInProgress";
			}
			List<Appuser> appUserList = appUserRepo.findAll();
			for (int i = 0; i < appUserList.size(); i++) {
				if (appUserList.get(i).getAppuserid() == id) {
					appUserAmendmentInProgress.put(id, session.getAttribute("user").toString());
					appUserMap.put(id, session.getAttribute("user").toString());
					appUserService.delete(id);
					appUserAmendmentInProgress.remove(id);
					System.out.println("Deleted by " + session.getAttribute("user") + ": Appuser ID " + id);
					return listByPage(model, (Integer) session.getAttribute("currentpage"),
							(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
							(String) session.getAttribute("keyword"), session);
				}
			}
		} catch (Exception e) {
			model.addAttribute("returnHtml", "/appusers/page/");
			return "/violateReferentialIntegrityHtml";
		}
		model.addAttribute("returnHtml", "/appusers/page/");
		model.addAttribute("userEdit", appUserMap.get(id));
		return "/justDeleted";
	}

	@GetMapping("/appusers/exportCsv")
	public void exportToCSV(HttpServletResponse response, HttpSession session) throws IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("text/csv");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";

			String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
			response.setHeader(headerKey, headerValue);
			List<Appuser> listAppUsers = appUserRepo.findAll();

			ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
			String[] csvHeader = { "App User ID", "User Name", "Enabled", "App Role", "Employee" };
			String[] nameMapping = { "appuserid", "username", "enabled", "roleobj", "employee" };
			csvWriter.writeHeader(csvHeader);

			for (Appuser appuser : listAppUsers) {
				csvWriter.write(appuser, nameMapping);
			}
			csvWriter.close();
		}
	}

	@GetMapping("/appusers/exportPdf")
	public void exportToPDF(HttpServletResponse response, HttpSession session) throws DocumentException, IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("application/pdf");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";
			String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
			response.setHeader(headerKey, headerValue);
			List<Appuser> listAppUsers = appUserRepo.findAll();

			AppUserPdfExporter exporter = new AppUserPdfExporter(listAppUsers);
			exporter.export(response);
		}
	}
}
