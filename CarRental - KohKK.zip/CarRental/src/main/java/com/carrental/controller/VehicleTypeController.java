package com.carrental.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.carrental.FileUploadUtil;
import com.carrental.model.Hire;
import com.carrental.model.Vehicletype;
import com.carrental.repository.HireRepository;
import com.carrental.repository.VehicleTypeRepository;
import com.carrental.service.VehicleTypePdfExporter;
import com.carrental.service.VehicleTypeService;
import com.lowagie.text.DocumentException;

@Controller
public class VehicleTypeController {
	@Autowired
	private VehicleTypeService vehicleTypeService;
	@Autowired
	private VehicleTypeRepository vehicleTypeRepo;
	@Autowired
	private HireRepository hireRepo;

	public static HashMap<Integer, String> vehicleTypeAmendmentInProgress = new HashMap<>();
	private HashMap<Integer, String> vehicleTypeMap = new HashMap<>();

	@GetMapping("/vehicletypes")
	public String viewHomePage(Model model, HttpSession session) {
		String keyword = "";
		return listByPage(model, 1, "vehicletypeid", "asc", keyword, session);
	}

	@GetMapping("/vehicletypes/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword,
			HttpSession session) {
		session.setAttribute("currentpage", currentPage);
		session.setAttribute("sortfield", sortField);
		session.setAttribute("sortdir", sortDir);
		session.setAttribute("keyword", keyword);
		if(session.getAttribute("vehicleTypeEditId")==null) {
			session.setAttribute("vehicleTypeEditId", "0");
		}
		int x = Integer.parseInt((String) session.getAttribute("vehicleTypeEditId"));
		if (x != 0) {
			vehicleTypeAmendmentInProgress.remove(x);
		}
		Page<Vehicletype> page = vehicleTypeService.listAll(currentPage, sortField, sortDir, keyword);

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Vehicletype> listVehicleTypes = page.getContent();
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listVehicleTypes", listVehicleTypes);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "/vehicleTypesHtml";
	}

	@GetMapping("/vehicletypes/new")
	public String showNewForm(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		Vehicletype vehicletype = new Vehicletype();
		model.addAttribute("vehicletype", vehicletype);
		return "/newVehicleTypeHtml";
	}

	@PostMapping("/vehicletypes/checknew")
	public String checkVehicleTypeNew(@Valid Vehicletype vehicletype, BindingResult bindingResult, Model model,
			@RequestParam("video") MultipartFile multipartFile, HttpServletRequest request, HttpSession session)
			throws IOException {
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		if (!fileName.isEmpty()) {
			vehicletype.setVehicletypevideo(fileName);
			String uploadDir = "vehiclephotos/";
			FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
		}

		if (bindingResult.hasErrors()) {
			model.addAttribute("vehicletype", vehicletype);
			return "/newVehicleTypeHtml";
		}
		if (vehicletype.getVehicletypevideo() == null) {
			String[] video = request.getParameterValues("originvideo");
			vehicletype.setVehicletypevideo(video[0]);
		}
		vehicleTypeService.save(vehicletype);
		System.out.println("Added by " + session.getAttribute("user") + ": " + vehicletype);
		Sort sort = Sort.by("vehicletypeid");
		Pageable pageable = PageRequest.of(0, 5, sort.ascending());
		Page<Vehicletype> page = vehicleTypeRepo.findAll("*", pageable);
		int totalpages = page.getTotalPages();
		return listByPage(model, totalpages, "vehicletypeid", "asc", "", session);
	}

	@PostMapping("/vehicletypes/checkedit")
	public String checkEditForm(@Valid Vehicletype vehicletype, BindingResult bindingResult, Model model,
			@RequestParam("video") MultipartFile multipartFile, HttpServletRequest request, HttpSession session)
			throws IOException {
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		if (!fileName.isEmpty()) {
			vehicletype.setVehicletypevideo(fileName);
			String uploadDir = "vehiclephotos/";
			FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
		} else {
			String[] video = request.getParameterValues("originvideo");
			vehicletype.setVehicletypevideo(video[0]);
		}
		if (bindingResult.hasErrors()) {
			return "/editVehicleTypeHtml";
		}
		vehicleTypeService.save(vehicletype);
		System.out.println("Edited by " + session.getAttribute("user") + ": " + vehicletype);
		return listByPage(model, (Integer) session.getAttribute("currentpage"),
				(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
				(String) session.getAttribute("keyword"), session);
	}

	@RequestMapping("/vehicletypes/edit/{id}")
	public String showEditForm(@PathVariable(name = "id") Integer vehicletypeid, Model model,
			HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		if (vehicleTypeAmendmentInProgress.containsKey(vehicletypeid)) {
			model.addAttribute("userEdit", vehicleTypeMap.get(vehicletypeid));
			model.addAttribute("returnHtml", "/vehicletypes/page/");
			return "/amendmentInProgress";
		}
		List<Vehicletype> vehicleTypeList = vehicleTypeRepo.findAll();
		for (int i = 0; i < vehicleTypeList.size(); i++) {
			if (vehicleTypeList.get(i).getVehicletypeid() == vehicletypeid) {
				vehicleTypeAmendmentInProgress.put(vehicletypeid, session.getAttribute("user").toString());
				vehicleTypeMap.put(vehicletypeid, session.getAttribute("user").toString());
				session.setAttribute("vehicleTypeEditId", "" + vehicletypeid);
				Vehicletype vehicletype = vehicleTypeService.get(vehicletypeid);
				model.addAttribute("vehicletype", vehicletype);
				return "/editVehicleTypeHtml";
			}
		}
		model.addAttribute("returnHtml", "/vehicletypes/page/");
		model.addAttribute("userEdit", vehicleTypeMap.get(vehicletypeid));
		return "/justDeleted";
	}

	@RequestMapping("/vehicletypes/delete/{id}")
	public String deleteObj(@PathVariable(name = "id") Integer id, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		try {
			if (vehicleTypeAmendmentInProgress.containsKey(id)) {
				model.addAttribute("userEdit", vehicleTypeMap.get(id));
				model.addAttribute("returnHtml", "/vehicletypes/page/");
				return "/amendmentInProgress";
			}
			List<Vehicletype> vehicleTypeList = vehicleTypeRepo.findAll();
			for (int i = 0; i < vehicleTypeList.size(); i++) {
				if (vehicleTypeList.get(i).getVehicletypeid() == id) {
					vehicleTypeAmendmentInProgress.put(id, session.getAttribute("user").toString());
					vehicleTypeMap.put(id, session.getAttribute("user").toString());
					vehicleTypeService.delete(id);
					vehicleTypeAmendmentInProgress.remove(id);
					System.out.println("Deleted by " + session.getAttribute("user") + ": Vehicletype ID " + id);
					return listByPage(model, (Integer) session.getAttribute("currentpage"),
							(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
							(String) session.getAttribute("keyword"), session);
				}
			}
		} catch (Exception e) {
			model.addAttribute("returnHtml", "/vehicletypes/page/");
			return "/violateReferentialIntegrityHtml";
		}
		model.addAttribute("returnHtml", "/vehicletypes/page/");
		model.addAttribute("userEdit", vehicleTypeMap.get(id));
		return "/justDeleted";
	}

	@GetMapping("/vehicletypes/exportCsv")
	public void exportToCSV(HttpServletResponse response) throws IOException {
		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = "Content-Disposition";

		String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();

		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Vehicle Type ID", "Brand", "Model", "Fuel Type", "Gear Type", "Rate ($/day)" };
		String[] nameMapping = { "vehicletypeid", "brand", "model", "fueltype", "geartype", "rate" };
		csvWriter.writeHeader(csvHeader);

		for (Vehicletype vehicletype : listVehicleTypes) {
			csvWriter.write(vehicletype, nameMapping);
		}
		csvWriter.close();
	}

	@GetMapping("/vehicletypes/exportPdf")
	public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
		response.setContentType("application/pdf");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
		response.setHeader(headerKey, headerValue);
		List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();

		VehicleTypePdfExporter exporter = new VehicleTypePdfExporter(listVehicleTypes);
		exporter.export(response);
	}

	@GetMapping("/showvehicletyperevenuechart")
	public String showChart(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString()
							.contains("manager"))) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		try {
			Date dateStart = dateFormatter.parse("01-02-2021");
			String dateStartStr = dateFormatter.format(dateStart);
			Date dateEnd = new Date();
			String dateEndStr = dateFormatter.format(dateEnd);
			List<Hire> listHires = hireRepo.findHiresBetweenDates(dateStart, dateEnd);

			List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();
			double[] revenues = new double[20];
			double numberOfDays = 0;
			Map<Integer, Double> graphData = new TreeMap<>();

			for (int vt = 0; vt < listVehicleTypes.size(); vt++) {
				revenues[vt] = 0.0;
				for (int h = 0; h < listHires.size(); h++) {
					if (listHires.get(h).getVehicle().getVehicleobj().getVehicletypeid() == listVehicleTypes.get(vt)
							.getVehicletypeid()) {
						Date startdate = listHires.get(h).getDatestart();
						if (startdate.compareTo(dateStart) < 0) {
							startdate = dateStart;
						}
						Date enddate;
						if (listHires.get(h).getDatereturn() == null
								|| listHires.get(h).getDatereturn().compareTo(dateEnd) > 0) {
							enddate = dateEnd;
						} else {
							enddate = listHires.get(h).getDatereturn();
						}
						numberOfDays = 1 + TimeUnit.DAYS.convert((enddate.getTime() - startdate.getTime()),
								TimeUnit.MILLISECONDS);

						revenues[vt] += listHires.get(h).getVehicle().getVehicleobj().getRate() * numberOfDays;
					}
				}
				graphData.put(listVehicleTypes.get(vt).getVehicletypeid(), revenues[vt]);
			}
			model.addAttribute("chartData", graphData);
			model.addAttribute("listVehicleTypes", listVehicleTypes);
			model.addAttribute("dateStart", dateStartStr);
			model.addAttribute("dateEnd", dateEndStr);

			List<List<Object>> lineData = new ArrayList<>();
			Calendar c = Calendar.getInstance();
			Date d = dateStart;
			double revenue = 0;
			int count = 0;

			do {
				List<Object> dateData = new ArrayList<>();
				dateData.add(d);
				count++;
				for (int j = 0; j < listVehicleTypes.size(); j++) {
					revenue = 0;
					for (int i = 0; i < listHires.size(); i++) {
						if (listHires.get(i).getDatereturn() == null)
							listHires.get(i).setDatereturn(new Date());
						if ((d.after(listHires.get(i).getDatestart()) || d.equals(listHires.get(i).getDatestart()))
								&& (d.before(listHires.get(i).getDatereturn())
										|| d.equals(listHires.get(i).getDatereturn())
										|| listHires.get(i).getDatereturn() == null)) {

							if (listHires.get(i).getVehicle().getVehicleobj().getVehicletypeid() == j + 1) {
								revenue += listHires.get(i).getVehicle().getVehicleobj().getRate();
							}
						}
					}
					dateData.add(revenue);
				}
				lineData.add(dateData);
				c.setTime(d);
				c.add(Calendar.DATE, 1);
				d = c.getTime();
			} while ((d.before(dateEnd) || d.equals(dateEnd)));
			model.addAttribute("lineChartData", lineData);
			model.addAttribute("vehicletypes", listVehicleTypes.size());
			model.addAttribute("numberofdata", count);

			return "/chartVehicleTypeRevenue";
		} catch (Exception e) {
			return "/error";
		}
	}

	@PostMapping("/showvehicletyperevenuechart")
	public String showPostChart(Model model, HttpServletRequest request) {
		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		try {
			String[] dateStarts = request.getParameterValues("dateStart");
			String[] dateEnds = request.getParameterValues("dateEnd");
			Date dateStart = dateFormatter.parse(dateStarts[0]);
			Date dateEnd = dateFormatter.parse(dateEnds[0]);

			List<Hire> listHires = hireRepo.findHiresBetweenDates(dateStart, dateEnd);

			List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();
			double[] revenues = new double[20];
			double numberOfDays = 0;
			Map<Integer, Double> graphData = new TreeMap<>();

			for (int vt = 0; vt < listVehicleTypes.size(); vt++) {
				revenues[vt] = 0.0;
				for (int h = 0; h < listHires.size(); h++) {
					if (listHires.get(h).getVehicle().getVehicleobj().getVehicletypeid() == listVehicleTypes.get(vt)
							.getVehicletypeid()) {
						Date startdate = listHires.get(h).getDatestart();
						if (startdate.compareTo(dateStart) < 0) {
							startdate = dateStart;
						}
						Date enddate;
						if (listHires.get(h).getDatereturn() == null
								|| listHires.get(h).getDatereturn().compareTo(dateEnd) > 0) {
							enddate = dateEnd;
						} else {
							enddate = listHires.get(h).getDatereturn();
						}

						numberOfDays = 1 + TimeUnit.DAYS.convert((enddate.getTime() - startdate.getTime()),
								TimeUnit.MILLISECONDS);

						revenues[vt] += listHires.get(h).getVehicle().getVehicleobj().getRate() * numberOfDays;
					}
				}
				graphData.put(listVehicleTypes.get(vt).getVehicletypeid(), revenues[vt]);
			}
			model.addAttribute("chartData", graphData);
			model.addAttribute("listVehicleTypes", listVehicleTypes);
			model.addAttribute("dateStart", dateStarts[0]);
			model.addAttribute("dateEnd", dateEnds[0]);

			List<List<Object>> lineData = new ArrayList<>();
			Calendar c = Calendar.getInstance();
			Date d = dateStart;
			double revenue = 0;
			int count = 0;

			do {
				List<Object> dateData = new ArrayList<>();
				dateData.add((Date) d);
				count++;
				for (int j = 0; j < listVehicleTypes.size(); j++) {
					revenue = 0;
					for (int i = 0; i < listHires.size(); i++) {
						if (listHires.get(i).getDatereturn() == null)
							listHires.get(i).setDatereturn(new Date());
						if ((d.after(listHires.get(i).getDatestart()) || d.equals(listHires.get(i).getDatestart()))
								&& (d.before(listHires.get(i).getDatereturn())
										|| d.equals(listHires.get(i).getDatereturn())
										|| listHires.get(i).getDatereturn() == null)) {

							if (listHires.get(i).getVehicle().getVehicleobj().getVehicletypeid() == j + 1) {
								revenue += listHires.get(i).getVehicle().getVehicleobj().getRate();
							}
						}
					}
					dateData.add((Double) revenue);
				}
				lineData.add(dateData);
				c.setTime(d);
				c.add(Calendar.DATE, 1);
				d = c.getTime();
			} while ((d.before(dateEnd) || d.equals(dateEnd)));
			model.addAttribute("lineChartData", lineData);
			model.addAttribute("vehicletypes", listVehicleTypes.size());
			model.addAttribute("numberofdata", count);
			return "/chartVehicleTypeRevenue";
		} catch (Exception e) {
			return "/error";
		}
	}

}
