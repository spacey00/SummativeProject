package com.carrental.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.carrental.model.Appuser;
import com.carrental.model.Customer;
import com.carrental.model.Hire;
import com.carrental.model.Vehicle;
import com.carrental.model.Vehicletype;
import com.carrental.repository.AppUserRepository;
import com.carrental.repository.CustomerRepository;
import com.carrental.repository.HireRepository;
import com.carrental.repository.RentAvailableRepository;
import com.carrental.repository.VehicleTypeRepository;
import com.carrental.service.HireService;
import com.carrental.service.RentAvailableService;
import com.carrental.service.VehiclePdfExporter;
import com.carrental.service.VehicleService;
import com.lowagie.text.DocumentException;

@Controller
public class RentAvailableController {
	@Autowired
	private RentAvailableService rentAvailableService;
	@Autowired
	private RentAvailableRepository rentAvailableRepo;
	@Autowired
	private HireService hireService;
	@Autowired
	private HireRepository hireRepo;
	@Autowired
	private VehicleService vehicleService;
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private AppUserRepository appUserRepo;
	@Autowired
	private VehicleTypeRepository vehicleTypeRepo;

	@GetMapping("/rentavailableslider")
	public String viewSlider(Model model, HttpSession session) {
		List<Vehicletype> listVehicleTypes = vehicleTypeRepo.findAll();
		List<Vehicle> listVehicles = rentAvailableRepo.findAll();
		model.addAttribute("listVehicles", listVehicles);
		model.addAttribute("listVehicleTypes", listVehicleTypes);
		model.addAttribute("size", listVehicles.size());
		session.setAttribute("sourceTemplate", "vehicleAvailableSliderHtml");
		return "/vehicleAvailableSliderHtml";
	}

	@GetMapping("/rentavailables")
	public String viewRPage(Model model, HttpSession session) {
		session.setAttribute("sourceTemplate", "rentAvailablesHtml");
		String keyword = "";
		return listByPage(model, 1, "vehicleid", "asc", keyword, session);
	}

	@GetMapping("/rentavailables/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword,
			HttpSession session) {
		session.setAttribute("currentpage", currentPage);
		session.setAttribute("sortfield", sortField);
		session.setAttribute("sortdir", sortDir);
		session.setAttribute("keyword", keyword);
		Page<Vehicle> page = rentAvailableService.listAll(currentPage, sortField, sortDir, keyword);

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Vehicle> listVehicles = page.getContent();

		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listVehicles", listVehicles);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);

		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "/rentAvailablesHtml";
	}

	@GetMapping("/rentavailables/rent/{id}")
	public String rentAvailableForm(@PathVariable(name = "id") Integer id, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString()
							.contains("staff"))) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
// Prevent unauthorized entry through endpoint url	- end

		Vehicle vehicle = vehicleService.get(id);
		Hire hire = new Hire();
		hire.setDatestart(new Date());
		hire.setVehicle(vehicle);

		model.addAttribute("hire", hire);
		List<Customer> listCustomers = customerRepo.findAll();
		model.addAttribute("listCustomers", listCustomers);
		model.addAttribute("sourceTemplate", session.getAttribute("sourceTemplate"));
		return "/rentAvailableHireHtml";
	}

	@RequestMapping(value = "/rentavailables/save", method = RequestMethod.POST)
	public String saveHire(@ModelAttribute("hire") Hire hire, Model model, HttpSession session) {

		List<Hire> listHires = hireRepo.findConflictSchedule(hire.getVehicle(), hire.getDatestart(),
				hire.getDatereturn());
		if (listHires.size() > 0) {
			if (session.getAttribute("sourceTemplate") == "rentAvailablesHtml") {
				model.addAttribute("returnHtml", "rentavailables");
			} else {
				model.addAttribute("returnHtml", "rentavailableslider");
			}
			model.addAttribute("heading", "Just Rent Out By Another User");
			return "/duplicatedHtml";
		}
		Appuser appuser = appUserRepo.getUserByUsername(session.getAttribute("user").toString());
		hire.setAppuser(appuser);
		hireService.save(hire);
		System.out.println("Created by " + session.getAttribute("user") + ": " + hire);
		if (session.getAttribute("sourceTemplate") == "rentAvailablesHtml") {
			return listByPage(model, (Integer) session.getAttribute("currentpage"),
					(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
					(String) session.getAttribute("keyword"), session);
		} else {
			return "redirect:/rentavailableslider";
		}
	}

	@GetMapping("/rentavailables/exportCsv")
	public void exportToCSV(HttpServletResponse response) throws IOException {
		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = "Content-Disposition";

		String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);
		List<Vehicle> listAvailableVehicles = rentAvailableRepo.findAll();

		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = { "Vehicle ID", "Vehicle Type" };
		String[] nameMapping = { "vehicleid", "vehicleobj" };

		csvWriter.writeHeader(csvHeader);

		for (Vehicle availableVehicle : listAvailableVehicles) {
			csvWriter.write(availableVehicle, nameMapping);
		}
		csvWriter.close();
	}

	@GetMapping("/rentavailables/exportPdf")
	public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
		response.setContentType("application/pdf");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());
		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
		response.setHeader(headerKey, headerValue);

		List<Vehicle> listAvailableVehicles = rentAvailableRepo.findAll();

		VehiclePdfExporter exporter = new VehiclePdfExporter(listAvailableVehicles);
		exporter.export(response);
	}
}
