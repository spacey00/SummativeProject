package com.carrental.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelpController {

	@GetMapping("/help/systemSetUp")
	public String systemSetUp(Model model) {
		return "/flowchartSetUpSystemHtml";
	}

	@GetMapping("/help/rentavehiclemarket")
	public String rentAVehicleMarket(Model model) {
		return "/flowchartRentVehicleMarketHtml";
	}

	@GetMapping("/help/rentavehicle")
	public String rentAVehicle(Model model) {
		return "/flowchartRentVehicleHtml";
	}

	@GetMapping("/help/returnavehicle")
	public String returnAVehicle(Model model) {
		return "/flowchartReturnVehicleHtml";
	}

	@GetMapping("/help/payment")
	public String payment(Model model) {
		return "/flowchartPaymentHtml";
	}

	@GetMapping("/help/appuseradmin")
	public String appUserAdmin(Model model) {
		return "/flowchartAppUserAdminHtml";
	}

	@GetMapping("/help/customeradmin")
	public String customerAdmin(Model model) {
		return "/flowchartCustomerAdminHtml";
	}

	@GetMapping("/help/employeeadmin")
	public String employeeAdmin(Model model) {
		return "/flowchartEmployeeAdminHtml";
	}

	@GetMapping("/help/hireadmin")
	public String hireAdmin(Model model) {
		return "/flowchartHireAdminHtml";
	}

	@GetMapping("/help/invoiceadmin")
	public String invoiceAdmin(Model model) {
		return "/flowchartInvoiceAdminHtml";
	}

	@GetMapping("/help/vehicletypeadmin")
	public String vehicleTypeAdmin(Model model) {
		return "/flowchartVehicleTypeAdminHtml";
	}

	@GetMapping("/help/vehiclelistmarket")
	public String vehicleListMarket(Model model) {
		return "/flowchartVehicleListMarketHtml";
	}

	@GetMapping("/help/vehicleadmin")
	public String vehicleAdmin(Model model) {
		return "/flowchartVehicleAdminHtml";
	}

	@GetMapping("/help/reportcustomer")
	public String reportCustomer(Model model) {
		return "/flowchartCustomerReportHtml";
	}

	@GetMapping("/help/reportvehicletype")
	public String reportVehicleType(Model model) {
		return "/flowchartVehicleTypeReportHtml";
	}

	@GetMapping("/help/reportvehicle")
	public String reportVehicle(Model model) {
		return "/flowchartVehicleReportHtml";
	}

	@GetMapping("/help/lockMaintenance")
	public String reportLockMaintenance(Model model) {
		return "/flowchartUnlockIdLockHtml";
	}

	@GetMapping("/help/erDiagram")
	public String showErDiagram(Model model) {
		return "/erDiagramHtml";
	}

}
