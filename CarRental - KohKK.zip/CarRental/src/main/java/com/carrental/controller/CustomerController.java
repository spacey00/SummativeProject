package com.carrental.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.carrental.model.Customer;
import com.carrental.model.Hire;
import com.carrental.repository.CustomerRepository;
import com.carrental.repository.HireRepository;
import com.carrental.service.CustomerPdfExporter;
import com.carrental.service.CustomerService;
import com.lowagie.text.DocumentException;

@Controller
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private HireRepository hireRepo;

	public static HashMap<Integer, String> customerAmendmentInProgress = new HashMap<>();
	private HashMap<Integer, String> customerMap = new HashMap<>();

	@GetMapping("/customers")
	public String viewHomePage(Model model, HttpSession session) {
		String keyword = "";
		return listByPage(model, 1, "customerid", "asc", keyword, session); // (HtmlPage, PageNumber, ColumnName,
																			// OrderDirection, SearchKey)
	}

	@GetMapping("/customers/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword,
			HttpSession session) {

		session.setAttribute("currentpage", currentPage);
		session.setAttribute("sortfield", sortField);
		session.setAttribute("sortdir", sortDir);
		session.setAttribute("keyword", keyword);
		if(session.getAttribute("customerEditId")==null) {
			session.setAttribute("customerEditId", "0");
		}
		int x = Integer.parseInt((String) session.getAttribute("customerEditId"));
		if (x != 0) {
			customerAmendmentInProgress.remove(x);
		}

		Page<Customer> page = customerService.listAll(currentPage, sortField, sortDir, keyword);
		List<Customer> customerList = customerRepo.findAll();
		model.addAttribute("size", customerList.size());

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Customer> listCustomers = page.getContent();
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listCustomers", listCustomers);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "/customersHtml";
	}

	@GetMapping("/customers/new")
	public String showNewForm(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
		// Prevent unauthorized entry through endpoint url - end

		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		return "/newCustomerHtml";
	}

	@PostMapping("/customers/checknew")
	public String checkNewForm(@Valid Customer customer, BindingResult bindingResult, Model model,
			HttpSession session) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("customer", customer);
			return "/newCustomerHtml";
		}
		List<Customer> listCustomers = customerRepo.findAll();
		for (int i = 0; i < listCustomers.size(); i++) {
			if (listCustomers.get(i).getDriverlicence().equalsIgnoreCase(customer.getDriverlicence())) {
				model.addAttribute("returnHtml", "/customers/page");
				model.addAttribute("heading",
						"Driver Licence Already Used By Customer ID: " + listCustomers.get(i).getCustomerid());
				return "/duplicatedHtml";
			}
		}
		customerService.save(customer);
		System.out.println(" Added by " + session.getAttribute("user") + ": " + customer);
		Sort sort = Sort.by("customerid");
		Pageable pageable = PageRequest.of(0, 5, sort.ascending());
		Page<Customer> page = customerRepo.findAll("*", pageable);
		int totalpages = page.getTotalPages();
		return listByPage(model, totalpages, "customerid", "asc", "", session);

	}

	@PostMapping("/customers/checkedit")
	public String checkEditForm(@Valid Customer customer, BindingResult bindingResult, Model model,
			HttpSession session) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("customer", customer);
			return "/editCustomerHtml";
		}
		customerService.save(customer);
		System.out.println("Edited by " + session.getAttribute("user") + ": " + customer);
		return listByPage(model, (Integer) session.getAttribute("currentpage"),
				(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
				(String) session.getAttribute("keyword"), session);
	}

	@RequestMapping("/customers/edit/{id}")
	public String showEditForm(@PathVariable(name = "id") Integer customerid, Model model,
			HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
		// Prevent unauthorized entry through endpoint url - end

		if (customerAmendmentInProgress.containsKey(customerid)) {
			model.addAttribute("userEdit", customerMap.get(customerid));
			model.addAttribute("returnHtml", "/customers/page/");
			return "/amendmentInProgress";
		}
		List<Customer> customerList = customerRepo.findAll();
		for (int i = 0; i < customerList.size(); i++) {
			if (customerList.get(i).getCustomerid() == customerid) {
				customerAmendmentInProgress.put(customerid, session.getAttribute("user").toString());
				customerMap.put(customerid, session.getAttribute("user").toString());
				session.setAttribute("customerEditId", "" + customerid);
				Customer customer = customerService.get(customerid);
				model.addAttribute("customer", customer);
				return "/editCustomerHtml";
			}
		}
		model.addAttribute("returnHtml", "/customers/page/");
		model.addAttribute("userEdit", customerMap.get(customerid));
		return "/justDeleted";
	}

	@RequestMapping("/customers/delete/{id}")
	public String deleteObj(@PathVariable(name = "id") Integer id, Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin")) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
		// Prevent unauthorized entry through endpoint url - end

		try {
			if (customerAmendmentInProgress.containsKey(id)) {
				model.addAttribute("userEdit", customerMap.get(id));
				model.addAttribute("returnHtml", "/customers/page/");
				return "/amendmentInProgress";
			}
			List<Customer> customerList = customerRepo.findAll();
			for (int i = 0; i < customerList.size(); i++) {
				if (customerList.get(i).getCustomerid() == id) {
					customerAmendmentInProgress.put(id, session.getAttribute("user").toString());
					customerMap.put(id, session.getAttribute("user").toString());
					customerService.delete(id);
					customerAmendmentInProgress.remove(id);
					System.out.println("Deleted by " + session.getAttribute("user") + ": Customer ID " + id);
					return listByPage(model, (Integer) session.getAttribute("currentpage"),
							(String) session.getAttribute("sortfield"), (String) session.getAttribute("sortdir"),
							(String) session.getAttribute("keyword"), session);
				}
			}
		} catch (Exception e) {
			model.addAttribute("returnHtml", "/customers/page/");
			return "/violateReferentialIntegrityHtml";
		}
		model.addAttribute("returnHtml", "/customers/page/");
		model.addAttribute("userEdit", customerMap.get(id));
		return "/justDeleted";
	}

	@GetMapping("/customers/exportCsv")
	public void exportToCSV(HttpServletResponse response, HttpSession session) throws IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("text/csv");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";

			String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
			response.setHeader(headerKey, headerValue);
			List<Customer> listCustomers = customerRepo.findAll();

			ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
			String[] csvHeader = { "Customer ID", "Name", "Address", "Phone", "Email", "Office Tel", "Website",
					"Driver Licence" };
			String[] nameMapping = { "customerid", "name", "address", "phone", "email", "officeno", "website",
					"driverlicence" };
			csvWriter.writeHeader(csvHeader);

			for (Customer customer : listCustomers) {
				csvWriter.write(customer, nameMapping);
			}
			csvWriter.close();
		}
	}

	@GetMapping("/customers/exportPdf")
	public void exportToPDF(HttpServletResponse response, HttpSession session) throws DocumentException, IOException {
// Prevent unauthorized entry through endpoint url - start
		if (((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("manager")
				|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("staff"))) {
// Prevent unauthorized entry through endpoint url - end

			response.setContentType("application/pdf");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());
			String headerKey = "Content-Disposition";
			String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
			response.setHeader(headerKey, headerValue);
			List<Customer> listCustomers = customerRepo.findAll();

			CustomerPdfExporter exporter = new CustomerPdfExporter(listCustomers);
			exporter.export(response);
		}
	}

	@GetMapping("/showcustomerrevenuechart")
	public String showChart(Model model, HttpSession session) {
		// Prevent unauthorized entry through endpoint url - start
		try {
			if (!((((UserDetails) session.getAttribute("principal")).getAuthorities().toString().contains("admin"))
					|| ((UserDetails) session.getAttribute("principal")).getAuthorities().toString()
							.contains("manager"))) {
				return "/trespass";
			}
		} catch (Exception e) {
			return "/trespass";
		}
		// Prevent unauthorized entry through endpoint url - end
		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		try {
			Date dateStart = dateFormatter.parse("01-02-2021");
			String dateStartStr = dateFormatter.format(dateStart);
			Date dateEnd = new Date();
			String dateEndStr = dateFormatter.format(dateEnd);
			List<Hire> listHires = hireRepo.findHiresBetweenDates(dateStart, dateEnd);
			List<Customer> listCustomers = customerRepo.findAll();
			double[] revenues = new double[20];
			double numberOfDays = 0;
			Map<Integer, Double> graphData = new TreeMap<>();

			for (int c = 0; c < listCustomers.size(); c++) {
				revenues[c] = 0.0;
				for (int h = 0; h < listHires.size(); h++) {
					if (listHires.get(h).getCustomer().getCustomerid() == listCustomers.get(c).getCustomerid()) {
						Date startdate = listHires.get(h).getDatestart();
						if (startdate.compareTo(dateStart) < 0) {
							startdate = dateStart;
						}
						Date enddate;
						if (listHires.get(h).getDatereturn() == null
								|| listHires.get(h).getDatereturn().compareTo(dateEnd) > 0) {
							enddate = dateEnd;
						} else {
							enddate = listHires.get(h).getDatereturn();
						}
						numberOfDays = 1 + TimeUnit.DAYS.convert((enddate.getTime() - startdate.getTime()),
								TimeUnit.MILLISECONDS);

						revenues[c] += listHires.get(h).getVehicle().getVehicleobj().getRate() * numberOfDays;
					}
				}
				graphData.put(listCustomers.get(c).getCustomerid(), revenues[c]);
			}
			model.addAttribute("chartData", graphData);
			model.addAttribute("listCustomers", listCustomers);
			model.addAttribute("dateStart", dateStartStr);
			model.addAttribute("dateEnd", dateEndStr);

			List<List<Object>> lineData = new ArrayList<>();
			Calendar c = Calendar.getInstance();
			Date d = dateStart;
			double revenue = 0;
			int count = 0;

			do {
				List<Object> dateData = new ArrayList<>();
				dateData.add(d);
				count++;
				for (int j = 0; j < listCustomers.size(); j++) {
					revenue = 0;
					for (int i = 0; i < listHires.size(); i++) {
						if (listHires.get(i).getDatereturn() == null)
							listHires.get(i).setDatereturn(new Date());
						if ((d.after(listHires.get(i).getDatestart()) || d.equals(listHires.get(i).getDatestart()))
								&& (d.before(listHires.get(i).getDatereturn())
										|| d.equals(listHires.get(i).getDatereturn())
										|| listHires.get(i).getDatereturn() == null)) {

							if (listHires.get(i).getCustomer().getCustomerid() == j + 1) {
								revenue += listHires.get(i).getVehicle().getVehicleobj().getRate();
							}
						}
					}
					dateData.add(revenue);
				}
				lineData.add(dateData);
				c.setTime(d);
				c.add(Calendar.DATE, 1);
				d = c.getTime();
			} while ((d.before(dateEnd) || d.equals(dateEnd)));

			model.addAttribute("lineChartData", lineData);
			model.addAttribute("customers", listCustomers.size());
			model.addAttribute("numberofdata", count);

			return "/chartCustomerRevenue";
		} catch (Exception e) {
			return "/error";
		}
	}

	@PostMapping("/showcustomerrevenuechart")
	public String showPostChart(Model model, HttpServletRequest request) {
		DateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		try {
			String[] dateStarts = request.getParameterValues("dateStart");
			String[] dateEnds = request.getParameterValues("dateEnd");
			Date dateStart = dateFormatter.parse(dateStarts[0]);
			Date dateEnd = dateFormatter.parse(dateEnds[0]);
			List<Hire> listHires = hireRepo.findHiresBetweenDates(dateStart, dateEnd);
			List<Customer> listCustomers = customerRepo.findAll();
			double[] revenues = new double[20];
			double numberOfDays = 0;
			Map<Integer, Double> graphData = new TreeMap<>();

			for (int c = 0; c < listCustomers.size(); c++) {
				revenues[c] = 0.0;
				for (int h = 0; h < listHires.size(); h++) {
					if (listHires.get(h).getCustomer().getCustomerid() == listCustomers.get(c).getCustomerid()) {
						Date startdate = listHires.get(h).getDatestart();
						if (startdate.compareTo(dateStart) < 0) {
							startdate = dateStart;
						}
						Date enddate;
						if (listHires.get(h).getDatereturn() == null
								|| listHires.get(h).getDatereturn().compareTo(dateEnd) > 0) {
							enddate = dateEnd;
						} else {
							enddate = listHires.get(h).getDatereturn();
						}
						numberOfDays = 1 + TimeUnit.DAYS.convert((enddate.getTime() - startdate.getTime()),
								TimeUnit.MILLISECONDS);

						revenues[c] += listHires.get(h).getVehicle().getVehicleobj().getRate() * numberOfDays;
					}
				}
				graphData.put(listCustomers.get(c).getCustomerid(), revenues[c]);
			}
			model.addAttribute("chartData", graphData);
			model.addAttribute("listCustomers", listCustomers);
			model.addAttribute("dateStart", dateStarts[0]);
			model.addAttribute("dateEnd", dateEnds[0]);

			List<List<Object>> lineData = new ArrayList<>();
			Calendar c = Calendar.getInstance();
			Date d = dateStart;
			double revenue = 0;
			int count = 0;

			do {
				List<Object> dateData = new ArrayList<>();
				dateData.add(d);
				count++;
				for (int j = 0; j < listCustomers.size(); j++) {
					revenue = 0;
					for (int i = 0; i < listHires.size(); i++) {
						if (listHires.get(i).getDatereturn() == null)
							listHires.get(i).setDatereturn(new Date());
						if ((d.after(listHires.get(i).getDatestart()) || d.equals(listHires.get(i).getDatestart()))
								&& (d.before(listHires.get(i).getDatereturn())
										|| d.equals(listHires.get(i).getDatereturn())
										|| listHires.get(i).getDatereturn() == null)) {

							if (listHires.get(i).getCustomer().getCustomerid() == j + 1) {
								revenue += listHires.get(i).getVehicle().getVehicleobj().getRate();
							}
						}
					}
					dateData.add(revenue);
				}
				lineData.add(dateData);
				c.setTime(d);
				c.add(Calendar.DATE, 1);
				d = c.getTime();
			} while ((d.before(dateEnd) || d.equals(dateEnd)));

			model.addAttribute("lineChartData", lineData);
			model.addAttribute("customers", listCustomers.size());
			model.addAttribute("numberofdata", count);

			return "/chartCustomerRevenue";
		} catch (Exception e) {
			return "/error";
		}
	}

}
