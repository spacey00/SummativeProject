package com.carrental.aspect;

import javax.servlet.http.HttpSession;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {
	@Autowired
	private HttpSession session;
	private Object principal;
	private String user;

	@Before("execution(public String indexPage(..)) ||"
			+ "execution(public String listByPage(..)) ||"
			+ "execution(public String showChart(..)) ||"
			+ "execution(public String showNewForm(..)) ||"
			+ "execution(public String showEditForm(..)) ||"
			+ "execution(public String deleteObj(..)) ||"
			+ "execution(public String returnVehicle(..)) ||"
			+ "execution(public String rentAvailableForm(..)) ||"
			+ "execution(public String locksPage(..))")
	public void LoggingBeforeAdvice() {
		principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			user = ((UserDetails) principal).getUsername();
		} else {
			user = principal.toString();
		}
		session.setAttribute("user", user);
		session.setAttribute("principal", principal);
	}

}
